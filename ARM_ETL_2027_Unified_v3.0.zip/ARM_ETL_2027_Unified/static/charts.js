/* Лёгкий локальный офлайн-рендерер диаграмм (doughnut и bar) без внешних CDN */
(function () {
  function LocalChart(canvas, cfg) {
    this.canvas = canvas;
    this.cfg = cfg || {};
    this._render();
  }

  LocalChart.prototype.destroy = function () {
    if (!this.canvas) return;
    const ctx = this.canvas.getContext('2d');
    if (ctx) ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  };

  LocalChart.prototype._render = function () {
    const canvas = this.canvas;
    if (!canvas) return;
    const parent = canvas.parentElement;
    const width = Math.max(260, (parent && parent.clientWidth) || 360);
    const height = Math.max(190, (parent && parent.clientHeight) || 220);
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';

    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);

    const dataObj = (this.cfg && this.cfg.data) || {};
    const labels = dataObj.labels || [];
    const ds = (dataObj.datasets && dataObj.datasets[0]) || { data: [], backgroundColor: [] };
    const values = ds.data || [];
    const colors = Array.isArray(ds.backgroundColor) ? ds.backgroundColor : labels.map(() => ds.backgroundColor || '#2563eb');

    if (this.cfg.type === 'doughnut') {
      const total = values.reduce((a, b) => a + (Number(b) || 0), 0) || 1;
      const cx = width * 0.5;
      const cy = height * 0.41;
      const r = Math.min(width * 0.28, height * 0.34);
      const innerR = r * 0.6;
      let start = -Math.PI / 2;

      values.forEach((v, i) => {
        const val = Number(v) || 0;
        if (val <= 0) return;
        const angle = (val / total) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, r, start, start + angle);
        ctx.closePath();
        ctx.fillStyle = colors[i] || '#64748b';
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
        start += angle;
      });

      ctx.beginPath();
      ctx.arc(cx, cy, innerR, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 18px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(values.reduce((a, b) => a + (Number(b) || 0), 0)), cx, cy - 6);
      ctx.fillStyle = '#64748b';
      ctx.font = '11px sans-serif';
      ctx.fillText('всего', cx, cy + 12);

      // Legend bottom
      ctx.font = '11px sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      const cols = 2;
      const colW = width / cols;
      labels.forEach((lbl, i) => {
        const row = Math.floor(i / cols);
        const col = i % cols;
        const lx = 14 + col * colW;
        const ly = height - 34 + row * 18;
        ctx.fillStyle = colors[i] || '#64748b';
        ctx.fillRect(lx, ly - 5, 10, 10);
        ctx.fillStyle = '#334155';
        ctx.fillText(lbl + ' (' + (values[i] || 0) + ')', lx + 15, ly);
      });
      return;
    }

    // Bar chart
    const padL = 42, padR = 14, padT = 16, padB = 42;
    const plotW = width - padL - padR;
    const plotH = height - padT - padB;
    const maxV = Math.max(10, ...values.map((v) => Number(v) || 0));
    const stepCount = 4;

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    for (let s = 0; s <= stepCount; s++) {
      const y = padT + plotH - (s / stepCount) * plotH;
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(padL + plotW, y);
      ctx.stroke();
      ctx.fillText(String(Math.round((maxV * s) / stepCount)), padL - 6, y);
    }

    const n = Math.max(1, labels.length);
    const slotW = plotW / n;
    const barW = Math.min(44, slotW * 0.58);
    labels.forEach((lbl, i) => {
      const v = Number(values[i]) || 0;
      const h = (v / maxV) * plotH;
      const x = padL + i * slotW + (slotW - barW) / 2;
      const y = padT + plotH - h;
      ctx.fillStyle = colors[i] || '#2563eb';
      ctx.fillRect(x, y, barW, h);

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(String(v), x + barW / 2, y - 7);

      ctx.fillStyle = '#475569';
      ctx.font = '10px sans-serif';
      const shortLbl = String(lbl).length > 12 ? String(lbl).slice(0, 11) + '…' : String(lbl);
      ctx.fillText(shortLbl, x + barW / 2, padT + plotH + 14);
    });
  };

  window.Chart = LocalChart;
})();
