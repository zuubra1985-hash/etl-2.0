# DATABASE SCHEMA — Информационная модель и схема БД ETL 2.0

**Версия:** 0.1 (предварительная логическая модель; финализируется после получения образцов паспортов — `OQ-02`)  
**СУБД:** SQLite (WAL + Foreign Keys ON) для локального одно-/малопользовательского развёртывания с полной совместимостью через SQLAlchemy 2.0 + Alembic для перехода на PostgreSQL (см. `ADR-002`).

## 1. Реестр сущностей (21 таблица)

| № | Сущность (Таблица) | Назначение | Ключевые поля и ограничения |
|---|---|---|---|
| 1 | `departments` | Подразделения | `id (UUID)`, `name`, `code`, `parent_id` |
| 2 | `locations` | Места установки / объекты | `id (UUID)`, `department_id`, `facility_name`, `building`, `room`, `address` |
| 3 | `equipment_types` | Справочник типов оборудования | `id (UUID)`, `code`, `name`, `default_passport_template_id`, `schema_json` |
| 4 | `equipment` | Реестр электрооборудования | `id (UUID)`, `type_id`, `location_id`, `inventory_no`, `serial_no`, `name`, `manufacturer`, `model`, `specs_json`, `commissioned_at`, `status` (ACTIVE/REPAIR/ARCHIVED), `is_archived`; уникальный контроль дублей по `(inventory_no, serial_no)` |
| 5 | `qr_identities` | Постоянные QR-идентификаторы | `id (UUID)`, `equipment_id (UNIQUE)`, `qr_token (UUID v4, IMMUTABLE)`, `short_code`, `print_count`, `last_printed_at`, `checksum` |
| 6 | `passports` | Электронные паспорта | `id (UUID)`, `equipment_id (UNIQUE)`, `template_id`, `original_attachment_id` (неизменяемый оригинал), `current_version_id`, `created_at` |
| 7 | `passport_versions` | Версии паспорта | `id (UUID)`, `passport_id`, `version_no`, `data_json`, `rendered_attachment_id`, `source_test_id (NULLABLE)`, `change_reason`, `created_by`, `created_at` |
| 8 | `methodologies` | Библиотека методик (МВИ) | `id (UUID)`, `code` (МВИ-01..25), `title`, `scope`, `is_active` |
| 9 | `methodology_versions` | Редакции методик | `id (UUID)`, `methodology_id`, `edition`, `effective_date`, `norm_criteria_json`, `approved_by_user_id`, `approved_at`, `source_attachment_id`, `status` |
| 10 | `test_types` | Справочник видов испытаний | `id (UUID)`, `code` (P1..P24), `name`, `methodology_id`, `form_schema_json`, `protocol_template_id` |
| 11 | `instruments` | Реестр СИ и ИО | `id (UUID)`, `name`, `model`, `manufacturer`, `serial_no (UNIQUE)`, `measurement_range`, `accuracy_class`, `arshin_reg_no`, `calibration_date`, `calibration_valid_until`, `status` (ACTIVE/CALIBRATION/CONSERVATION) |
| 12 | `instrument_documents` | Свидетельства о поверке / паспорта СИ | `id (UUID)`, `instrument_id`, `doc_type`, `doc_number`, `valid_until`, `attachment_id` |
| 13 | `tests` | Проведённые испытания | `id (UUID)`, `equipment_id`, `test_type_id`, `methodology_version_id`, `test_date`, `test_time`, `purpose` (приёмо-сдаточные/контрольные/эксплуатационные), `temp_c`, `humidity_pct`, `pressure_mmhg`, `executor_user_id`, `status` (DRAFT/CONFIRMED/VERIFIED/CANCELLED), `instruments_snapshot_json`, `notes` |
| 14 | `measurement_parameters` | Справочник параметров измерений | `id (UUID)`, `test_type_id`, `code`, `name`, `unit`, `data_type`, `is_required`, `validation_rules_json` |
| 15 | `measurements` | Записи измерений | `id (UUID)`, `test_id`, `parameter_id`, `point_label` (присоединение/фаза), `raw_value`, `unit`, `conditions_json`, `instrument_id`, `compliance_status` (PASS/FAIL/NOT_EVALUATED — отдельно от сырого значения!), `norm_ref`, `is_superseded`, `superseded_by_id`, `correction_reason`, `corrected_by`, `corrected_at` |
| 16 | `protocols` | Сформированные протоколы | `id (UUID)`, `test_id`, `protocol_no`, `version_no`, `status` (DRAFT/GENERATED/REVIEWED/SIGNED/REVISED), `conclusion`, `attachment_id_docx`, `attachment_id_pdf`, `signatories_json`, `created_by`, `created_at` |
| 17 | `passport_fill_mappings` | Карта автозаполнения паспортов | `id (UUID)`, `equipment_type_id`, `test_type_id`, `passport_section_code`, `mapping_rules_json`, `is_active` |
| 18 | `attachments` | Метаданные файлов (CAS) | `id (UUID)`, `entity_type`, `entity_id`, `original_filename`, `storage_rel_path`, `sha256`, `mime_type`, `size_bytes`, `is_original_immutable`, `uploaded_by`, `uploaded_at` |
| 19 | `roles` | Роли RBAC | `id (UUID)`, `code` (ADMIN/HEAD/TESTER/REVIEWER/VIEWER), `name`, `permissions_json` |
| 20 | `users` | Пользователи | `id (UUID)`, `username (UNIQUE)`, `full_name`, `position`, `eb_group`, `password_hash`, `role_id`, `is_active`, `created_at` |
| 21 | `audit_log` | Неизменяемый журнал действий | `id (BIGINT)`, `user_id`, `action`, `entity_type`, `entity_id`, `before_json`, `after_json`, `reason`, `ip_address`, `created_at` |

## 2. Гарантии целостности (п. 21 ТЗ)
- **Неизменяемость истории:** при исправлении измерения старая запись не перезаписывается (`is_superseded = true`), создаётся новая запись со ссылкой и причиной.
- **Снимки приборов и методик:** в `tests.instruments_snapshot_json` фиксируется заводской № и дата поверки прибора на момент испытания; изменение карточки прибора в будущем не искажает исторические протоколы.
- **Идемпотентность автозаполнения паспорта:** уникальный индекс `(passport_id, source_test_id)` в `passport_versions` (где `source_test_id IS NOT NULL`) исключает повторное добавление одной и той же записи испытания.
- **Разделение хранения файлов и БД:** путь к файлу не является ключом сущности; все ссылки идут через `attachments.id (UUID)` и проверяются по `sha256`.

---

## 3. Уточнённая схема полей паспорта асинхронного электродвигателя (по образцам `.doc`, v0.2.0)

### 3.1. Постоянные и условно-постоянные поля (`equipment` + `passport_versions.data_json`)
- **Идентификация и привязка:** `dispatch_name` (диспетчерское наименование), `object_name`, `department` (ОГЭ), `location_name` (место установки), `serial_no` (Зав.№ / Номер агрегата), `inventory_no` (Инв.№), `manufacturer` (завод-изготовитель), `year_manufactured`, `year_installed`, `commissioned_date` (дата ввода), `is_explosion_proof` (обычный / взрывозащищённый), `explosion_zone_class`, `mixture_category`.
- **Раздел 1 (Схема подключения):** `connection_scheme_attachment_id` (UUID вложения SVG/PNG/VSDX).
- **Раздел 2 (20 технических характеристик):** `motor_type`, `ex_marking`, `ex_level_type`, `ex_group`, `temp_limit`, `power_kw`, `voltage_v`, `rated_current_a`, `idle_current_a`, `rpm`, `winding_scheme`, `phases_count`, `frequency_hz`, `start_method`, `efficiency_pct`, `power_factor`, `start_current_ratio`, `bearing_drive_end`, `bearing_non_drive_end`, `lubricant_type`, `weight_kg`, `cable_type`, `shaft_diameter_mm`, `mounting_type`.
- **Раздел 3 (Коммутация и РЗиА):** `switching_device_type`, `switching_device_location`, `protection_device_type`, `protection_device_location`.

### 3.2. Изменяемые журнальные разделы паспорта (табличные записи с версионированием)
- **Разделы 4–10:** *ожидается вкладыш от заказчика (`OQ-02a`)* — предварительно резервируется таблица `passport_test_records` (автозаполнение из `tests`/`protocols`) и `passport_repair_records`.
- **Раздел 11 (`passport_starter_repairs`):** `repair_date`, `order_ref` (дата и № наряда/распоряжения), `works_description`, `executor_name`, `notes`.
- **Раздел 12 (`passport_operating_hours`):** `record_date`, `operating_hours`, `object_name`, `tech_unit_name`, `responsible_name`, `notes`.
- **Раздел 13 (`passport_relocations`):** `relocation_date`, `object_name`, `tech_unit_name`, `responsible_name`, `notes`.
