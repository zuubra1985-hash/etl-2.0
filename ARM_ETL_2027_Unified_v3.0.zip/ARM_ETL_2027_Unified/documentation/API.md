# API — Спецификация REST API v1 (проект)

**Базовый префикс:** `/api/v1`  
**Формат обмена:** `application/json` (файлы — `multipart/form-data` / потоковая выгрузка)  
**Аутентификация:** Bearer JWT (Access + Refresh токены) + сессионные cookie для PWA.

## 1. Аутентификация и пользователи
- `POST /api/v1/auth/login` — вход, выдача JWT, запись в `audit_log`.
- `POST /api/v1/auth/refresh` — обновление токена.
- `GET /api/v1/auth/me` — профиль и права текущего пользователя.
- `GET/POST/PATCH /api/v1/users` — управление пользователями (только `ADMIN`).

## 2. Реестр оборудования и QR
- `GET /api/v1/equipment` — список с поиском, фильтрацией (тип, локация, статус) и пагинацией.
- `POST /api/v1/equipment` — создание объекта с проверкой на возможные дубликаты (возвращает предупреждение `409 Conflict` с кандидатами при совпадении инв./зав. №).
- `GET /api/v1/equipment/{id}` — полная карточка (сведения, ТХ, актуальный паспорт, последние испытания, QR).
- `PATCH /api/v1/equipment/{id}` — редактирование; `POST /api/v1/equipment/{id}/archive` — архивирование.
- `GET /api/v1/qr/resolve/{qr_token}` — точка входа после сканирования QR (требует авторизацию; возвращает `equipment_id` и перенаправляет на мобильную карточку).
- `GET /api/v1/equipment/{id}/qr/image` — PNG/SVG QR-кода; `POST /api/v1/qr/print-batch` — печатный лист (PDF) этикеток.

## 3. Электронные паспорта
- `GET /api/v1/equipment/{id}/passport` — актуальная версия паспорта и список версий.
- `POST /api/v1/equipment/{id}/passport/original` — загрузка неизменяемого оригинала изготовителя.
- `POST /api/v1/equipment/{id}/passport/versions` — сохранение новой редакции разрешённых полей.
- `GET /api/v1/passports/{passport_id}/versions/{version_no}/export?format=pdf|docx` — экспорт/печать.

## 4. Испытания, измерения и протоколы
- `GET /api/v1/equipment/{id}/applicable-tests` — применимые виды испытаний и методики для данного типа оборудования.
- `GET /api/v1/test-types/{id}/form-schema` — JSON-схема динамической формы ввода измерений.
- `POST /api/v1/tests` — создание черновика испытания.
- `PUT /api/v1/tests/{id}/measurements` — сохранение/обновление измерений в черновике.
- `POST /api/v1/tests/{id}/confirm` — **транзакционное подтверждение**: валидация → фиксация снимков СИ/МВИ → генерация протокола → автозаполнение паспорта (новая версия).
- `POST /api/v1/measurements/{id}/correct` — контролируемое исправление измерения с обязательной причиной.
- `GET /api/v1/protocols/{id}/download?format=docx|pdf` — скачивание протокола.
- `POST /api/v1/protocols/{id}/status` — смена статуса (`REVIEWED`, `SIGNED`, `REVISED`).

## 5. Справочники, панель и администрирование
- `GET /api/v1/dashboard/summary` — настраиваемые показатели главной панели (объекты, испытания, просроченные/истекающие поверки СИ, документы, требующие внимания).
- `GET/POST/PATCH /api/v1/instruments` — реестр СИ/ИО и свидетельства поверки.
- `GET/POST/PATCH /api/v1/methodologies` — версионируемые методики и ручное утверждение критериев НД.
- `GET /api/v1/reports/export` — выгрузка сводных отчётов (XLSX/PDF/CSV).
- `POST /api/v1/admin/backups` / `POST /api/v1/admin/backups/{id}/verify` — ручной бэкап и проверка целостности.
