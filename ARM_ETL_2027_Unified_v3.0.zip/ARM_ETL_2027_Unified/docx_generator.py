"""Генератор нативных документов Word (.docx) для ЭТЛ ООО «Сургут перевалка».

Поддерживает:
- Все 13 методик протоколов ЭТЛ с двухуровневыми объединёнными шапками Приложения № 2
- Технический отчёт (Титульный лист, Содержание, Протоколы, Ведомость дефектов)
- Опцию сквозной нумерации страниц в родном нижнем колонтитуле Word (PAGE / NUMPAGES)
- Генерацию наряда-допуска для работы в электроустановках по ПОТЭЭ № 903н (ред. № 279н)
"""

from __future__ import annotations

from io import BytesIO
from typing import Any

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

MONTHS_GEN = [
    "января", "февраля", "марта", "апреля", "мая", "июня",
    "июля", "августа", "сентября", "октября", "ноября", "декабря",
]

from mvi_catalog import MVI_BY_NUM


def _mvi_mii(num: int) -> str:
    m = MVI_BY_NUM[num]
    return f"{m['code']} ({m['short']} «{m['title']}», ред. 2027 г., утверждённой ООО «Сургут перевалка»)."


PROTOCOL_META: dict[str, dict[str, str]] = {
    "breaker_1p": {
        "title": "проверки срабатывания расцепителей однополюсных однофазных автоматических выключателей напряжением до 1 кВ",
        "mii": _mvi_mii(7),
        "nd": MVI_BY_NUM[7]["nd"],
        "indicator": "Измерение тока и времени срабатывания расцепителей",
        "nd_item": MVI_BY_NUM[7]["nd_item"],
        "method_no": "МВИ-ЭТЛ-07-2027 (Методика № 7)",
        "nd_val": "B: 3–5·Iн; C: 5–10·Iн; D: 10–20·Iн (ГОСТ IEC 60898-1-2020); tоткл ≤ 0,4 с (220 В)",
        "nd_tol": "Согласно требованиям ГОСТ IEC 60898-1-2020 и заводским данным",
    },
    "breaker_3p": {
        "title": "проверки срабатывания расцепителей трехфазных автоматических выключателей напряжением до 1 кВ",
        "mii": _mvi_mii(7),
        "nd": MVI_BY_NUM[7]["nd"],
        "indicator": "Измерение тока и времени срабатывания расцепителей",
        "nd_item": MVI_BY_NUM[7]["nd_item"],
        "method_no": "МВИ-ЭТЛ-07-2027 (Методика № 7)",
        "nd_val": "B: 3–5·Iн; C: 5–10·Iн; D: 10–20·Iн (ГОСТ IEC 60898-1-2020); tоткл ≤ 0,2 с (380 В)",
        "nd_tol": "Согласно требованиям ГОСТ IEC 60898-1-2020 и заводским данным",
    },
    "motor": {
        "title": "Измерение параметров электродвигателей",
        "mii": _mvi_mii(22),
        "nd": MVI_BY_NUM[22]["nd"],
        "indicator": "Измерение сопротивления изоляции, Кабс и сопротивления обмоток",
        "nd_item": MVI_BY_NUM[22]["nd_item"],
        "method_no": "МВИ-ЭТЛ-22-2027 (Методика № 22)",
        "nd_val": "Rиз ≥ 0,5 МОм (до 1 кВ); Кабс ≥ 1,3; разброс Rобм ≤ 2 %",
        "nd_tol": "Согласно требованиям ПУЭ п. 1.8.15 и завода-изготовителя",
    },
    "continuity": {
        "title": "Проверка наличия цепи между заземлителями и заземленными элементами",
        "mii": _mvi_mii(5),
        "nd": MVI_BY_NUM[5]["nd"],
        "indicator": "Проверка непрерывности защитных проводников и качества контактных соединений",
        "nd_item": MVI_BY_NUM[5]["nd_item"],
        "method_no": "МВИ-ЭТЛ-05-2027 (Методика № 5)",
        "nd_val": "Наличие непрерывной цепи (ток ≥ 0,2 А); Rпереход. ≤ 0,05 Ом (рекомендуемое до 0,1 Ом)",
        "nd_tol": "Согласно требованиям ПУЭ п. 1.8.39 (п. 2) и ГОСТ Р 50571.16-2019",
    },
    "grounding": {
        "title": "Измерение сопротивления заземляющего устройства",
        "mii": _mvi_mii(4),
        "nd": MVI_BY_NUM[4]["nd"],
        "indicator": "Измерение сопротивления заземляющих устройств (с учётом сезонного коэффициента)",
        "nd_item": MVI_BY_NUM[4]["nd_item"],
        "method_no": "МВИ-ЭТЛ-04-2027 (Методика № 4)",
        "nd_val": "Не более 4 Ом (сети 380/220 В TN) / 10 Ом (3–35 кВ) / 30 Ом (опоры ВЛ)",
        "nd_tol": "Согласно ПУЭ табл. 1.8.38 и проектной документации",
    },
    "opn": {
        "title": "Испытания ограничителей перенапряжения",
        "mii": _mvi_mii(20),
        "nd": MVI_BY_NUM[20]["nd"],
        "indicator": "Сопротивление изоляции и ток проводимости вентильных разрядников и ОПН",
        "nd_item": MVI_BY_NUM[20]["nd_item"],
        "method_no": "МВИ-ЭТЛ-20-2027 (Методика № 20)",
        "nd_val": "Rиз ≥ 1000 МОм (1000 В при U < 3 кВ; 2500 В при U ≥ 3 кВ); Iпров — по данным завода",
        "nd_tol": "Согласно ГОСТ Р 52725-2021 и данным завода-изготовителя",
    },
    "transformer": {
        "title": "Испытание трансформатора собственных нужд (ТСН) / силового трансформатора",
        "mii": _mvi_mii(9),
        "nd": MVI_BY_NUM[9]["nd"],
        "indicator": "Сопротивление изоляции обмоток, Кабс, Rобм постоянному току и Kтр",
        "nd_item": MVI_BY_NUM[9]["nd_item"],
        "method_no": "МВИ-ЭТЛ-09-2027 (Методика № 9)",
        "nd_val": "Rиз ≥ 450 МОм (10 °C) / ≥ 300 МОм (20 °C); Кабс ≥ 1,3; несимметрия Rобм ≤ 2 %",
        "nd_tol": "Согласно ПУЭ табл. 1.8.9–1.8.12 и ГОСТ Р 52719-2007",
    },
    "disconnector": {
        "title": "Испытания разъединителя",
        "mii": _mvi_mii(16),
        "nd": MVI_BY_NUM[16]["nd"],
        "indicator": "Сопротивление изоляции (орг. части / вторичные цепи) и контактной системы",
        "nd_item": MVI_BY_NUM[16]["nd_item"],
        "method_no": "МВИ-ЭТЛ-16-2027 (Методика № 16)",
        "nd_val": "Rиз ≥ 1000 МОм (ввод) / ≥ 300 МОм (экспл.) при 2500 В; Rконт ≤ 175 мкОм (630 А)",
        "nd_tol": "В пределах норм ПУЭ п. 1.8.24, ГОСТ Р 52726-2007 и СТО 34.01-23.1-001-2017",
    },
    "insulation": {
        "title": "Измерение сопротивления изоляции",
        "mii": _mvi_mii(2),
        "nd": MVI_BY_NUM[2]["nd"],
        "indicator": "Измерение сопротивления изоляции электрооборудования, аппаратов, вторичных цепей и электропроводок",
        "nd_item": MVI_BY_NUM[2]["nd_item"],
        "method_no": "МВИ-ЭТЛ-02-2027 (Методика № 2)",
        "nd_val": "Не менее 0,5 МОм (ПУЭ) / 1,0 МОм (ГОСТ Р 50571.16-2019) при Uисп = 500–1000 В",
        "nd_tol": "Согласно требованиям ПУЭ табл. 1.8.34 и ГОСТ Р 50571.16-2019",
    },
    "loop": {
        "title": "Измерение сопротивления петли «фаза-нуль» и проверки ОТКЗ",
        "mii": _mvi_mii(6),
        "nd": MVI_BY_NUM[6]["nd"],
        "indicator": "Полное сопротивление петли «фаза-нуль» и ток однофазного короткого замыкания",
        "nd_item": MVI_BY_NUM[6]["nd_item"],
        "method_no": "МВИ-ЭТЛ-06-2027 (Методика № 6)",
        "nd_val": "tоткл ≤ 0,4 с (220 В) / ≤ 0,2 с (380 В) / ≤ 5 с (распред. щиты); Iкз ≥ 1,1·Iуст",
        "nd_tol": "Согласно требованиям ПУЭ п. 1.7.79 (табл. 1.7.1) и ГОСТ Р 50571.4.41-2022",
    },
    "hv_test": {
        "title": "Высоковольтные испытания повышенным напряжением (ВВИ)",
        "mii": _mvi_mii(1),
        "nd": MVI_BY_NUM[1]["nd"],
        "indicator": "Испытание силовых кабельных линий и электрооборудования повышенным напряжением (ВВИ)",
        "nd_item": MVI_BY_NUM[1]["nd_item"],
        "method_no": "МВИ-ЭТЛ-01-2027 (Методика № 1)",
        "nd_val": "Отсутствие пробоя и перекрытия; ток утечки и коэффициент асимметрии в пределах нормы",
        "nd_tol": "Согласно ПУЭ п. 1.8.40 (табл. 1.8.39) и РД 34.45-51.300-97 (разд. 29)",
    },
    "rcd": {
        "title": "Проверка устройств защитного отключения (УЗО / АВДТ)",
        "mii": _mvi_mii(8),
        "nd": MVI_BY_NUM[8]["nd"],
        "indicator": "Дифференциальный ток и время срабатывания УЗО / ВДТ / АВДТ",
        "nd_item": MVI_BY_NUM[8]["nd_item"],
        "method_no": "МВИ-ЭТЛ-08-2027 (Методика № 8)",
        "nd_val": "0,5·IΔn < IΔ ≤ IΔn; tоткл ≤ 0,3 с (IΔn) / ≤ 0,15 с (2·IΔn) / ≤ 0,04 с (5·IΔn)",
        "nd_tol": "Согласно ГОСТ IEC 61008-1-2020, ГОСТ IEC 61009-1-2020 и ГОСТ Р 50571.16-2019",
    },
    "rzia": {
        "title": "Проверка устройств релейной защиты и автоматики (РЗиА)",
        "mii": "Правилами технической эксплуатации электроустановок потребителей (ПТЭЭП № 811), ПУЭ гл. 1.8 и картами уставок РЗиА.",
        "nd": "ПТЭЭП (Приказ Минэнерго России от 12.08.2022 № 811), ПУЭ (7-е изд., гл. 1.8), ПОТЭЭ № 903н (ред. № 279н), карты уставок РЗиА, ФЗ № 102-ФЗ (ФГИС «АРШИН»).",
        "indicator": "Проверка уставок тока, напряжения и времени срабатывания устройств РЗиА",
        "nd_item": "ПТЭЭП № 811; ПУЭ гл. 1.8; карты уставок РЗиА",
        "method_no": "ПТЭЭП № 811 / Карты уставок РЗиА",
        "nd_val": "Согласно утверждённой карте уставок РЗиА",
        "nd_tol": "В пределах класса точности реле и заводской документации",
    },
    "dc_resistance": {
        "title": "измерения сопротивления постоянному току обмоток, контактов и токоведущих соединений",
        "mii": _mvi_mii(3),
        "nd": MVI_BY_NUM[3]["nd"],
        "indicator": "Сопротивление постоянному току обмоток, контактов и болтовых соединений",
        "nd_item": MVI_BY_NUM[3]["nd_item"],
        "method_no": "МВИ-ЭТЛ-03-2027 (Методика № 3)",
        "nd_val": "Разброс по фазам ≤ 2 %; контактные соединения — по паспорту завода-изготовителя",
        "nd_tol": "Согласно ПУЭ гл. 1.8 и ГОСТ 3484.1-88",
    },
    "ct": {
        "title": "испытаний измерительных трансформаторов тока напряжением до 10 кВ",
        "mii": _mvi_mii(10),
        "nd": MVI_BY_NUM[10]["nd"],
        "indicator": "Сопротивление изоляции, Rобм, коэффициент трансформации, ВАХ и ВВИ трансформаторов тока",
        "nd_item": MVI_BY_NUM[10]["nd_item"],
        "method_no": "МВИ-ЭТЛ-10-2027 (Методика № 10)",
        "nd_val": "Rиз перв. ≥ 1000 МОм (2500 В); втор. ≥ 1 МОм (1000 В); ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.17 и ГОСТ 7746-2015",
    },
    "vt": {
        "title": "испытаний измерительных трансформаторов напряжения до 10 кВ",
        "mii": _mvi_mii(11),
        "nd": MVI_BY_NUM[11]["nd"],
        "indicator": "Сопротивление изоляции, Rобм, коэффициент трансформации и ВВИ трансформаторов напряжения",
        "nd_item": MVI_BY_NUM[11]["nd_item"],
        "method_no": "МВИ-ЭТЛ-11-2027 (Методика № 11)",
        "nd_val": "Rиз перв. ≥ 1000 МОм (2500 В); втор. ≥ 1 МОм (1000 В); ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.18 и ГОСТ 1983-2015",
    },
    "cb_oil": {
        "title": "испытаний масляных выключателей напряжением до 10 кВ",
        "mii": _mvi_mii(12),
        "nd": MVI_BY_NUM[12]["nd"],
        "indicator": "Сопротивление изоляции, Rконт постоянному току, ВВИ и проверка привода масляных выключателей",
        "nd_item": MVI_BY_NUM[12]["nd_item"],
        "method_no": "МВИ-ЭТЛ-12-2027 (Методика № 12)",
        "nd_val": "Rиз орг. ≥ 1000 МОм (ввод) / ≥ 300 МОм (экспл.); втор. ≥ 1 МОм; ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.19 и ГОСТ Р 52565-2006",
    },
    "cb_sf6": {
        "title": "испытаний элегазовых выключателей напряжением до 10 кВ",
        "mii": _mvi_mii(13),
        "nd": MVI_BY_NUM[13]["nd"],
        "indicator": "Сопротивление изоляции, Rконт постоянному току, ВВИ и проверка привода элегазовых выключателей",
        "nd_item": MVI_BY_NUM[13]["nd_item"],
        "method_no": "МВИ-ЭТЛ-13-2027 (Методика № 13)",
        "nd_val": "Rиз орг. ≥ 1000 МОм (ввод) / ≥ 300 МОм (экспл.); втор. ≥ 1 МОм; ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.21 и ГОСТ Р 52565-2006",
    },
    "cb_air": {
        "title": "испытаний воздушных выключателей напряжением до 10 кВ",
        "mii": _mvi_mii(14),
        "nd": MVI_BY_NUM[14]["nd"],
        "indicator": "Сопротивление изоляции, Rконт постоянному току, ВВИ и проверка привода воздушных выключателей",
        "nd_item": MVI_BY_NUM[14]["nd_item"],
        "method_no": "МВИ-ЭТЛ-14-2027 (Методика № 14)",
        "nd_val": "Rиз орг. ≥ 1000 МОм (ввод) / ≥ 300 МОм (экспл.); втор. ≥ 1 МОм; ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.20 и ГОСТ Р 52565-2006",
    },
    "load_switch": {
        "title": "испытаний выключателей нагрузки напряжением до 10 кВ",
        "mii": _mvi_mii(15),
        "nd": MVI_BY_NUM[15]["nd"],
        "indicator": "Сопротивление изоляции, Rконт постоянному току, ВВИ и проверка привода выключателей нагрузки",
        "nd_item": MVI_BY_NUM[15]["nd_item"],
        "method_no": "МВИ-ЭТЛ-15-2027 (Методика № 15)",
        "nd_val": "Rиз орг. ≥ 1000 МОм (ввод) / ≥ 300 МОм (экспл.); втор. ≥ 1 МОм; ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.23 и ГОСТ 17717-79 / ГОСТ Р 52565-2006",
    },
    "cb_vacuum": {
        "title": "испытаний вакуумных выключателей напряжением до 10 кВ",
        "mii": _mvi_mii(23),
        "nd": MVI_BY_NUM[23]["nd"],
        "indicator": "Сопротивление изоляции, Rконт постоянному току, ВВИ дугогасительных камер и проверка привода",
        "nd_item": MVI_BY_NUM[23]["nd_item"],
        "method_no": "МВИ-ЭТЛ-23-2027 (Методика № 23)",
        "nd_val": "Rиз орг. ≥ 1000 МОм (ввод) / ≥ 300 МОм (экспл.); втор. ≥ 1 МОм; ВВИ камер без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.22 и ГОСТ Р 52565-2006",
    },
    "kru": {
        "title": "испытаний комплектных распределительных устройств (КРУ и КРУН) до 10 кВ",
        "mii": _mvi_mii(17),
        "nd": MVI_BY_NUM[17]["nd"],
        "indicator": "Сопротивление опорной/проходной изоляции, Rконт и ВВИ ячеек КРУ и КРУН",
        "nd_item": MVI_BY_NUM[17]["nd_item"],
        "method_no": "МВИ-ЭТЛ-17-2027 (Методика № 17)",
        "nd_val": "Опорная ≥ 300 МОм, проходная ≥ 1000 МОм (2500 В); ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.25 и ГОСТ 14693-90",
    },
    "busduct": {
        "title": "испытаний комплектных токопроводов и шинопроводов напряжением до 10 кВ",
        "mii": _mvi_mii(18),
        "nd": MVI_BY_NUM[18]["nd"],
        "indicator": "Сопротивление изоляции, контроль соединений и ВВИ токопроводов и шинопроводов",
        "nd_item": MVI_BY_NUM[18]["nd_item"],
        "method_no": "МВИ-ЭТЛ-18-2027 (Методика № 18)",
        "nd_val": "Опорная ≥ 300 МОм, проходная ≥ 1000 МОм (2500 В); ВВИ 6 кВ: 32/28,8 кВ; 10 кВ: 42/37,8 кВ",
        "nd_tol": "Согласно ПУЭ п. 1.8.26 и ГОСТ IEC 61439-6-2017",
    },
    "insulators_bus": {
        "title": "испытаний вводов, опорных, подвесных и проходных изоляторов, сборных и соединительных шин до 10 кВ",
        "mii": _mvi_mii(19),
        "nd": MVI_BY_NUM[19]["nd"],
        "indicator": "Сопротивление изоляции, контроль контактных соединений и ВВИ изоляторов и сборных шин",
        "nd_item": MVI_BY_NUM[19]["nd_item"],
        "method_no": "МВИ-ЭТЛ-19-2027 (Методика № 19)",
        "nd_val": "Опорные ≥ 300 МОм, проходные ≥ 1000 МОм (2500 В); ВВИ без пробоя",
        "nd_tol": "Согласно ПУЭ п. 1.8.27, 1.8.34, 1.8.35 и ГОСТ 1516.3-96",
    },
    "hv_fuse": {
        "title": "испытаний предохранителей и предохранителей-разъединителей напряжением до 10 кВ",
        "mii": _mvi_mii(21),
        "nd": MVI_BY_NUM[21]["nd"],
        "indicator": "Сопротивление изоляции, целостность плавких вставок и ВВИ предохранителей до 10 кВ",
        "nd_item": MVI_BY_NUM[21]["nd_item"],
        "method_no": "МВИ-ЭТЛ-21-2027 (Методика № 21)",
        "nd_val": "Опорные ≥ 300 МОм, проходные ≥ 1000 МОм (2500 В); ВВИ (фарфор 1 мин / органика 5 мин)",
        "nd_tol": "Согласно ПУЭ п. 1.8.33 и ГОСТ Р МЭК 60282-1-2011",
    },
    "ohl": {
        "title": "испытаний и измерений на воздушных линиях электропередачи напряжением выше 1 кВ (до 10 кВ)",
        "mii": _mvi_mii(24),
        "nd": MVI_BY_NUM[24]["nd"],
        "indicator": "Сопротивление изоляции опорных изоляторов, проверка соединений и ВВИ на ВЛ выше 1 кВ",
        "nd_item": MVI_BY_NUM[24]["nd_item"],
        "method_no": "МВИ-ЭТЛ-24-2027 (Методика № 24)",
        "nd_val": "Опорные изоляторы ≥ 300 МОм (2500 В); ВВИ без пробоя и перекрытия",
        "nd_tol": "Согласно ПУЭ п. 1.8.41, гл. 2.5 и СТО 34.01-23.1-001-2017 (разд. 31)",
    },
}

def fmt_ru_date(iso: str | None) -> str:
    if not iso or iso == "—":
        return "—"
    parts = str(iso).split("-")
    return f"{parts[2]}.{parts[1]}.{parts[0]}" if len(parts) == 3 else str(iso)


def fmt_formal_date(iso: str | None) -> str:
    if not iso or iso == "—":
        return "«___» ____________ 2026 г."
    parts = str(iso).split("-")
    if len(parts) != 3:
        return str(iso)
    idx = max(0, min(11, int(parts[1]) - 1))
    return f"«{parts[2]}» {MONTHS_GEN[idx]} {parts[0]} г."


def _add_word_field(paragraph: Any, field_name: str, font_size: float = 9.5) -> None:
    run = paragraph.add_run()
    run.font.name = "Times New Roman"
    run.font.size = Pt(font_size)
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = f" {field_name} "
    fld_sep = OxmlElement("w:fldChar")
    fld_sep.set(qn("w:fldCharType"), "separate")
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_sep)
    run._r.append(fld_end)


def _enable_word_footer_numbering(doc: Document) -> None:
    sec = doc.sections[0]
    sec.footer_distance = Cm(0.5)
    footer = sec.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    r1 = p.add_run("Стр. ")
    r1.font.name = "Times New Roman"
    r1.font.size = Pt(9.5)
    _add_word_field(p, "PAGE", 9.5)
    r2 = p.add_run(" из ")
    r2.font.name = "Times New Roman"
    r2.font.size = Pt(9.5)
    _add_word_field(p, "NUMPAGES", 9.5)


def _setup_doc(use_word_footer: bool = False) -> Document:
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(1.0)
    sec.bottom_margin = Cm(1.2 if use_word_footer else 1.0)
    sec.left_margin = Cm(2.0)
    sec.right_margin = Cm(1.5)
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(12)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(2)
    normal.paragraph_format.line_spacing = 1.15
    if use_word_footer:
        _enable_word_footer_numbering(doc)
    return doc


def _set_table_borders(table: Any, visible: bool = True) -> None:
    if visible:
        try:
            table.style = "Table Grid"
        except Exception:
            pass
    tbl_pr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    val = "single" if visible else "none"
    for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:val"), val)
        if visible:
            el.set(qn("w:sz"), "4")
            el.set(qn("w:space"), "0")
            el.set(qn("w:color"), "000000")
        borders.append(el)
    tbl_pr.append(borders)


def _cell_text(cell: Any, text: Any, size: float = 10, bold: bool = False, align: Any = WD_ALIGN_PARAGRAPH.CENTER) -> None:
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    p = cell.paragraphs[0]
    p.alignment = align
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.space_after = Pt(1)
    run = p.add_run(str(text if text not in (None, "") else "—"))
    run.font.name = "Times New Roman"
    run.font.size = Pt(size)
    run.bold = bold


def _add_p(doc: Document, text: str = "", size: float = 12, bold: bool = False, align: Any = WD_ALIGN_PARAGRAPH.LEFT, underline: bool = False, space_before: float = 0, space_after: float = 2, keep_with_next: bool = False) -> Any:
    p = doc.add_paragraph()
    p.alignment = align
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if keep_with_next:
        p.paragraph_format.keep_with_next = True
    if text:
        r = p.add_run(text)
        r.font.name = "Times New Roman"
        r.font.size = Pt(size)
        r.bold = bold
        r.underline = underline
    return p


def _cm_to_dxa(cm_val: float) -> int:
    return int(round(cm_val * 566.929))


def _set_table_cell_margins(table: Any, top: int = 30, bottom: int = 30, left: int = 55, right: int = 55) -> None:
    tbl_pr = table._tbl.tblPr
    for old in tbl_pr.findall(qn("w:tblCellMar")):
        tbl_pr.remove(old)
    mar = OxmlElement("w:tblCellMar")
    for side, val in (("top", top), ("bottom", bottom), ("left", left), ("right", right)):
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:w"), str(val))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tbl_pr.append(mar)


def _set_row_header(row: Any) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    if tr_pr.find(qn("w:tblHeader")) is None:
        tr_pr.append(OxmlElement("w:tblHeader"))


def _set_row_cant_split(row: Any) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    if tr_pr.find(qn("w:cantSplit")) is None:
        tr_pr.append(OxmlElement("w:cantSplit"))


def _set_col_widths(table: Any, widths_cm: list[float]) -> None:
    """Жёстко фиксирует ширины колонок для Microsoft Word (tblLayout=fixed + tblGrid + tcW)."""
    table.autofit = False
    dxa_widths = [_cm_to_dxa(w) for w in widths_cm]
    total_dxa = sum(dxa_widths)

    tbl_pr = table._tbl.tblPr
    for tag in ("w:tblW", "w:tblLayout"):
        for old in tbl_pr.findall(qn(tag)):
            tbl_pr.remove(old)
    tbl_w = OxmlElement("w:tblW")
    tbl_w.set(qn("w:w"), str(total_dxa))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_pr.append(tbl_w)

    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tbl_pr.append(layout)

    # Обновляем tblGrid
    tbl_grid = table._tbl.tblGrid
    if tbl_grid is not None:
        for gc in list(tbl_grid.findall(qn("w:gridCol"))):
            tbl_grid.remove(gc)
        for w_dxa in dxa_widths:
            gc = OxmlElement("w:gridCol")
            gc.set(qn("w:w"), str(w_dxa))
            tbl_grid.append(gc)

    # Проставляем w:tcW и запрет разрыва строки (cantSplit) для каждой строки
    for row_obj in table.rows:
        _set_row_cant_split(row_obj)
    for tr in table._tbl.findall(qn("w:tr")):
        col_cursor = 0
        for tc in tr.findall(qn("w:tc")):
            tc_pr = tc.get_or_add_tcPr()
            span_el = tc_pr.find(qn("w:gridSpan"))
            span = int(span_el.get(qn("w:val"))) if span_el is not None else 1
            cell_dxa = sum(dxa_widths[col_cursor:col_cursor + span]) if col_cursor < len(dxa_widths) else dxa_widths[-1]
            for old_w in tc_pr.findall(qn("w:tcW")):
                tc_pr.remove(old_w)
            tc_w = OxmlElement("w:tcW")
            tc_w.set(qn("w:w"), str(cell_dxa))
            tc_w.set(qn("w:type"), "dxa")
            tc_pr.append(tc_w)
            col_cursor += span


def _build_two_level_table(
    doc: Document,
    col_specs: list[tuple[str, list[str] | None]],
    size: float = 9.0,
) -> Any:
    """Создает таблицу с 2-уровневой объединённой шапкой.

    col_specs: список элементов (Заголовок, None) для одиночной колонки (merge по вертикали)
               или (Общий заголовок, [Подзаголовок1, Подзаголовок2, ...]) для объединённой группы.
    """
    total_cols = sum(1 if sub is None else len(sub) for _, sub in col_specs)
    tbl = doc.add_table(rows=2, cols=total_cols)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    _set_table_borders(tbl, visible=True)

    c = 0
    for title, subs in col_specs:
        if subs is None:
            tbl.cell(0, c).merge(tbl.cell(1, c))
            _cell_text(tbl.cell(0, c), title, size=size, bold=True)
            c += 1
        else:
            span = len(subs)
            if span > 1:
                tbl.cell(0, c).merge(tbl.cell(0, c + span - 1))
            _cell_text(tbl.cell(0, c), title, size=size, bold=True)
            for j, sub_title in enumerate(subs):
                _cell_text(tbl.cell(1, c + j), sub_title, size=size - 0.5, bold=True)
            c += span
    _set_row_header(tbl.rows[0])
    _set_row_header(tbl.rows[1])
    _set_table_cell_margins(tbl, top=24, bottom=24, left=42, right=42)
    return tbl


def _add_footer_stamp(doc: Document, proto_num: str, sheet_idx: int, total_sheets: int, page_num: int, dynamic_pages: bool = False) -> None:
    _add_p(doc, "", size=6, space_before=6, space_after=2)
    tbl = doc.add_table(rows=1, cols=5)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    _set_table_borders(tbl, visible=False)
    cells = tbl.rows[0].cells
    _cell_text(cells[0], "М.П.", size=10.5, align=WD_ALIGN_PARAGRAPH.LEFT)

    if dynamic_pages:
        specs = [("Протокол № " + str(proto_num), None), ("лист ", "PAGE"), ("листов ", "NUMPAGES"), ("стр. № ", "PAGE")]
        for i, (prefix, fld) in enumerate(specs, start=1):
            cells[i].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p_c = cells[i].paragraphs[0]
            p_c.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_c.paragraph_format.space_before = Pt(1)
            p_c.paragraph_format.space_after = Pt(1)
            r_pre = p_c.add_run(prefix)
            r_pre.font.name = "Times New Roman"
            r_pre.font.size = Pt(10.5)
            if fld:
                _add_word_field(p_c, fld, 10.5)
    else:
        labels = [f"Протокол № {proto_num}", f"лист {sheet_idx}", f"листов {total_sheets}", f"стр. № {page_num}"]
        for i, lbl in enumerate(labels, start=1):
            _cell_text(cells[i], lbl, size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER)

    for i in range(1, 5):
        tc_pr = cells[i]._tc.get_or_add_tcPr()
        tc_borders = OxmlElement("w:tcBorders")
        for side in ("top", "left", "bottom", "right"):
            el = OxmlElement(f"w:{side}")
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), "4")
            el.set(qn("w:color"), "000000")
            tc_borders.append(el)
        tc_pr.append(tc_borders)
    _set_col_widths(tbl, [3.1, 4.4, 3.2, 3.4, 3.4])


def _to_float(val: Any) -> float | None:
    try:
        s = str(val or "").replace(",", ".").strip()
        return float(s) if s else None
    except ValueError:
        return None


def _add_measurements_table(doc: Document, ptype: str, rows: list[dict[str, Any]]) -> None:
    if _add_extra_measurements_table(doc, ptype, rows):
        return
    if ptype == "breaker_1p":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Наименование присоединения", None),
                ("Тип АВ", None),
                ("Iн, А", None),
                ("Тепловой расцепитель", ["Iуст, А", "Iср, А", "tср, с"]),
                ("Электромагнитный расцепитель", ["Iуст, А", "Iср, А", "tср, с"]),
            ],
            size=8.5,
        )
        last_panel = ""
        seq = 0
        col_w = [0.8, 4.8, 1.7, 0.9, 1.5, 1.5, 1.4, 1.6, 1.6, 1.7]
        for r in rows:
            panel = str(r.get("panel") or "").strip()
            if panel and panel != last_panel:
                last_panel = panel
                gr = tbl.add_row()
                gr.cells[0].merge(gr.cells[-1])
                _cell_text(gr.cells[0], panel, size=9.5, bold=True)
            seq += 1
            dr = tbl.add_row().cells
            vals = [seq, r.get("line"), r.get("abType"), r.get("inVal"), r.get("thSet"), r.get("thTrip"), r.get("thTime"), r.get("emSet"), r.get("emTrip"), r.get("emTime")]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=8.5, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, col_w)
        return

    if ptype == "breaker_3p":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Наименование присоединения", None),
                ("Тип АВ", None),
                ("Iн, А", None),
                ("Тепловой расцепитель", ["Iуст, А", "tср (A/B/C), с"]),
                ("Электромагнитный расцепитель", ["Iуст, А", "Iср (A/B/C), А", "tср, с"]),
                ("Заключение", None),
            ],
            size=8.5,
        )
        last_panel = ""
        seq = 0
        col_w = [0.8, 4.6, 1.6, 0.9, 1.3, 1.8, 1.3, 2.0, 1.2, 2.0]
        for r in rows:
            panel = str(r.get("panel") or "").strip()
            if panel and panel != last_panel:
                last_panel = panel
                gr = tbl.add_row()
                _set_row_cant_split(gr)
                gr.cells[0].merge(gr.cells[-1])
                _cell_text(gr.cells[0], panel, size=9.0, bold=True)
            seq += 1
            row_obj = tbl.add_row()
            _set_row_cant_split(row_obj)
            dr = row_obj.cells
            em_t = _to_float(r.get("emTime"))
            em_s = _to_float(r.get("emSet"))
            trips = [x for x in (_to_float(p) for p in str(r.get("emTrips") or "").split("/")) if x is not None]
            if em_t is None and not trips:
                verdict = "—"
            else:
                t_ok = True if em_t is None else (em_t <= 0.4)
                i_ok = True if (not trips or em_s in (None, 0)) else all(abs(v - em_s) / em_s <= 0.2 for v in trips)
                verdict = "Соотв." if (t_ok and i_ok) else "Не соотв."
            vals = [seq, r.get("line"), r.get("abType"), r.get("inVal"), r.get("thSet"), r.get("thTimes"), r.get("emSet"), r.get("emTrips"), r.get("emTime"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=8.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, col_w)
        return

    if ptype == "motor":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Наименование присоединения", None),
                ("Тип ЭД", None),
                ("Сопротивление изоляции обмоток, МОм", ["Фаза A-N", "Фаза B-N", "Фаза C-N"]),
                ("Kабс", None),
                ("Вывод", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            vals_num = [x for x in (_to_float(r.get("rA")), _to_float(r.get("rB")), _to_float(r.get("rC"))) if x is not None]
            norm = _to_float(r.get("norm")) or 0.5
            verdict = "—" if not vals_num else ("Соотв." if min(vals_num) >= norm else "Не соотв.")
            vals = [idx, r.get("line"), r.get("edType"), r.get("rA"), r.get("rB"), r.get("rC"), r.get("kabs"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.2, 2.5, 1.8, 1.8, 1.8, 1.5, 2.0])
        return

    if ptype == "continuity":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Наименование заземляемого элемента", None),
                ("Характеристика проводника", None),
                ("Результаты измерений", ["Rконт, Ом", "Погр., %", "Норма, Ом"]),
                ("Заключение", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            rv = _to_float(r.get("rVal"))
            nv = _to_float(r.get("norm")) or 0.05
            verdict = "—" if rv is None else ("Соотв." if rv <= nv else "Не соотв.")
            vals = [idx, r.get("line"), r.get("conductor"), r.get("rVal"), r.get("err", "2,5"), r.get("norm", "0.05"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.5, 3.0, 2.1, 1.9, 2.1, 2.0])
        return

    if ptype == "grounding":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Принадлежность заземляющего устройства", None),
                ("Результаты измерений ЗУ", ["Rизм, Ом", "Ксез", "Rприв, Ом", "Норма, Ом", "Погр., %"]),
                ("Вывод", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            rm = _to_float(r.get("rMeas"))
            ks = _to_float(r.get("kSez")) or 1.0
            nm = _to_float(r.get("norm")) or 10.0
            r_priv = f"{rm * ks:.2f}" if rm is not None else "—"
            verdict = "—" if rm is None else ("соответствует" if rm * ks <= nm else "не соответствует")
            vals = [idx, r.get("line"), r.get("rMeas"), r.get("kSez", "1"), r_priv, r.get("norm", "10"), r.get("err", "5"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.1, 1.9, 1.5, 1.9, 1.9, 1.8, 2.5])
        return

    if ptype == "opn":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Место установки ОПН", None),
                ("Фаза", None),
                ("Результаты испытаний ОПН", ["Uисп, кВ", "Rиз, МОм", "Iпров, мкА", "Норма Rиз, МОм"]),
                ("Заключение", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            rz = _to_float(r.get("rIz"))
            nr = _to_float(r.get("normR")) or 1000.0
            verdict = "—" if rz is None else ("Соотв." if rz >= nr else "Не соотв.")
            vals = [idx, r.get("line"), r.get("phase"), r.get("uisp"), r.get("rIz"), r.get("iCond", "—"), r.get("normR", "1000"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 4.8, 1.3, 1.9, 2.2, 2.0, 2.4, 2.0])
        return

    if ptype == "transformer":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Параметр / схема измерения (ТСН / ТМ)", None),
                ("Результаты испытаний", ["Измерено", "Ед. изм.", "Норма"]),
                ("Заключение", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            mv = _to_float(r.get("meas"))
            nv = _to_float(r.get("norm"))
            cond = r.get("cond") or "gte"
            if mv is None or nv is None:
                verdict = "—"
            else:
                ok = (mv >= nv) if cond == "gte" else ((mv <= nv) if cond == "lte" else (nv != 0 and abs((mv - nv) / nv) * 100 <= 2))
                verdict = "Соотв." if ok else "Не соотв."
            vals = [idx, r.get("line"), r.get("meas"), r.get("unit", "МОм"), r.get("norm"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 7.6, 2.4, 2.0, 2.4, 2.2])
        return

    if ptype == "disconnector":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Наименование / зав. №", None),
                ("Фаза", None),
                ("Изоляция", ["Rиз, МОм"]),
                ("Контактная система", ["Rкс, мкОм", "Rцд, мкОм", "Rкс/Rцд", "Норма, мкОм"]),
                ("Заключение", None),
            ],
            size=8.5,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            r_iz = _to_float(r.get("rIz"))
            r_ks = _to_float(r.get("rKs"))
            r_cd = _to_float(r.get("rCd"))
            n_r = _to_float(r.get("normR")) or 175.0
            ratio = (r_ks / r_cd) if (r_ks is not None and r_cd not in (None, 0)) else None
            ratio_s = f"{ratio:.2f}" if ratio is not None else "—"
            if r_iz is None and ratio is None:
                verdict = "—"
            else:
                ok = (r_iz is None or r_iz >= 300) and (r_ks is None or r_ks <= n_r) and (ratio is None or ratio <= 1.25)
                verdict = "Соотв." if ok else "Не соотв."
            vals = [idx, r.get("line"), r.get("phase"), r.get("rIz"), r.get("rKs"), r.get("rCd"), ratio_s, r.get("normR", "175"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=8.5, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.8, 4.4, 1.1, 1.9, 1.8, 1.8, 1.8, 1.9, 2.0])
        return

    if ptype == "insulation":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Наименование линии / цепи", None),
                ("Uисп, В", None),
                ("Сопротивление изоляции", ["R15, МОм", "R60, МОм", "Kабс", "Норма, МОм"]),
                ("Заключение", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            r15 = _to_float(r.get("r15"))
            r60 = _to_float(r.get("r60"))
            nm = _to_float(r.get("norm")) or 0.5
            kabs = f"{r60 / r15:.2f}" if (r60 is not None and r15 not in (None, 0)) else "—"
            verdict = "—" if r60 is None else ("Соотв." if r60 >= nm else "Не соотв.")
            vals = [idx, r.get("line"), r.get("uisp", "1000"), r.get("r15"), r.get("r60"), kabs, r.get("norm", "0.5"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.5, 1.7, 1.9, 1.9, 1.6, 2.0, 2.0])
        return

    if ptype == "loop":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Наименование линии / аппарата", None),
                ("Защитный аппарат", ["Iн, А", "Хар."]),
                ("Петля «фаза-нуль»", ["Zп, Ом", "Iкз, А", "Iмин, А"]),
                ("Заключение", None),
            ],
            size=9.0,
        )
        k_map = {"B": 5.0, "C": 10.0, "D": 20.0}
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            zp = _to_float(r.get("zLoop"))
            in_v = _to_float(r.get("inVal"))
            curve = str(r.get("curve") or "C").upper()
            ikz = (230.0 / zp) if (zp not in (None, 0)) else None
            imin = (1.1 * k_map.get(curve, 10.0) * in_v) if in_v is not None else None
            verdict = "—" if (ikz is None or imin is None) else ("Соотв." if ikz >= imin else "Не соотв.")
            vals = [idx, r.get("line"), r.get("inVal"), curve, r.get("zLoop"), f"{ikz:.0f}" if ikz else "—", f"{imin:.0f}" if imin else "—", verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.4, 1.5, 1.4, 2.0, 2.1, 2.1, 2.1])
        return

    if ptype == "hv_test":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Оборудование / жила КЛ", None),
                ("Режим ВВИ", ["Uисп, кВ", "t, мин"]),
                ("Контроль изоляции", ["Iут, мА", "Норма, мА", "Пробой"]),
                ("Заключение", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            iut = _to_float(r.get("iLeak"))
            nm = _to_float(r.get("normLeak"))
            br = str(r.get("breakdown") or "Нет").strip()
            verdict = "—" if iut is None else ("Соотв." if (br.lower() != "да" and (nm is None or iut <= nm)) else "Не соотв.")
            vals = [idx, r.get("line"), r.get("uTest"), r.get("duration"), r.get("iLeak"), r.get("normLeak"), br, verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.1, 1.9, 1.6, 2.0, 2.0, 1.9, 2.1])
        return

    if ptype == "rcd":
        tbl = _build_two_level_table(
            doc,
            [
                ("№ п/п", None),
                ("Линия / тип УЗО (АВДТ)", None),
                ("Параметры срабатывания", ["IΔn, мА", "Iср, мА", "tоткл, мс", "tмакс, мс"]),
                ("Заключение", None),
            ],
            size=9.0,
        )
        for idx, r in enumerate(rows, start=1):
            dr = tbl.add_row().cells
            idn = _to_float(r.get("idn"))
            itr = _to_float(r.get("iTrip"))
            ttr = _to_float(r.get("tTrip"))
            tmax = _to_float(r.get("tMax")) or 300.0
            if idn is None or (itr is None and ttr is None):
                verdict = "—"
            else:
                ok = (itr is None or (0.5 * idn < itr <= idn)) and (ttr is None or ttr <= tmax)
                verdict = "Соотв." if ok else "Не соотв."
            vals = [idx, r.get("line"), r.get("idn"), r.get("iTrip"), r.get("tTrip"), r.get("tMax", "300"), verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.8, 2.1, 2.1, 2.2, 2.2, 2.2])
        return

    # rzia
    tbl = _build_two_level_table(
        doc,
        [
            ("№ п/п", None),
            ("Присоединение / ступень защиты", None),
            ("Проверка уставки РЗиА", ["Уставка", "Измерено", "Допуск, %", "Откл., %"]),
            ("Заключение", None),
        ],
        size=9.0,
    )
    for idx, r in enumerate(rows, start=1):
        dr = tbl.add_row().cells
        sv = _to_float((r.get("setpoint") if r.get("setpoint") is not None else r.get("setVal")))
        mv = _to_float((r.get("measured") if r.get("measured") is not None else r.get("measVal")))
        tol = _to_float(r.get("tol")) or 5.0
        if sv in (None, 0) or mv is None:
            dev_s, verdict = "—", "—"
        else:
            dev = ((mv - sv) / sv) * 100.0
            dev_s = f"{dev:+.2f}%"
            verdict = "Соотв." if abs(dev) <= tol else "Не соотв."
        vals = [idx, r.get("line"), (r.get("setpoint") if r.get("setpoint") is not None else r.get("setVal")), (r.get("measured") if r.get("measured") is not None else r.get("measVal")), r.get("tol", "5"), dev_s, verdict]
        for i, v in enumerate(vals):
            _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
    _set_col_widths(tbl, [0.9, 5.8, 2.2, 2.2, 2.1, 2.1, 2.2])


def _add_extra_measurements_table(doc: Document, ptype: str, rows: list[dict[str, Any]]) -> bool:
    """Рендер Приложения № 2 для 13 методик 6–10 кВ и сопротивления пост. току."""
    if ptype == "dc_resistance":
        tbl = doc.add_table(rows=1, cols=7)
        _set_table_borders(tbl, visible=True)
        headers = ["№ п/п", "Наименование объекта / обмотки / узла", "Фаза / участок", "Rизм, мкОм", "Норма, мкОм", "Разброс, %", "Заключение"]
        for i, h in enumerate(headers):
            _cell_text(tbl.rows[0].cells[i], h, size=9.0, bold=True)
        for idx, r in enumerate(rows or [{}], start=1):
            dr = tbl.add_row().cells
            rv, nv, dv = _to_float(r.get("rVal")), _to_float(r.get("norm")), _to_float(r.get("diff"))
            if rv is None and dv is None:
                verdict = "—"
            else:
                ok_r = True if (rv is None or nv is None) else (rv <= nv)
                ok_d = True if dv is None else (abs(dv) <= 2.0)
                verdict = "Соотв." if (ok_r and ok_d) else "Не соотв."
            vals = [idx, r.get("line") or "—", r.get("phase") or "—", r.get("rVal") or "—", r.get("norm") or "—", r.get("diff") or "—", verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=9.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.9, 5.6, 2.2, 2.2, 2.2, 2.0, 2.4])
        return True

    if ptype in ("ct", "vt"):
        tbl = doc.add_table(rows=1, cols=8)
        _set_table_borders(tbl, visible=True)
        headers = ["№ п/п", "Ячейка / тип ТТ (ТН)", "Фаза", "Rиз перв. (2500 В), МОм", "Rиз втор. (1000 В), МОм", "Rобм / Kтр (ВАХ)", "ВВИ (кВ / мин)", "Заключение"]
        for i, h in enumerate(headers):
            _cell_text(tbl.rows[0].cells[i], h, size=8.5, bold=True)
        for idx, r in enumerate(rows or [{}], start=1):
            dr = tbl.add_row().cells
            rp, rs = _to_float(r.get("rPrim")), _to_float(r.get("rSec"))
            hv_s = str(r.get("hv") or "").strip()
            if rp is None and rs is None and not hv_s:
                verdict = "—"
            else:
                ok = (rp is None or rp >= 300.0) and (rs is None or rs >= 1.0) and ("пробой" not in hv_s.lower())
                verdict = "Соотв." if ok else "Не соотв."
            vals = [idx, r.get("line") or "—", r.get("phase") or "—", r.get("rPrim") or "—", r.get("rSec") or "—", r.get("param") or "—", hv_s or "—", verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=8.5, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.8, 4.3, 1.1, 2.3, 2.3, 2.5, 2.2, 2.0])
        return True

    if ptype in ("cb_oil", "cb_sf6", "cb_air", "load_switch", "cb_vacuum"):
        tbl = doc.add_table(rows=1, cols=9)
        _set_table_borders(tbl, visible=True)
        headers = ["№", "Ячейка / тип выключателя", "Фаза", "Rиз орг. (2500 В), МОм", "Rиз втор. (1000 В), МОм", "Rконт, мкОм", "ВВИ (кВ / мин)", "Привод", "Заключение"]
        for i, h in enumerate(headers):
            _cell_text(tbl.rows[0].cells[i], h, size=8.0, bold=True)
        for idx, r in enumerate(rows or [{}], start=1):
            dr = tbl.add_row().cells
            ro, rs = _to_float(r.get("rOrg")), _to_float(r.get("rSec"))
            hv_s, drv_s = str(r.get("hv") or "").strip(), str(r.get("drive") or "").strip()
            if ro is None and rs is None and not hv_s and not drv_s:
                verdict = "—"
            else:
                ok = (ro is None or ro >= 300.0) and (rs is None or rs >= 1.0) and ("пробой" not in hv_s.lower()) and ("отказ" not in drv_s.lower())
                verdict = "Соотв." if ok else "Не соотв."
            vals = [idx, r.get("line") or "—", r.get("phase") or "—", r.get("rOrg") or "—", r.get("rSec") or "—", r.get("rCont") or "—", hv_s or "—", drv_s or "—", verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=8.0, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.7, 3.8, 1.0, 2.1, 2.1, 1.9, 2.1, 1.9, 1.9])
        return True

    if ptype in ("kru", "busduct", "insulators_bus", "hv_fuse", "ohl"):
        tbl = doc.add_table(rows=1, cols=8)
        _set_table_borders(tbl, visible=True)
        headers = ["№ п/п", "Наименование узла / ячейки / опоры", "Тип изоляции", "Rиз (2500 В), МОм", "Норма Rиз, МОм", "Rконт / соед., мкОм", "ВВИ (кВ / мин)", "Заключение"]
        for i, h in enumerate(headers):
            _cell_text(tbl.rows[0].cells[i], h, size=8.5, bold=True)
        for idx, r in enumerate(rows or [{}], start=1):
            dr = tbl.add_row().cells
            riz, nr = _to_float(r.get("rIz")), _to_float(r.get("normR"))
            hv_s = str(r.get("hv") or "").strip()
            if riz is None and not hv_s:
                verdict = "—"
            else:
                ok = (riz is None or nr is None or riz >= nr) and ("пробой" not in hv_s.lower())
                verdict = "Соотв." if ok else "Не соотв."
            vals = [idx, r.get("line") or "—", r.get("isoType") or "—", r.get("rIz") or "—", r.get("normR") or "—", r.get("rCont") or "—", hv_s or "—", verdict]
            for i, v in enumerate(vals):
                _cell_text(dr[i], v, size=8.5, align=WD_ALIGN_PARAGRAPH.LEFT if i == 1 else WD_ALIGN_PARAGRAPH.CENTER)
        _set_col_widths(tbl, [0.8, 4.4, 2.2, 2.0, 1.9, 2.1, 2.1, 2.0])
        return True

    return False



def _eval_row_status(ptype: str, r: dict[str, Any]) -> str:
    """Единая оценка статуса строки ('PASS' | 'FAIL' | 'EMPTY'), синхронизированная с HTML."""
    if ptype == "breaker_1p":
        em_t, em_set, em_trip = _to_float(r.get("emTime")), _to_float(r.get("emSet")), _to_float(r.get("emTrip"))
        if em_t is None and em_trip is None:
            return "EMPTY"
        t_ok = True if em_t is None else em_t <= 0.4
        i_ok = True if (em_set in (None, 0) or em_trip is None) else abs(em_trip - em_set) / em_set <= 0.2
        return "PASS" if (t_ok and i_ok) else "FAIL"
    if ptype == "breaker_3p":
        em_t, em_set = _to_float(r.get("emTime")), _to_float(r.get("emSet"))
        trips = [_to_float(x) for x in str(r.get("emTrips") or "").split("/") if _to_float(x) is not None]
        if em_t is None and not trips:
            return "EMPTY"
        t_ok = True if em_t is None else em_t <= 0.4
        i_ok = True if (em_set in (None, 0) or not trips) else all(abs(x - em_set) / em_set <= 0.2 for x in trips if x is not None)
        return "PASS" if (t_ok and i_ok) else "FAIL"
    if ptype == "motor":
        vals_num = [v for v in (_to_float(r.get("rA")), _to_float(r.get("rB")), _to_float(r.get("rC"))) if v is not None]
        norm = _to_float(r.get("norm")) or 0.5
        if not vals_num:
            return "EMPTY"
        return "PASS" if min(vals_num) >= norm else "FAIL"
    if ptype == "continuity":
        rv, nv = _to_float(r.get("rVal")), _to_float(r.get("norm")) or 0.05
        if rv is None:
            return "EMPTY"
        return "PASS" if rv <= nv else "FAIL"
    if ptype == "grounding":
        rm, ks, nm = _to_float(r.get("rMeas")), _to_float(r.get("kSez")) or 1.0, _to_float(r.get("norm")) or 10.0
        if rm is None:
            return "EMPTY"
        return "PASS" if rm * ks <= nm else "FAIL"
    if ptype == "opn":
        rz, nr = _to_float(r.get("rIz")), _to_float(r.get("normR")) or 1000.0
        if rz is None:
            return "EMPTY"
        return "PASS" if rz >= nr else "FAIL"
    if ptype == "transformer":
        mv, nv, cond = _to_float(r.get("meas")), _to_float(r.get("norm")), r.get("cond") or "gte"
        if mv is None or nv is None:
            return "EMPTY"
        if cond == "gte":
            ok = mv >= nv
        elif cond == "lte":
            ok = mv <= nv
        else:
            ok = nv != 0 and abs((mv - nv) / nv) * 100.0 <= 2.0
        return "PASS" if ok else "FAIL"
    if ptype == "disconnector":
        rz, rks, rcd, nr = _to_float(r.get("rIz")), _to_float(r.get("rKs")), _to_float(r.get("rCd")), _to_float(r.get("normR")) or 175.0
        if rz is None and rks is None and rcd is None:
            return "EMPTY"
        ratio = (rks / rcd) if (rks is not None and rcd not in (None, 0)) else None
        ok = (rz is None or rz >= 300.0) and (rks is None or rks <= nr) and (ratio is None or ratio <= 1.2)
        return "PASS" if ok else "FAIL"
    if ptype == "insulation":
        r60, norm = _to_float(r.get("r60")), _to_float(r.get("norm")) or 0.5
        if r60 is None:
            return "EMPTY"
        return "PASS" if r60 >= norm else "FAIL"
    if ptype == "loop":
        in_v, curve, zv, uv = _to_float(r.get("inVal")), _to_float(r.get("curve")) or 10.0, _to_float(r.get("zVal")), _to_float(r.get("uVal")) or 230.0
        if zv in (None, 0) or in_v is None:
            return "EMPTY"
        ikz = uv / zv
        min_req = 1.1 * curve * in_v
        return "PASS" if ikz >= min_req else "FAIL"
    if ptype == "hv_test":
        il, inorm = _to_float(r.get("iLeak")), _to_float(r.get("iNorm"))
        brk = str(r.get("breakdown") or "Нет").strip()
        if brk == "Да":
            return "FAIL"
        if _to_float(r.get("uisp")) is None and il is None:
            return "EMPTY"
        if il is not None and inorm is not None and il > inorm:
            return "FAIL"
        return "PASS"
    if ptype == "rcd":
        idn, itrip, ttrip, tmax = _to_float(r.get("idn")), _to_float(r.get("iTrip")), _to_float(r.get("tTrip")), _to_float(r.get("tMax")) or 300.0
        if idn is None or (itrip is None and ttrip is None):
            return "EMPTY"
        ok = (itrip is None or (0.5 * idn < itrip <= idn)) and (ttrip is None or ttrip <= tmax)
        return "PASS" if ok else "FAIL"
    if ptype == "rzia":
        sv, mv, tol = _to_float(r.get("setpoint") if r.get("setpoint") is not None else (r.get("setpoint") if r.get("setpoint") is not None else r.get("setVal"))), _to_float(r.get("measured") if r.get("measured") is not None else (r.get("measured") if r.get("measured") is not None else r.get("measVal"))), _to_float(r.get("tol")) or 5.0
        if sv in (None, 0) or mv is None:
            return "EMPTY"
        return "PASS" if abs(((mv - sv) / sv) * 100.0) <= tol else "FAIL"
    if ptype == "dc_resistance":
        rv, nv, dv = _to_float(r.get("rVal")), _to_float(r.get("norm")), _to_float(r.get("diff"))
        if rv is None and dv is None:
            return "EMPTY"
        ok = (rv is None or nv is None or rv <= nv) and (dv is None or abs(dv) <= 2.0)
        return "PASS" if ok else "FAIL"
    if ptype in ("ct", "vt"):
        rp, rs, hv_s = _to_float(r.get("rPrim")), _to_float(r.get("rSec")), str(r.get("hv") or "").strip()
        if rp is None and rs is None and not hv_s:
            return "EMPTY"
        ok = (rp is None or rp >= 300.0) and (rs is None or rs >= 1.0) and ("пробой" not in hv_s.lower())
        return "PASS" if ok else "FAIL"
    if ptype in ("cb_oil", "cb_sf6", "cb_air", "load_switch", "cb_vacuum"):
        ro, rs = _to_float(r.get("rOrg")), _to_float(r.get("rSec"))
        hv_s, drv_s = str(r.get("hv") or "").strip(), str(r.get("drive") or "").strip()
        if ro is None and rs is None and not hv_s and not drv_s:
            return "EMPTY"
        ok = (ro is None or ro >= 300.0) and (rs is None or rs >= 1.0) and ("пробой" not in hv_s.lower()) and ("отказ" not in drv_s.lower())
        return "PASS" if ok else "FAIL"
    if ptype in ("kru", "busduct", "insulators_bus", "hv_fuse", "ohl"):
        riz, nr, hv_s = _to_float(r.get("rIz")), _to_float(r.get("normR")), str(r.get("hv") or "").strip()
        if riz is None and not hv_s:
            return "EMPTY"
        ok = (riz is None or nr is None or riz >= nr) and ("пробой" not in hv_s.lower())
        return "PASS" if ok else "FAIL"
    return "EMPTY"


def _build_conclusion_text(ptype: str, rows: list[dict[str, Any]]) -> str:
    statuses = [_eval_row_status(ptype, r) for r in (rows or [])]
    fail_idxs = [str(i + 1) for i, s in enumerate(statuses) if s == "FAIL"]
    pass_cnt = sum(1 for s in statuses if s == "PASS")
    if fail_idxs:
        return f"Данные измерений НЕ СООТВЕТСТВУЮТ требованиям ПУЭ (несоответствия в п. № {', '.join(fail_idxs)})."
    if pass_cnt == 0:
        return "Измерения не проводились (данные измерений не заполнены)."
    return "Данные измерений соответствуют требованиям ПУЭ."


def _append_protocol_to_doc(doc: Document, proto: dict[str, Any], devices: list[dict[str, Any]], start_page: int = 1, dynamic_pages: bool = False) -> None:
    ptype = proto.get("type", "grounding")
    meta = PROTOCOL_META.get(ptype, PROTOCOL_META["grounding"])
    proto_num = str(proto.get("number") or "1")
    formal_date = fmt_formal_date(proto.get("date"))
    formal_req_date = fmt_formal_date(proto.get("reqDate") or proto.get("date"))
    total_sheets = 3 if int(proto.get("pages") or 2) == 3 else 2

    hdr = doc.add_table(rows=1, cols=2)
    _set_table_borders(hdr, visible=False)
    left_txt = (
        "ООО «Сургут перевалка»\n"
        "ХМАО Сургутский район\n"
        "Западно-Сургутское месторождение\n"
        "Электротехническая лаборатория\n"
        "Регистрационный номер: №58ЭТЛ035\n"
        "Срок действия: до 25.12.2027г.\n"
        "Выдано: Северо-Уральским управлением Ростехнадзора"
    )
    right_txt = (
        "Заказчик: ООО «Сургут перевалка»\n"
        f"Объект: {proto.get('object') or '—'}\n"
        f"Дата: {formal_date}"
    )
    _cell_text(hdr.rows[0].cells[0], left_txt, size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT)
    _cell_text(hdr.rows[0].cells[1], right_txt, size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT)
    hdr.rows[0].cells[0].vertical_alignment = WD_ALIGN_VERTICAL.TOP
    hdr.rows[0].cells[1].vertical_alignment = WD_ALIGN_VERTICAL.TOP
    _set_col_widths(hdr, [10.3, 7.2])

    _add_p(doc, f"ПРОТОКОЛ №{proto_num}", size=13, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=10)
    _add_p(doc, meta["title"], size=12, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=8)

    points = [
        "1. Протокол распространяется только на образцы, подвергнутые испытаниям.",
        "2. Протокол не может быть частично или полностью перепечатан, или размножен без разрешения заказчика или испытательной лаборатории.",
        "3. На каждом листе протокола ставится печать испытательной лаборатории.",
        f"4. Объект: {proto.get('object') or '—'}",
        f"5. Дата получения заявки на проведение испытаний: {formal_req_date}",
        f"6. Монтажная организация: {proto.get('installer') or '-'}",
        f"7. Электроустановка смонтирована в соответствии с проектом, разработанным: {proto.get('project') or 'ОАО «Омскпроект»'}",
        f"8. Дата проведения испытаний: {formal_date}",
        f"9. Место проведения испытаний: {proto.get('object') or '—'}",
        f"10. Цель испытаний: {proto.get('purpose') or 'контрольные'}",
        "11. Климатические условия проведения испытаний:",
        f"    • Температура: {proto.get('temp') or '+ 18'} °C",
        f"    • Влажность: {proto.get('humidity') or '61'} %",
        f"    • Барометрическое давление: {proto.get('pressure') or '760'} мм.рт.ст.",
        f"12. Измерения выполнены в соответствии с {meta['mii']}",
        f"13. Нормативный документ, на соответствие требованиям которого проводятся испытания: {meta['nd']}",
        "14. Наименование показателей и нормативные данные приведены в приложении №1 к настоящему протоколу.",
        "15. Результаты испытаний приведены в приложении № 2 к настоящему протоколу.",
        "16. Перечень применяемого испытательного оборудования (ИО) и средств измерений (СИ) приведены в приложении № 3 к настоящему протоколу.",
    ]
    for pt in points:
        _add_p(doc, pt, size=11.5, space_after=2)

    _add_footer_stamp(doc, proto_num, 1, total_sheets, start_page, dynamic_pages=dynamic_pages)

    doc.add_page_break()
    _add_p(doc, "Приложение №1", size=11, align=WD_ALIGN_PARAGRAPH.RIGHT, keep_with_next=True)
    _add_p(doc, "Наименование показателей и нормативные данные", size=11.5, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4, keep_with_next=True)
    app1 = doc.add_table(rows=5, cols=2)
    _set_table_borders(app1, visible=True)
    app1_rows = [
        ("Наименование показателя", meta["indicator"]),
        ("Номер пункта НД на требование", meta["nd_item"]),
        ("Номер пункта НД на метод измерения", meta["method_no"]),
        ("Значение показателя по НД", meta["nd_val"]),
        ("Допуск на показатель НД", meta["nd_tol"]),
    ]
    for idx, (k, v) in enumerate(app1_rows):
        _cell_text(app1.rows[idx].cells[0], k, size=10)
        _cell_text(app1.rows[idx].cells[1], v, size=10)
    _set_col_widths(app1, [6.5, 11.0])

    _add_p(doc, "Приложение №2", size=11, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=8, keep_with_next=True)
    _add_p(doc, "Фактическое значение показателя:", size=11.5, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4, keep_with_next=True)
    _add_measurements_table(doc, ptype, proto.get("rows") or [])

    if total_sheets == 3:
        _add_footer_stamp(doc, proto_num, 2, 3, start_page + 1, dynamic_pages=dynamic_pages)
        doc.add_page_break()

    _add_p(doc, "Приложение №3", size=11, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=6, keep_with_next=True)
    _add_p(doc, "Перечень применяемого испытательного оборудования (ИО)\nи средств измерений (СИ).", size=11.5, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4, keep_with_next=True)

    dev_list = devices if devices else [{}]
    app3 = doc.add_table(rows=2 + len(dev_list), cols=7)
    _set_table_borders(app3, visible=True)
    h0 = ["Наименование ИО и СИ", "Тип ИО и СИ", "Диапазон измерений", "Заводской номер", "Погрешн. или кл. точности", "Дата поверки", ""]
    for c in range(5):
        app3.cell(0, c).merge(app3.cell(1, c))
        _cell_text(app3.cell(0, c), h0[c], size=9.5)
    app3.cell(0, 5).merge(app3.cell(0, 6))
    _cell_text(app3.cell(0, 5), "Дата поверки", size=9.5)
    _cell_text(app3.cell(1, 5), "последняя", size=9.5)
    _cell_text(app3.cell(1, 6), "очередная", size=9.5)
    for r_idx, d in enumerate(dev_list, start=2):
        _cell_text(app3.cell(r_idx, 0), d.get("name", "—"), size=9.5)
        _cell_text(app3.cell(r_idx, 1), d.get("model") or d.get("name") or "—", size=9.5)
        _cell_text(app3.cell(r_idx, 2), d.get("range", "—"), size=9.5)
        _cell_text(app3.cell(r_idx, 3), d.get("serial", "—"), size=9.5)
        _cell_text(app3.cell(r_idx, 4), d.get("accuracy", "—"), size=9.5)
        _cell_text(app3.cell(r_idx, 5), fmt_ru_date(d.get("lastCalDate")), size=9.5)
        _cell_text(app3.cell(r_idx, 6), fmt_ru_date(d.get("validUntil")), size=9.5)
    _set_col_widths(app3, [3.5, 2.4, 2.7, 2.0, 2.5, 2.2, 2.2])

    p_conc = _add_p(doc, "", size=11.5, space_before=8, space_after=8)
    r1 = p_conc.add_run("Заключение: ")
    r1.font.name = "Times New Roman"
    r1.font.size = Pt(11.5)
    r2 = p_conc.add_run(_build_conclusion_text(ptype, proto.get("rows") or []))
    r2.font.name = "Times New Roman"
    r2.font.size = Pt(11.5)
    r2.underline = True

    exec2 = proto.get("exec2") or "Лиханов Д.Ю."
    exec1 = proto.get("exec1") or "Калимуллин Р.Р."
    _add_p(doc, "Испытания произвели:", size=11.5, space_before=6, keep_with_next=True)
    _add_p(doc, f"Начальник ЭТЛ\t\t____________________________\t{exec2}", size=11.5)
    _add_p(doc, "должность, подпись, фамилия, инициалы", size=8, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
    _add_p(doc, f"Инженер РЗиА\t\t____________________________\t{exec1}", size=11.5)
    _add_p(doc, "должность, подпись, фамилия, инициалы", size=8, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=6)
    _add_p(doc, "Протокол проверил:", size=11.5, space_before=4, keep_with_next=True)
    _add_p(doc, f"Начальник ЭТЛ\t\t____________________________\t{exec2}", size=11.5)
    _add_p(doc, "должность, подпись, фамилия, инициалы", size=8, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=6)

    _add_footer_stamp(doc, proto_num, total_sheets, total_sheets, start_page + total_sheets - 1, dynamic_pages=dynamic_pages)


def generate_protocol_docx(
    proto: dict[str, Any],
    devices: list[dict[str, Any]],
    start_page: int = 1,
    use_word_footer: bool = False,
) -> bytes:
    doc = _setup_doc(use_word_footer=use_word_footer)
    _append_protocol_to_doc(doc, proto, devices, start_page=start_page, dynamic_pages=True)
    buf = BytesIO()
    doc.save(buf)
    return buf.getvalue()


def generate_report_docx(
    report_meta: dict[str, Any],
    protocols: list[dict[str, Any]],
    instruments_by_id: dict[str, dict[str, Any]],
    manual_defects: list[str] | None = None,
    use_word_footer: bool = False,
) -> bytes:
    doc = _setup_doc(use_word_footer=use_word_footer)
    rep_num = str(report_meta.get("number") or "16")
    rep_date_iso = str(report_meta.get("date") or "")
    rep_date_formal = fmt_formal_date(rep_date_iso)
    rep_year = rep_date_iso.split("-")[0] if "-" in rep_date_iso else "2026"
    obj1 = str(report_meta.get("customer") or "—")
    obj2 = str(report_meta.get("address") or "")
    kind = str(report_meta.get("kind") or "о проведении электрических испытаний")
    loc = str(report_meta.get("location") or "Сургутский район")

    _add_p(doc, "Испытательная лаборатория\nООО «Сургут перевалка»", size=14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    _add_p(
        doc,
        "ООО «Сургут перевалка»\n"
        "г. Сургут ХМАО-Югра Западно-Сургутское месторождение\n"
        "Электротехническая лаборатория\n"
        "Регистрационный номер: №58ЭТЛ035 от 25.12.2024 г.\n"
        "Срок действия: до 25.12.2027 г.\n"
        "Выдано: Северо-Уральским управлением Ростехнадзора",
        size=12,
        align=WD_ALIGN_PARAGRAPH.RIGHT,
        space_before=12,
    )
    _add_p(doc, "Утверждаю:", size=12, bold=True, align=WD_ALIGN_PARAGRAPH.RIGHT, space_before=16)
    _add_p(
        doc,
        f"Начальник испытательной\nлаборатории\n__________ Лиханов Д.Ю.\n{rep_date_formal}\nМ.П.",
        size=12,
        align=WD_ALIGN_PARAGRAPH.RIGHT,
    )
    _add_p(doc, f"Технический отчёт №{rep_num}", size=14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=60)
    _add_p(doc, kind, size=12, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    _add_p(doc, obj1, size=12, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=6)
    if obj2:
        _add_p(doc, obj2, size=12, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    _add_p(doc, f"{loc}\n{rep_year} г.", size=12, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=80)

    doc.add_page_break()
    _add_p(doc, "Содержание технического отчёта", size=14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    _add_p(doc, "электроустановки:", size=12, align=WD_ALIGN_PARAGRAPH.CENTER)
    _add_p(doc, f"{obj1}\n{obj2}".strip(), size=12, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=10)

    toc = doc.add_table(rows=3 + len(protocols), cols=5)
    _set_table_borders(toc, True)
    for i, h in enumerate(["№ п/п", "Наименование", "Номер протокола", "Всего листов", "Лист отчёта"]):
        _cell_text(toc.rows[0].cells[i], h, size=10.5, bold=True)
    _cell_text(toc.rows[1].cells[0], "1", size=10.5)
    _cell_text(toc.rows[1].cells[1], "Титульный лист", size=10.5, align=WD_ALIGN_PARAGRAPH.LEFT)
    _cell_text(toc.rows[1].cells[2], "-", size=10.5)
    _cell_text(toc.rows[1].cells[3], "1", size=10.5)
    _cell_text(toc.rows[1].cells[4], "-", size=10.5)
    _cell_text(toc.rows[2].cells[0], "2", size=10.5)
    _cell_text(toc.rows[2].cells[1], "Содержание технического отчёта", size=10.5, align=WD_ALIGN_PARAGRAPH.LEFT)
    _cell_text(toc.rows[2].cells[2], "-", size=10.5)
    _cell_text(toc.rows[2].cells[3], "1", size=10.5)
    _cell_text(toc.rows[2].cells[4], "-", size=10.5)

    cur_sheet = 1
    start_pages: list[int] = []
    for idx, p in enumerate(protocols):
        row_cnt = len(p.get("rows") or [])
        extra_p = max(0, (row_cnt - 16 + 21) // 22) if row_cnt > 16 else 0
        sheets = (3 if int(p.get("pages") or 2) == 3 else 2) + extra_p
        s_start = cur_sheet
        s_end = cur_sheet + sheets - 1
        start_pages.append(s_start)
        cur_sheet = s_end + 1
        meta = PROTOCOL_META.get(p.get("type", "grounding"), PROTOCOL_META["grounding"])
        row = toc.rows[3 + idx].cells
        _cell_text(row[0], str(idx + 3), size=10.5)
        _cell_text(row[1], f"Протокол № {p.get('number', idx + 1)} {meta['title']}", size=10.5, align=WD_ALIGN_PARAGRAPH.LEFT)
        _cell_text(row[2], str(p.get("number", idx + 1)), size=10.5)
        _cell_text(row[3], str(sheets), size=10.5)
        _cell_text(row[4], f"{s_start}-{s_end}", size=10.5)
    _set_col_widths(toc, [1.3, 8.7, 2.6, 2.4, 2.5])

    for idx, p in enumerate(protocols):
        doc.add_page_break()
        devs = [instruments_by_id[p[k]] for k in ("instrumentId", "instrumentId2") if p.get(k) and p[k] in instruments_by_id]
        _append_protocol_to_doc(doc, p, devs, start_page=start_pages[idx])

    if manual_defects:
        doc.add_page_break()
        _add_p(doc, "Ведомость дефектов и замечаний", size=14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=8)
        dtbl = doc.add_table(rows=1 + len(manual_defects), cols=2)
        _set_table_borders(dtbl, True)
        _cell_text(dtbl.rows[0].cells[0], "№ п/п", size=10.5, bold=True)
        _cell_text(dtbl.rows[0].cells[1], "Описание замечания", size=10.5, bold=True)
        for i, txt in enumerate(manual_defects, start=1):
            _cell_text(dtbl.rows[i].cells[0], str(i), size=10.5)
            _cell_text(dtbl.rows[i].cells[1], txt, size=10.5, align=WD_ALIGN_PARAGRAPH.LEFT)
        _set_col_widths(dtbl, [1.6, 15.9])

    buf = BytesIO()
    doc.save(buf)
    return buf.getvalue()


def generate_work_permit_docx(permit: dict[str, Any]) -> bytes:
    """Генерирует Наряд-допуск для работы в электроустановках по ПОТЭЭ № 903н (ред. № 279н)."""
    doc = _setup_doc(use_word_footer=True)
    _add_p(doc, "Приложение № 7 к Правилам по охране труда при эксплуатации электроустановок (Приказ Минтруда РФ № 903н в ред. № 279н)", size=8.5, align=WD_ALIGN_PARAGRAPH.RIGHT, space_after=4)
    _add_p(doc, "Организация: ООО «Сургут перевалка»", size=11)
    _add_p(doc, f"Подразделение: {permit.get('department') or 'Электротехническая лаборатория (ЭТЛ)'}", size=11, space_after=6)

    _add_p(doc, f"НАРЯД-ДОПУСК № {permit.get('number') or '___'}", size=13, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    _add_p(doc, "ДЛЯ РАБОТЫ В ЭЛЕКТРОУСТАНОВКАХ", size=11.5, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=8)

    fields = [
        ("Ответственному руководителю работ:", permit.get("responsible") or "не назначается"),
        ("Допускающему:", permit.get("admitter") or "—"),
        ("Производителю работ (наблюдающему):", permit.get("producer") or "—"),
        ("С членами бригады:", permit.get("crew") or "—"),
        ("Категория работ:", permit.get("category") or "Со снятием напряжения / испытания повышенным напряжением"),
        ("Поручается:", permit.get("task") or "—"),
        ("Работу начать:", f"{fmt_ru_date(permit.get('startDate'))}  {permit.get('startTime') or '08:00'}"),
        ("Работу закончить:", f"{fmt_ru_date(permit.get('endDate'))}  {permit.get('endTime') or '17:00'}"),
    ]
    for lbl, val in fields:
        p = _add_p(doc, "", size=11, space_after=2)
        r1 = p.add_run(lbl + " ")
        r1.font.name = "Times New Roman"
        r1.font.size = Pt(11)
        r1.bold = True
        r2 = p.add_run(str(val))
        r2.font.name = "Times New Roman"
        r2.font.size = Pt(11)

    _add_p(doc, "Меры по подготовке рабочих мест к выполнению работ:", size=11, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=6, space_after=4)
    measures = permit.get("measures") or []
    if not measures:
        measures = [{"installation": permit.get("object") or "—", "actions": "Отключить коммутационный аппарат, вывесить плакат «НЕ ВКЛЮЧАТЬ! РАБОТАЮТ ЛЮДИ», проверить отсутствие напряжения, установить ПЗ."}]
    mtbl = doc.add_table(rows=1 + len(measures), cols=2)
    _set_table_borders(mtbl, True)
    _cell_text(mtbl.rows[0].cells[0], "Наименование электроустановок, в которых нужно провести отключения и установить заземления", size=9.5, bold=True)
    _cell_text(mtbl.rows[0].cells[1], "Что должно быть отключено и где установлены заземления", size=9.5, bold=True)
    for i, m in enumerate(measures, start=1):
        _cell_text(mtbl.rows[i].cells[0], m.get("installation", "—"), size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT)
        _cell_text(mtbl.rows[i].cells[1], m.get("actions", "—"), size=9.5, align=WD_ALIGN_PARAGRAPH.LEFT)
    _set_col_widths(mtbl, [7.5, 10.0])

    _add_p(doc, f"Отдельные указания: {permit.get('notes') or 'При проведении испытаний повышенным напряжением выставить ограждения и плакаты «ИСПЫТАНИЕ. ОПАСНО ДЛЯ ЖИЗНИ».'}", size=10.5, space_before=6, space_after=6)
    _add_p(doc, f"Наряд выдал: {fmt_ru_date(permit.get('issueDate'))}   Подпись: ____________   {permit.get('issuer') or 'Болышев В.С.'}", size=11, space_after=6)

    # Обратная сторона наряда (разрешение, ежедневный допуск, изменения, окончание)
    doc.add_page_break()
    _add_p(doc, "Разрешение на подготовку рабочих мест и на допуск к выполнению работ", size=11, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
    rtbl = doc.add_table(rows=3, cols=3)
    _set_table_borders(rtbl, True)
    for i, h in enumerate(["Разрешение выдал (должность, ФИО)", "Дата, время", "Подпись работника, получившего разрешение"]):
        _cell_text(rtbl.rows[0].cells[i], h, size=9, bold=True)
    for r_i in (1, 2):
        for c_i in range(3):
            _cell_text(rtbl.rows[r_i].cells[c_i], " ", size=9)
    _set_col_widths(rtbl, [7.0, 4.0, 6.5])

    _add_p(doc, "Рабочие места подготовлены. Под напряжением остались: ___________________________________________", size=10.5, space_before=6)
    _add_p(doc, "Допускающий ______________________    Ответственный руководитель (производитель) ______________________", size=10.5, space_after=6)

    _add_p(doc, "Ежедневный допуск к работе и время ее окончания", size=11, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_before=4, space_after=4)
    dtbl = doc.add_table(rows=4, cols=5)
    _set_table_borders(dtbl, True)
    for i, h in enumerate(["Наименование рабочего места", "Дата, время начала", "Подпись допускающего", "Подпись производителя", "Дата, время окончания"]):
        _cell_text(dtbl.rows[0].cells[i], h, size=9, bold=True)
    for r_i in range(1, 4):
        for c_i in range(5):
            _cell_text(dtbl.rows[r_i].cells[c_i], " ", size=9)
    _set_col_widths(dtbl, [4.5, 3.2, 3.3, 3.3, 3.2])

    _add_p(doc, "Работа полностью закончена, бригада удалена, заземления, установленные бригадой, сняты, сообщено (кому): ________________________", size=10.5, space_before=10)
    _add_p(doc, "Дата: «___» __________ 20___ г.   Время: ___ ч ___ мин", size=10.5)
    _add_p(doc, "Производитель работ (наблюдающий): ______________________    Ответственный руководитель работ: ______________________", size=10.5, space_before=4)

    buf = BytesIO()
    doc.save(buf)
    return buf.getvalue()
