@echo off
cd /d "%~dp0"
set PY_CMD=python
where python >nul 2>&1 || set PY_CMD=py -3
if not exist ".venv\Scripts\python.exe" %PY_CMD% -m venv .venv
".venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller
".venv\Scripts\pyinstaller.exe" --noconfirm --onefile --name "ARM_ETL_Surgut" --add-data "templates;templates" --add-data "static;static" --add-data "objects_seed.json;." --hidden-import=mvi_catalog --hidden-import=security --hidden-import=database --hidden-import=docx_generator app.py
echo Done! Executable is in dist\ARM_ETL_Surgut.exe
pause
