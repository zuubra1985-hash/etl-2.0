import json
import uuid
from pathlib import Path
from typing import Dict, Optional
from application.server.core.config import PROJECT_ROOT
from application.server.core.db import db_session
from application.server.modules.security.auth import hash_password

ROLES = [
    ("ADMIN", "Администратор", ["*"]),
    ("HEAD", "Начальник ЭТЛ", [
        "equipment:read", "equipment:write", "passport:read", "passport:write",
        "test:read", "test:write", "test:confirm", "protocol:sign",
        "instrument:read", "instrument:write", "methodology:approve",
        "audit:read", "backup:run", "report:export",
    ]),
    ("TESTER", "Испытатель / Инженер ЭТЛ", [
        "equipment:read", "equipment:write", "passport:read", "passport:write",
        "test:read", "test:write", "test:confirm", "instrument:read", "report:export",
    ]),
    ("REVIEWER", "Контролирующий специалист", [
        "equipment:read", "passport:read", "test:read", "protocol:review",
        "instrument:read", "audit:read", "report:export",
    ]),
    ("VIEWER", "Просмотр", ["equipment:read", "passport:read", "test:read", "instrument:read"]),
]

EQUIPMENT_TYPES = [
    ("MOTOR", "Электродвигатели переменного тока"),
    ("TRANSFORMER", "Силовые трансформаторы"),
    ("KRU", "КРУ / КРУН / Ячейки 6–10 кВ"),
    ("BREAKER_LV", "Автоматические выключатели до 1000 В"),
    ("BREAKER_HV", "Выключатели 6–10 кВ"),
    ("CABLE_LINE", "Силовые кабельные линии"),
    ("GROUNDING", "Заземляющие устройства и молниезащита"),
    ("CT_VT", "Измерительные трансформаторы тока и напряжения (ТТ/ТН)"),
    ("SWITCHBOARD", "Щиты, ВРУ, распределительные устройства до 1000 В"),
    ("PPE", "Электрозащитные средства (СИЗ)"),
]

METHODOLOGIES = [
    ("МВИ-01", "Проверка состояния элементов заземляющих устройств", "ЗУ"),
    ("МВИ-02", "Проверка наличия цепи и замеры переходных сопротивлений", "ЗУ / Металлосвязь"),
    ("МВИ-03", "Измерение удельного сопротивления грунта", "ЗУ"),
    ("МВИ-04", "Измерение сопротивления заземляющих устройств", "ЗУ"),
    ("МВИ-05", "Измерение сопротивления изоляции электрооборудования и кабелей", "Все типы"),
    ("МВИ-06", "Испытание цепи фаза-нуль в электроустановках до 1000 В", "До 1000 В"),
    ("МВИ-07", "Проверка действия расцепителей автоматических выключателей", "АВ до 1000 В"),
    ("МВИ-08", "Проверка устройств защитного отключения (УЗО / АВДТ)", "До 1000 В"),
    ("МВИ-09", "Испытание силовых кабельных линий повышенным напряжением", "КЛ"),
    ("МВИ-10", "Измерение сопротивления постоянному току обмоток и контактов", "ЭД / Трансформаторы"),
    ("МВИ-11", "Испытание силовых трансформаторов (Ктр, группа соединений, ХХ)", "Трансформаторы"),
    ("МВИ-12", "Испытание измерительных трансформаторов тока (ТТ)", "ТТ"),
    ("МВИ-13", "Испытание измерительных трансформаторов напряжения (ТН)", "ТН"),
    ("МВИ-14", "Испытание выключателей 6–10 кВ", "Выключатели 6–10 кВ"),
    ("МВИ-15", "Испытание разъединителей, отделителей и короткозамыкателей", "КРУ"),
    ("МВИ-16", "Испытание сборных и соединительных шин КРУ", "КРУ"),
    ("МВИ-17", "Испытание вентильных разрядников и ОПН", "КРУ / Подстанции"),
    ("МВИ-18", "Испытание электродвигателей переменного тока", "ЭД"),
    ("МВИ-19", "Проверка устройств релейной защиты и автоматики (РЗиА)", "РЗиА / КРУ"),
    ("МВИ-20", "Испытание систем АВР и вторичных цепей", "Вторичные цепи"),
    ("МВИ-21", "Испытание конденсаторных установок", "КУ"),
    ("МВИ-22", "Визуальный осмотр электроустановок", "Все типы"),
    ("МВИ-23", "Фазировка электрических сетей и оборудования", "КЛ / КРУ"),
    ("МВИ-24", "Тепловизионный контроль электрооборудования", "Все типы"),
    ("МВИ-25", "Электрические испытания электрозащитных средств (СИЗ)", "СИЗ"),
]

BASE_TEST_TYPES = [
    ("P1", "Визуальный осмотр электроустановок", "МВИ-22"),
    ("P2", "Проверка наличия цепи (металлосвязь)", "МВИ-02"),
    ("P3", "Измерение сопротивления изоляции", "МВИ-05"),
    ("P4", "Проверка цепи «фаза — нуль»", "МВИ-06"),
    ("P5", "Проверка расцепителей автоматических выключателей", "МВИ-07"),
    ("P6", "Проверка УЗО / дифференциальных автоматов", "МВИ-08"),
]


def seed_all(db_path: Optional[str] = None) -> Dict[str, int]:
    counts = {"roles": 0, "users": 0, "equipment_types": 0, "methodologies": 0, "test_types": 0, "instruments": 0}
    with db_session(db_path) as conn:
        # 1. Department
        dep_row = conn.execute("SELECT id FROM departments WHERE code = 'OGE-ETL'").fetchone()
        if not dep_row:
            conn.execute(
                "INSERT INTO departments (id, name, code) VALUES (?, ?, ?)",
                (str(uuid.uuid4()), "ОГЭ / Электротехническая лаборатория ООО «Сургут перевалка»", "OGE-ETL"),
            )

        # 2. Roles
        role_ids = {}
        for code, name, perms in ROLES:
            row = conn.execute("SELECT id FROM roles WHERE code = ?", (code,)).fetchone()
            if row:
                role_ids[code] = row["id"]
            else:
                rid = str(uuid.uuid4())
                conn.execute(
                    "INSERT INTO roles (id, code, name, permissions_json) VALUES (?, ?, ?, ?)",
                    (rid, code, name, json.dumps(perms, ensure_ascii=False)),
                )
                role_ids[code] = rid
                counts["roles"] += 1

        # 3. Default users (passwords must be changed on first deployment)
        default_users = [
            ("admin", "Администратор системы ETL 2.0", "Системный администратор", "V", "ADMIN", "AdminETL2026!"),
            ("likhanov", "Лиханов Дмитрий Юрьевич", "Начальник ЭТЛ", "V", "HEAD", "2027"),
            ("kalimullin", "Калимуллин Ренард Ринатович", "Инженер РЗиА", "V", "TESTER", "1234"),
            ("viewer", "Наблюдатель ЭТЛ", "Просмотр", "-", "VIEWER", "0000"),
        ]
        for uname, fname, pos, grp, rcode, pwd in default_users:
            if not conn.execute("SELECT id FROM users WHERE username = ?", (uname,)).fetchone():
                conn.execute(
                    """
                    INSERT INTO users (id, username, full_name, position, eb_group, password_hash, role_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (str(uuid.uuid4()), uname, fname, pos, grp, hash_password(pwd), role_ids[rcode]),
                )
                counts["users"] += 1

        # 4. Equipment types
        for code, name in EQUIPMENT_TYPES:
            if not conn.execute("SELECT id FROM equipment_types WHERE code = ?", (code,)).fetchone():
                conn.execute(
                    "INSERT INTO equipment_types (id, code, name, schema_json) VALUES (?, ?, ?, '{}')",
                    (str(uuid.uuid4()), code, name),
                )
                counts["equipment_types"] += 1

        # 5. Methodologies (25 MVI)
        mvi_ids = {}
        for code, title, scope in METHODOLOGIES:
            row = conn.execute("SELECT id FROM methodologies WHERE code = ?", (code,)).fetchone()
            if row:
                mvi_ids[code] = row["id"]
            else:
                mid = str(uuid.uuid4())
                conn.execute(
                    "INSERT INTO methodologies (id, code, title, scope, is_active) VALUES (?, ?, ?, ?, 1)",
                    (mid, code, title, scope),
                )
                conn.execute(
                    """
                    INSERT INTO methodology_versions (id, methodology_id, edition, norm_criteria_json, status)
                    VALUES (?, ?, '2026', '{}', 'DRAFT')
                    """,
                    (str(uuid.uuid4()), mid),
                )
                mvi_ids[code] = mid
                counts["methodologies"] += 1

        # 6. Base test types P1..P6
        for code, name, mvi_code in BASE_TEST_TYPES:
            if not conn.execute("SELECT id FROM test_types WHERE code = ?", (code,)).fetchone():
                conn.execute(
                    "INSERT INTO test_types (id, code, name, methodology_id) VALUES (?, ?, ?, ?)",
                    (str(uuid.uuid4()), code, name, mvi_ids.get(mvi_code)),
                )
                counts["test_types"] += 1

        # 7. Instruments from verified data/instruments/instruments_seed.json
        seed_json = PROJECT_ROOT / "data" / "instruments" / "instruments_seed.json"
        if seed_json.exists():
            raw = json.loads(seed_json.read_text(encoding="utf-8"))
            items = raw.get("instruments", raw) if isinstance(raw, dict) else raw
            for item in items:
                sn = str(item.get("serial_no") or item.get("serial_number") or "").strip()
                if not sn:
                    continue
                if conn.execute("SELECT id FROM instruments WHERE serial_no = ?", (sn,)).fetchone():
                    continue
                inst_id = str(uuid.uuid4())
                status = item.get("status", "CALIBRATION")
                if status not in ("ACTIVE", "CALIBRATION", "CONSERVATION"):
                    status = "CALIBRATION"
                op_cond = item.get("operating_conditions") or {
                    "temp_min_c": item.get("operating_temp_min_c"),
                    "temp_max_c": item.get("operating_temp_max_c"),
                    "humidity_max_pct": item.get("operating_humidity_max_pct"),
                }
                int_years = item.get("verification_interval_years")
                if int_years is None and item.get("calibration_interval_months"):
                    int_years = max(1, int(item["calibration_interval_months"]) // 12)
                cal_date = item.get("last_known_calibration_date")
                valid_until = item.get("active_valid_until") or item.get("last_known_valid_until")
                conn.execute(
                    """
                    INSERT INTO instruments (
                        id, name, model, manufacturer, serial_no, measurement_range,
                        accuracy_class, arshin_reg_no, calibration_method,
                        calibration_interval_years, operating_conditions_json,
                        calibration_date, calibration_valid_until, status, notes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        inst_id,
                        item.get("name") or item.get("model") or "СИ",
                        item.get("model") or item.get("name") or "СИ",
                        item.get("manufacturer"),
                        sn,
                        json.dumps(item.get("measurement_ranges", ""), ensure_ascii=False)
                        if isinstance(item.get("measurement_ranges"), (dict, list))
                        else str(item.get("measurement_range") or ""),
                        str(item.get("accuracy_class") or ""),
                        item.get("fifo_reg_no") or item.get("arshin_reg_no"),
                        item.get("verification_method"),
                        int_years,
                        json.dumps(op_cond, ensure_ascii=False),
                        cal_date,
                        valid_until,
                        status,
                        item.get("notes"),
                    ),
                )
                arch_cert = item.get("archive_certificate_no") or item.get("archive_cert_2024")
                if arch_cert:
                    conn.execute(
                        """
                        INSERT INTO instrument_documents (id, instrument_id, doc_type, doc_number, valid_until)
                        VALUES (?, ?, 'ARCHIVE_VERIFICATION_CERT', ?, ?)
                        """,
                        (str(uuid.uuid4()), inst_id, str(arch_cert), valid_until),
                    )
                counts["instruments"] += 1
    return counts


if __name__ == "__main__":
    print("Seed result:", seed_all())
