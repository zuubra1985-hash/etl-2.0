import json
import uuid
from typing import Dict, Optional
from application.server.core.db import db_session


def seed_stage8_mappings(db_path: Optional[str] = None) -> Dict[str, int]:
    added = 0
    with db_session(db_path) as conn:
        eq_types = conn.execute("SELECT id, code FROM equipment_types").fetchall()
        test_types = conn.execute("SELECT id, code FROM test_types").fetchall()
        rules = json.dumps({"target_list": "test_records", "section": "sec_4_10", "include_instruments": True}, ensure_ascii=False)
        for et in eq_types:
            for tt in test_types:
                exists = conn.execute(
                    "SELECT id FROM passport_fill_mappings WHERE equipment_type_id = ? AND test_type_id = ?",
                    (et["id"], tt["id"]),
                ).fetchone()
                if not exists:
                    conn.execute(
                        """
                        INSERT INTO passport_fill_mappings (
                            id, equipment_type_id, test_type_id, passport_section_code, mapping_rules_json, is_active
                        ) VALUES (?, ?, ?, 'sec_4_10', ?, 1)
                        """,
                        (str(uuid.uuid4()), et["id"], tt["id"], rules),
                    )
                    added += 1
    return {"mappings_added": added}
