import glob
import os
import sys
from pathlib import Path
from typing import List, Optional
from application.server.core.db import connect_db

MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"


def ensure_migrations_table(conn) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version TEXT PRIMARY KEY,
            applied_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
        """
    )


def get_applied_versions(conn) -> List[str]:
    ensure_migrations_table(conn)
    rows = conn.execute("SELECT version FROM schema_migrations ORDER BY version").fetchall()
    return [r["version"] for r in rows]


def upgrade(db_path: Optional[str] = None) -> List[str]:
    conn = connect_db(db_path)
    applied_now: List[str] = []
    try:
        applied = set(get_applied_versions(conn))
        sql_files = sorted(glob.glob(str(MIGRATIONS_DIR / "*.sql")))
        for sql_file in sql_files:
            version = os.path.basename(sql_file)
            if version in applied:
                continue
            with open(sql_file, "r", encoding="utf-8") as f:
                script = f.read()
            conn.executescript(script)
            conn.execute("INSERT INTO schema_migrations (version) VALUES (?)", (version,))
            conn.commit()
            applied_now.append(version)
    finally:
        conn.close()
    return applied_now


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "upgrade"
    if cmd == "upgrade":
        res = upgrade()
        print("Applied migrations:", res or "already up to date")
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)
