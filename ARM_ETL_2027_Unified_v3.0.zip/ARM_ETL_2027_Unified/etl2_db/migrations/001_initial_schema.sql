-- ETL 2.0 Migration 001: Initial 21-table schema (SQLite WAL / PostgreSQL compatible types)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS departments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    parent_id TEXT REFERENCES departments(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS locations (
    id TEXT PRIMARY KEY,
    department_id TEXT REFERENCES departments(id) ON DELETE SET NULL,
    facility_name TEXT NOT NULL,
    building TEXT,
    room TEXT,
    address TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS equipment_types (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    default_passport_template_id TEXT,
    schema_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS equipment (
    id TEXT PRIMARY KEY,
    type_id TEXT NOT NULL REFERENCES equipment_types(id),
    location_id TEXT REFERENCES locations(id),
    inventory_no TEXT,
    serial_no TEXT,
    dispatch_name TEXT,
    name TEXT NOT NULL,
    manufacturer TEXT,
    model TEXT,
    specs_json TEXT NOT NULL DEFAULT '{}',
    commissioned_at TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'REPAIR', 'ARCHIVED')),
    is_archived INTEGER NOT NULL DEFAULT 0,
    legacy_id INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_equipment_inv_serial ON equipment(inventory_no, serial_no);
CREATE INDEX IF NOT EXISTS idx_equipment_type ON equipment(type_id);
CREATE INDEX IF NOT EXISTS idx_equipment_location ON equipment(location_id);

CREATE TABLE IF NOT EXISTS qr_identities (
    id TEXT PRIMARY KEY,
    equipment_id TEXT UNIQUE NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    qr_token TEXT UNIQUE NOT NULL,
    short_code TEXT UNIQUE NOT NULL,
    print_count INTEGER NOT NULL DEFAULT 0,
    last_printed_at TEXT,
    checksum TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    original_filename TEXT NOT NULL,
    storage_rel_path TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    is_original_immutable INTEGER NOT NULL DEFAULT 0,
    uploaded_by TEXT,
    uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_attachments_entity ON attachments(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS roles (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL CHECK (code IN ('ADMIN', 'HEAD', 'TESTER', 'REVIEWER', 'VIEWER')),
    name TEXT NOT NULL,
    permissions_json TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    position TEXT,
    eb_group TEXT,
    password_hash TEXT NOT NULL,
    role_id TEXT NOT NULL REFERENCES roles(id),
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS methodologies (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    scope TEXT,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS methodology_versions (
    id TEXT PRIMARY KEY,
    methodology_id TEXT NOT NULL REFERENCES methodologies(id) ON DELETE CASCADE,
    edition TEXT NOT NULL,
    effective_date TEXT,
    norm_criteria_json TEXT NOT NULL DEFAULT '{}',
    approved_by_user_id TEXT REFERENCES users(id),
    approved_at TEXT,
    source_attachment_id TEXT REFERENCES attachments(id),
    status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'ACTIVE', 'SUPERSEDED'))
);

CREATE TABLE IF NOT EXISTS test_types (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    methodology_id TEXT REFERENCES methodologies(id),
    form_schema_json TEXT NOT NULL DEFAULT '{}',
    protocol_template_id TEXT
);

CREATE TABLE IF NOT EXISTS instruments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    model TEXT NOT NULL,
    manufacturer TEXT,
    serial_no TEXT UNIQUE NOT NULL,
    measurement_range TEXT,
    accuracy_class TEXT,
    arshin_reg_no TEXT,
    calibration_method TEXT,
    calibration_interval_years INTEGER,
    operating_conditions_json TEXT NOT NULL DEFAULT '{}',
    calibration_date TEXT,
    calibration_valid_until TEXT,
    status TEXT NOT NULL DEFAULT 'CALIBRATION' CHECK (status IN ('ACTIVE', 'CALIBRATION', 'CONSERVATION')),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS instrument_documents (
    id TEXT PRIMARY KEY,
    instrument_id TEXT NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
    doc_type TEXT NOT NULL,
    doc_number TEXT,
    valid_until TEXT,
    attachment_id TEXT REFERENCES attachments(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tests (
    id TEXT PRIMARY KEY,
    equipment_id TEXT NOT NULL REFERENCES equipment(id),
    test_type_id TEXT NOT NULL REFERENCES test_types(id),
    methodology_version_id TEXT REFERENCES methodology_versions(id),
    test_date TEXT NOT NULL,
    test_time TEXT,
    purpose TEXT,
    temp_c REAL,
    humidity_pct REAL,
    pressure_mmhg REAL,
    executor_user_id TEXT REFERENCES users(id),
    status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'CONFIRMED', 'VERIFIED', 'CANCELLED')),
    instruments_snapshot_json TEXT NOT NULL DEFAULT '[]',
    notes TEXT,
    legacy_id INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS measurement_parameters (
    id TEXT PRIMARY KEY,
    test_type_id TEXT NOT NULL REFERENCES test_types(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    unit TEXT,
    data_type TEXT NOT NULL DEFAULT 'number',
    is_required INTEGER NOT NULL DEFAULT 1,
    validation_rules_json TEXT NOT NULL DEFAULT '{}',
    UNIQUE(test_type_id, code)
);

CREATE TABLE IF NOT EXISTS measurements (
    id TEXT PRIMARY KEY,
    test_id TEXT NOT NULL REFERENCES tests(id) ON DELETE CASCADE,
    parameter_id TEXT NOT NULL REFERENCES measurement_parameters(id),
    point_label TEXT,
    raw_value TEXT NOT NULL,
    unit TEXT,
    conditions_json TEXT NOT NULL DEFAULT '{}',
    instrument_id TEXT REFERENCES instruments(id),
    compliance_status TEXT NOT NULL DEFAULT 'NOT_EVALUATED' CHECK (compliance_status IN ('PASS', 'FAIL', 'NOT_EVALUATED')),
    norm_ref TEXT,
    is_superseded INTEGER NOT NULL DEFAULT 0,
    superseded_by_id TEXT REFERENCES measurements(id),
    correction_reason TEXT,
    corrected_by TEXT REFERENCES users(id),
    corrected_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS passports (
    id TEXT PRIMARY KEY,
    equipment_id TEXT UNIQUE NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    template_id TEXT,
    original_attachment_id TEXT REFERENCES attachments(id),
    current_version_id TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS passport_versions (
    id TEXT PRIMARY KEY,
    passport_id TEXT NOT NULL REFERENCES passports(id) ON DELETE CASCADE,
    version_no INTEGER NOT NULL,
    data_json TEXT NOT NULL DEFAULT '{}',
    rendered_attachment_id TEXT REFERENCES attachments(id),
    source_test_id TEXT REFERENCES tests(id),
    change_reason TEXT,
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(passport_id, version_no)
);

-- Idempotency guarantee: one test cannot auto-fill the same passport twice
CREATE UNIQUE INDEX IF NOT EXISTS uq_passport_versions_source_test
    ON passport_versions(passport_id, source_test_id)
    WHERE source_test_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS protocols (
    id TEXT PRIMARY KEY,
    test_id TEXT NOT NULL REFERENCES tests(id) ON DELETE CASCADE,
    protocol_no TEXT NOT NULL,
    version_no INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'GENERATED', 'REVIEWED', 'SIGNED', 'REVISED')),
    conclusion TEXT,
    attachment_id_docx TEXT REFERENCES attachments(id),
    attachment_id_pdf TEXT REFERENCES attachments(id),
    signatories_json TEXT NOT NULL DEFAULT '[]',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS passport_fill_mappings (
    id TEXT PRIMARY KEY,
    equipment_type_id TEXT NOT NULL REFERENCES equipment_types(id) ON DELETE CASCADE,
    test_type_id TEXT NOT NULL REFERENCES test_types(id) ON DELETE CASCADE,
    passport_section_code TEXT NOT NULL,
    mapping_rules_json TEXT NOT NULL DEFAULT '{}',
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT REFERENCES users(id),
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    before_json TEXT,
    after_json TEXT,
    reason TEXT,
    ip_address TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at);
