import json
import uuid
from typing import Dict, List, Optional
from application.server.core.db import db_session

TEST_TYPE_PARAMS: Dict[str, List[tuple]] = {
    "P1": [
        ("visual_state", "Результат визуального осмотра", "", "enum", 1),
        ("marking_ok", "Наличие маркировки и схем", "", "enum", 1),
    ],
    "P2": [
        ("r_metal_ohm", "Переходное сопротивление металлосвязи", "Ом", "number", 1),
    ],
    "P3": [
        ("u_test_v", "Испытательное напряжение мегаомметра", "В", "number", 1),
        ("r_ins_mohm", "Сопротивление изоляции R60", "МОм", "number", 1),
        ("k_abs", "Коэффициент абсорбции R60/R15", "", "number", 0),
    ],
    "P4": [
        ("z_loop_ohm", "Полное сопротивление петли фаза-нуль", "Ом", "number", 1),
        ("i_sc_a", "Ток однофазного КЗ", "А", "number", 1),
    ],
    "P5": [
        ("i_test_a", "Испытательный ток прогрузки", "А", "number", 1),
        ("t_trip_s", "Время срабатывания расцепителя", "с", "number", 1),
    ],
    "P6": [
        ("i_diff_ma", "Дифференциальный ток срабатывания", "мА", "number", 1),
        ("t_trip_ms", "Время отключения УЗО", "мс", "number", 1),
    ],
}

# Applicability map by test_type code -> list of equipment_type codes (["*"] means all)
APPLICABILITY_MAP: Dict[str, List[str]] = {
    "P1": ["*"],
    "P2": ["MOTOR", "TRANSFORMER", "KRU", "SWITCHBOARD", "GROUNDING"],
    "P3": ["MOTOR", "TRANSFORMER", "KRU", "CABLE_LINE", "SWITCHBOARD", "BREAKER_LV", "BREAKER_HV", "CT_VT"],
    "P4": ["MOTOR", "BREAKER_LV", "SWITCHBOARD"],
    "P5": ["BREAKER_LV", "SWITCHBOARD"],
    "P6": ["BREAKER_LV", "SWITCHBOARD"],
}


def seed_stage6_metadata(db_path: Optional[str] = None) -> Dict[str, int]:
    added_tt = 0
    added_params = 0
    with db_session(db_path) as conn:
        # Ensure form_schema_json on P1..P6
        for code, eq_types in APPLICABILITY_MAP.items():
            row = conn.execute("SELECT id, form_schema_json FROM test_types WHERE code = ?", (code,)).fetchone()
            if row:
                schema = {"applicable_equipment_types": eq_types, "protocol_group": code}
                conn.execute(
                    "UPDATE test_types SET form_schema_json = ? WHERE id = ?",
                    (json.dumps(schema, ensure_ascii=False), row["id"]),
                )
                for pcode, pname, unit, dtype, req in TEST_TYPE_PARAMS.get(code, []):
                    exists = conn.execute(
                        "SELECT id FROM measurement_parameters WHERE test_type_id = ? AND code = ?",
                        (row["id"], pcode),
                    ).fetchone()
                    if not exists:
                        conn.execute(
                            """
                            INSERT INTO measurement_parameters (id, test_type_id, code, name, unit, data_type, is_required)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                            """,
                            (str(uuid.uuid4()), row["id"], pcode, pname, unit, dtype, req),
                        )
                        added_params += 1

        # Create test_types for remaining methodologies (МВИ-01..25) that do not yet have a dedicated test_type
        mvis = conn.execute("SELECT id, code, title, scope FROM methodologies ORDER BY code").fetchall()
        for m in mvis:
            has_tt = conn.execute("SELECT id FROM test_types WHERE methodology_id = ?", (m["id"],)).fetchone()
            if not has_tt:
                tcode = m["code"].replace("МВИ-", "T")
                tid = str(uuid.uuid4())
                schema = {"applicable_equipment_types": ["*"], "scope_hint": m["scope"]}
                conn.execute(
                    "INSERT INTO test_types (id, code, name, methodology_id, form_schema_json) VALUES (?, ?, ?, ?, ?)",
                    (tid, tcode, m["title"], m["id"], json.dumps(schema, ensure_ascii=False)),
                )
                # Default generic measurement parameter so every MVI is immediately usable
                conn.execute(
                    """
                    INSERT INTO measurement_parameters (id, test_type_id, code, name, unit, data_type, is_required)
                    VALUES (?, ?, 'measured_value', 'Измеренное значение по методике', '', 'text', 1)
                    """,
                    (str(uuid.uuid4()), tid),
                )
                added_tt += 1
                added_params += 1
    return {"test_types_added": added_tt, "parameters_added": added_params}
