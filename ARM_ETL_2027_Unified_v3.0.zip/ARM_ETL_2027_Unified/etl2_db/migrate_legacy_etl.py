import hashlib
import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, Optional
from application.server.core.db import db_session
from application.server.modules.security.audit import write_audit_log


def migrate_from_legacy(legacy_db_path: str, target_db_path: Optional[str] = None) -> Dict[str, Any]:
    lpath = Path(legacy_db_path)
    if not lpath.exists():
        raise FileNotFoundError(f"Исходная БД не найдена: {legacy_db_path}")

    lconn = sqlite3.connect(str(lpath))
    lconn.row_factory = sqlite3.Row
    manifest: Dict[str, Any] = {
        "source_db": str(lpath),
        "locations_created": [],
        "equipment_created": [],
        "instruments_created": [],
        "tests_created": [],
    }

    try:
        with db_session(target_db_path) as conn:
            dep = conn.execute("SELECT id FROM departments WHERE code = 'OGE-ETL'").fetchone()
            dep_id = dep["id"] if dep else None
            default_eq_type = conn.execute("SELECT id FROM equipment_types WHERE code = 'SWITCHBOARD'").fetchone()
            default_type_id = default_eq_type["id"]

            # 1. Objects -> locations
            loc_map = {}
            for row in lconn.execute("SELECT * FROM objects").fetchall():
                d = dict(row)
                fname = d.get("name") or f"Объект #{d.get('id')}"
                existing = conn.execute("SELECT id FROM locations WHERE facility_name = ?", (fname,)).fetchone()
                if existing:
                    loc_map[d["id"]] = existing["id"]
                else:
                    lid = str(uuid.uuid4())
                    conn.execute(
                        "INSERT INTO locations (id, department_id, facility_name, address) VALUES (?, ?, ?, ?)",
                        (lid, dep_id, fname, d.get("address")),
                    )
                    loc_map[d["id"]] = lid
                    manifest["locations_created"].append(lid)

            # 2. Equipment -> equipment + qr_identities
            eq_map = {}
            for row in lconn.execute("SELECT * FROM equipment").fetchall():
                d = dict(row)
                existing = conn.execute("SELECT id FROM equipment WHERE legacy_id = ?", (d["id"],)).fetchone()
                if existing:
                    eq_map[d["id"]] = existing["id"]
                    continue
                eid = str(uuid.uuid4())
                name = d.get("name") or d.get("equipment_name") or f"Оборудование #{d['id']}"
                conn.execute(
                    """
                    INSERT INTO equipment (id, type_id, location_id, inventory_no, serial_no, name, specs_json, legacy_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        eid,
                        default_type_id,
                        loc_map.get(d.get("object_id")),
                        d.get("inventory_number") or d.get("inv_number"),
                        d.get("serial_number"),
                        name,
                        json.dumps({"legacy_raw": d}, ensure_ascii=False),
                        d["id"],
                    ),
                )
                qr_token = str(uuid.uuid4())
                short_code = f"EQ-{qr_token[:8].upper()}"
                checksum = hashlib.sha256(f"{eid}:{qr_token}".encode("utf-8")).hexdigest()[:16]
                conn.execute(
                    """
                    INSERT INTO qr_identities (id, equipment_id, qr_token, short_code, checksum)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (str(uuid.uuid4()), eid, qr_token, short_code, checksum),
                )
                eq_map[d["id"]] = eid
                manifest["equipment_created"].append(eid)

            # 3. Instruments (only add if serial_no not already in verified seed)
            for row in lconn.execute("SELECT * FROM instruments").fetchall():
                d = dict(row)
                sn = str(d.get("serial_number") or d.get("serial_no") or "").strip()
                if not sn:
                    continue
                if conn.execute("SELECT id FROM instruments WHERE serial_no = ?", (sn,)).fetchone():
                    continue
                iid = str(uuid.uuid4())
                conn.execute(
                    """
                    INSERT INTO instruments (id, name, model, serial_no, status, notes)
                    VALUES (?, ?, ?, ?, 'CALIBRATION', 'Перенесено из legacy etl_production.db')
                    """,
                    (iid, d.get("name") or sn, d.get("model") or d.get("name") or sn, sn),
                )
                manifest["instruments_created"].append(iid)

            # 4. Tests (map protocol_type P1..P6)
            tt_rows = conn.execute("SELECT id, code FROM test_types").fetchall()
            tt_map = {r["code"].upper(): r["id"] for r in tt_rows}
            fallback_tt = tt_map.get("P1")
            default_eq_id = next(iter(eq_map.values()), None)
            if default_eq_id:
                for row in lconn.execute("SELECT * FROM tests").fetchall():
                    d = dict(row)
                    if conn.execute("SELECT id FROM tests WHERE legacy_id = ?", (d["id"],)).fetchone():
                        continue
                    code = str(d.get("test_type") or d.get("protocol_code") or "P1").upper()
                    tt_id = tt_map.get(code, fallback_tt)
                    tid = str(uuid.uuid4())
                    conn.execute(
                        """
                        INSERT INTO tests (id, equipment_id, test_type_id, test_date, status, notes, legacy_id)
                        VALUES (?, ?, ?, ?, 'DRAFT', ?, ?)
                        """,
                        (
                            tid,
                            eq_map.get(d.get("equipment_id"), default_eq_id),
                            tt_id,
                            str(d.get("test_date") or "2026-06-01"),
                            f"Миграция legacy test #{d['id']}",
                            d["id"],
                        ),
                    )
                    manifest["tests_created"].append(tid)

            write_audit_log(
                conn,
                action="LEGACY_MIGRATION",
                entity_type="database",
                after={k: len(v) if isinstance(v, list) else v for k, v in manifest.items()},
                reason="Миграция данных из legacy etl_production.db",
            )
    finally:
        lconn.close()
    return manifest


def rollback_legacy_migration(manifest: Dict[str, Any], target_db_path: Optional[str] = None) -> None:
    with db_session(target_db_path) as conn:
        for tid in manifest.get("tests_created", []):
            conn.execute("DELETE FROM tests WHERE id = ?", (tid,))
        for eid in manifest.get("equipment_created", []):
            conn.execute("DELETE FROM equipment WHERE id = ?", (eid,))
        for iid in manifest.get("instruments_created", []):
            conn.execute("DELETE FROM instruments WHERE id = ?", (iid,))
        for lid in manifest.get("locations_created", []):
            conn.execute("DELETE FROM locations WHERE id = ?", (lid,))
        write_audit_log(conn, action="LEGACY_MIGRATION_ROLLBACK", entity_type="database", reason="Откат миграции legacy БД")
