@echo off
echo Opening TCP port 8080 in Windows Firewall for ARM ETL phone sync...
netsh advfirewall firewall delete rule name="ARM_ETL_8080" >nul 2>&1
netsh advfirewall firewall add rule name="ARM_ETL_8080" dir=in action=allow protocol=TCP localport=8080 profile=private,domain
if errorlevel 1 (
  echo [!] Right-click this file and choose 'Run as administrator'.
) else (
  echo [OK] Port 8080 is open. Your phone can now connect to this laptop.
)
pause
