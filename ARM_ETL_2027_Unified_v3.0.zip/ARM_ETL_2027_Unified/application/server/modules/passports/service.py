from datetime import date
import io
import json
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

from application.server.core.config import PROJECT_ROOT
from application.server.core.storage import save_attachment_bytes
from application.server.modules.passports.templates import get_template_for_type
from application.server.modules.security.audit import write_audit_log

STATUS_RU = {"PASS": "Соответствует", "FAIL": "Не соответствует", "NOT_EVALUATED": "Не оценивалось"}


def _fmt_date(val: Any) -> str:
    s = str(val or "").strip()
    if re.match(r"^\d{4}-\d{2}-\d{2}", s):
        return f"{s[8:10]}.{s[5:7]}.{s[0:4]}"
    return s or "—"


def _set_tnr(run, size=10, bold=False):
    run.font.name = "Times New Roman"
    run.font.size = Pt(size)
    run.bold = bold
    rPr = run._r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rFonts.set(qn(attr), "Times New Roman")


def _set_cell_text(cell, text: str, size: int = 9, bold: bool = False):
    cell.text = ""
    p = cell.paragraphs[0]
    _set_tnr(p.add_run(str(text) if text not in (None, "") else "—"), size=size, bold=bold)


def _mark_table_header_and_nosplit(table):
    if len(table.rows) > 0:
        trPr = table.rows[0]._tr.get_or_add_trPr()
        trPr.append(OxmlElement("w:tblHeader"))
    for row in table.rows:
        trPr = row._tr.get_or_add_trPr()
        trPr.append(OxmlElement("w:cantSplit"))


def _ensure_passport_row(conn, equipment_id: str) -> Dict[str, Any]:
    eq = conn.execute(
        """
        SELECT e.*, et.code AS type_code, et.name AS type_name, l.facility_name AS location_name
        FROM equipment e
        JOIN equipment_types et ON et.id = e.type_id
        LEFT JOIN locations l ON l.id = e.location_id
        WHERE e.id = ?
        """,
        (equipment_id,),
    ).fetchone()
    if not eq:
        raise KeyError("Оборудование не найдено")
    p = conn.execute("SELECT * FROM passports WHERE equipment_id = ?", (equipment_id,)).fetchone()
    if not p:
        pid = str(uuid.uuid4())
        tpl = get_template_for_type(eq["type_code"])
        conn.execute(
            "INSERT INTO passports (id, equipment_id, template_id) VALUES (?, ?, ?)",
            (pid, equipment_id, tpl["template_id"]),
        )
        p = conn.execute("SELECT * FROM passports WHERE id = ?", (pid,)).fetchone()
    return {"equipment": dict(eq), "passport": dict(p)}


def get_equipment_passport(conn, equipment_id: str) -> Dict[str, Any]:
    ctx = _ensure_passport_row(conn, equipment_id)
    eq = ctx["equipment"]
    p = ctx["passport"]
    tpl = get_template_for_type(eq["type_code"])

    orig = None
    if p["original_attachment_id"]:
        row = conn.execute(
            "SELECT id, original_filename, mime_type, size_bytes, sha256, is_original_immutable, uploaded_at FROM attachments WHERE id = ?",
            (p["original_attachment_id"],),
        ).fetchone()
        orig = dict(row) if row else None

    versions = [
        {
            "id": v["id"],
            "version_no": v["version_no"],
            "data": json.loads(v["data_json"] or "{}"),
            "source_test_id": v["source_test_id"],
            "change_reason": v["change_reason"],
            "created_by": v["created_by"],
            "created_at": v["created_at"],
        }
        for v in conn.execute(
            "SELECT * FROM passport_versions WHERE passport_id = ? ORDER BY version_no DESC",
            (p["id"],),
        ).fetchall()
    ]
    current = versions[0] if versions else None
    return {
        "passport_id": p["id"],
        "equipment_id": equipment_id,
        "equipment_name": eq["name"],
        "type_code": eq["type_code"],
        "template": tpl,
        "original_attachment": orig,
        "current_version": current,
        "versions_count": len(versions),
        "versions": versions,
    }


def upload_original_passport(
    conn,
    equipment_id: str,
    content: bytes,
    filename: str,
    mime_type: str,
    user_id: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    ctx = _ensure_passport_row(conn, equipment_id)
    p = ctx["passport"]
    if p["original_attachment_id"]:
        raise PermissionError("Неизменяемый оригинал паспорта уже загружен и защищён от перезаписи (ADR-005)")

    att = save_attachment_bytes(
        conn,
        content=content,
        original_filename=filename,
        mime_type=mime_type,
        entity_type="passport",
        entity_id=p["id"],
        uploaded_by=user_id,
        is_original_immutable=True,
    )
    conn.execute("UPDATE passports SET original_attachment_id = ? WHERE id = ?", (att["id"], p["id"]))
    write_audit_log(
        conn,
        action="PASSPORT_ORIGINAL_UPLOADED",
        entity_type="passport",
        entity_id=p["id"],
        user_id=user_id,
        after={"attachment_id": att["id"], "filename": filename, "sha256": att["sha256"]},
        ip_address=ip_address,
    )
    return {"passport_id": p["id"], "original_attachment": att}


def create_passport_version(
    conn,
    equipment_id: str,
    data: Dict[str, Any],
    change_reason: str,
    user_id: Optional[str] = None,
    source_test_id: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    ctx = _ensure_passport_row(conn, equipment_id)
    p = ctx["passport"]
    row = conn.execute(
        "SELECT COALESCE(MAX(version_no), 0) AS max_v FROM passport_versions WHERE passport_id = ?",
        (p["id"],),
    ).fetchone()
    next_v = int(row["max_v"]) + 1
    vid = str(uuid.uuid4())
    conn.execute(
        """
        INSERT INTO passport_versions (id, passport_id, version_no, data_json, source_test_id, change_reason, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (vid, p["id"], next_v, json.dumps(data, ensure_ascii=False), source_test_id, change_reason, user_id),
    )
    conn.execute("UPDATE passports SET current_version_id = ? WHERE id = ?", (vid, p["id"]))
    write_audit_log(
        conn,
        action="PASSPORT_VERSION_CREATED",
        entity_type="passport",
        entity_id=p["id"],
        user_id=user_id,
        after={"version_no": next_v, "source_test_id": source_test_id},
        reason=change_reason,
        ip_address=ip_address,
    )
    return {"id": vid, "passport_id": p["id"], "version_no": next_v}


def _load_passport_render_context(conn, passport_id: str, version_no: Optional[int]):
    p = conn.execute("SELECT * FROM passports WHERE id = ?", (passport_id,)).fetchone()
    if not p:
        raise KeyError("Паспорт не найден")
    eq = conn.execute(
        """
        SELECT e.*, et.code AS type_code, et.name AS type_name,
               l.facility_name AS location_name, q.short_code
        FROM equipment e
        JOIN equipment_types et ON et.id = e.type_id
        LEFT JOIN locations l ON l.id = e.location_id
        LEFT JOIN qr_identities q ON q.equipment_id = e.id
        WHERE e.id = ?
        """,
        (p["equipment_id"],),
    ).fetchone()
    if version_no is not None and version_no > 0:
        ver = conn.execute(
            "SELECT * FROM passport_versions WHERE passport_id = ? AND version_no = ?",
            (passport_id, version_no),
        ).fetchone()
        if not ver:
            raise KeyError(f"Редакция паспорта № {version_no} не найдена")
    else:
        ver = conn.execute(
            "SELECT * FROM passport_versions WHERE passport_id = ? ORDER BY version_no DESC LIMIT 1",
            (passport_id,),
        ).fetchone()

    v_num = ver["version_no"] if ver else 0
    v_data = json.loads(ver["data_json"] or "{}") if ver else {}
    eq_specs = json.loads(eq["specs_json"] or "{}")
    merged = {**eq_specs, **v_data.get("specs", {})}
    # Always map equipment.model -> type and bearings -> drive/non_drive so motor specs are NEVER blank!
    if not merged.get("type") and eq["model"]:
        merged["type"] = eq["model"]
    if merged.get("bearings") and not merged.get("bearing_drive"):
        b_s = str(merged["bearings"])
        if "/" in b_s:
            b1, b2 = [x.strip() for x in b_s.split("/", 1)]
            merged["bearing_drive"] = b1
            merged.setdefault("bearing_non_drive", b2)
        else:
            merged["bearing_drive"] = b_s
            merged.setdefault("bearing_non_drive", b_s)
    return dict(eq), v_num, v_data, merged


def _render_motor_oge_template_docx(eq: Dict[str, Any], v_num: int, v_data: Dict[str, Any], specs: Dict[str, Any]) -> bytes:
    """Fill the real OGE OOO Surgut Perevalka 4-page booklet template 1-in-1 + append Sections 4-10 test insert."""
    tpl_path = PROJECT_ROOT / "documents" / "templates" / "motor_passport_oge_template.docx"
    doc = Document(str(tpl_path))

    # Table 2: Title page — exact merged value cells verified against OGE template
    t2 = doc.tables[2]
    # Clean outdated approval name/year (201 г. / Е.Ю.Польский)
    _set_cell_text(t2.rows[13].cells[6], "_____________ / Д.Ю. Лиханов", size=9)
    _set_cell_text(t2.rows[14].cells[6], f"«____» ____________ {date.today().year} г.", size=9)
    # Row 21 (cells[4]): Диспетчерское наименование; Row 23 (cells[4]): Объект
    _set_cell_text(t2.rows[21].cells[4], str(eq.get("dispatch_name") or eq.get("name") or "—"), size=10, bold=True)
    _set_cell_text(t2.rows[23].cells[4], str(eq.get("location_name") or "—"), size=10, bold=True)
    # Row 25: cells[3]=Год выпуска, cells[8]=Год установки
    yr = str(eq.get("commissioned_at") or "—")
    _set_cell_text(t2.rows[25].cells[3], str(specs.get("year_manufactured") or yr), size=9)
    _set_cell_text(t2.rows[25].cells[8], yr, size=9)
    # Row 27: cells[2]=Зав.№, cells[7]=Инв.№
    inv_lbl = str(eq.get("inventory_no") or "—")
    if eq.get("short_code"):
        inv_lbl = f"{inv_lbl} ({eq['short_code']})"
    _set_cell_text(t2.rows[27].cells[2], str(eq.get("serial_no") or "—"), size=9)
    _set_cell_text(t2.rows[27].cells[7], inv_lbl, size=9)

    # Table 3: Header metadata
    t3 = doc.tables[3]
    _set_cell_text(t3.rows[1].cells[1], eq.get("location_name") or "—", size=9)
    _set_cell_text(t3.rows[1].cells[3], specs.get("mixture_category") or "—", size=9)
    _set_cell_text(t3.rows[3].cells[1], eq.get("inventory_no") or "—", size=9)
    _set_cell_text(t3.rows[3].cells[3], _fmt_date(eq.get("commissioned_at")), size=9)
    _set_cell_text(t3.rows[5].cells[1], specs.get("explosion_zone_class") or "—", size=9)
    _set_cell_text(t3.rows[5].cells[3], specs.get("year_manufactured") or eq.get("commissioned_at") or "—", size=9)
    _set_cell_text(t3.rows[7].cells[1], eq.get("manufacturer") or "—", size=9)
    _set_cell_text(t3.rows[7].cells[3], eq.get("serial_no") or "—", size=9)

    # Table 4: Section 1 Connection scheme
    if v_data.get("sec_1_scheme"):
        _set_cell_text(doc.tables[4].rows[0].cells[0], f"1. Схема подключения: {v_data['sec_1_scheme']}", size=9)

    # Table 5: Exact 20 technical specs (2-column OGE grid)
    t5 = doc.tables[5]
    left_map = {
        1: specs.get("type") or eq.get("model") or "—",
        2: specs.get("explosion_marking") or "—",
        4: specs.get("explosion_zone_class") or "—",
        5: specs.get("explosion_group") or "—",
        6: specs.get("temp_limit") or "—",
        8: str(specs.get("power_kw")).replace(".", ",") if specs.get("power_kw") not in (None, "") else "—",
        9: specs.get("voltage_v") or "380",
        10: specs.get("current_nom_a") or "—",
        11: specs.get("current_idle_a") or "—",
        12: str(int(float(specs["rpm"]))) if str(specs.get("rpm", "")).replace(".", "", 1).isdigit() else (specs.get("rpm") or "—"),
        13: specs.get("winding_scheme") or "—",
        14: specs.get("phases") or "3",
    }
    right_map = {
        1: specs.get("frequency_hz") or "50",
        2: specs.get("start_method") or "—",
        3: specs.get("efficiency_pct") or "—",
        4: specs.get("cos_phi") or "—",
        5: specs.get("start_current_ratio") or "—",
        7: specs.get("bearing_drive") or "—",
        8: specs.get("bearing_non_drive") or "—",
        9: specs.get("grease_type") or "—",
        10: specs.get("mass_kg") or "—",
        11: specs.get("cable_type") or "—",
        12: specs.get("shaft_and_mounting") or "—",
        13: specs.get("mounting_type") or "—",
    }
    for ri, val in left_map.items():
        if ri < len(t5.rows):
            _set_cell_text(t5.rows[ri].cells[2], str(val), size=9)
    for ri, val in right_map.items():
        if ri < len(t5.rows):
            _set_cell_text(t5.rows[ri].cells[5], str(val), size=9)

    # Fix typo in OGE template ("КОМУТАЦИОННЫЕ" -> "КОММУТАЦИОННЫЕ")
    for cell in doc.tables[6].rows[0].cells:
        if "КОМУТАЦИОННЫЕ" in cell.text:
            _set_cell_text(cell, cell.text.replace("КОМУТАЦИОННЫЕ", "КОММУТАЦИОННЫЕ"), size=9, bold=True)
    # Remove redundant empty spacer paragraphs that push extra blank pages in LibreOffice PDF export
    body_children = list(doc.element.body)
    for idx_el in range(len(body_children) - 1, -1, -1):
        el = body_children[idx_el]
        if el.tag.endswith("}p") and not "".join(el.itertext()).strip():
            has_br = any(b.tag.endswith("}br") for b in el.iter())
            if not has_br:
                doc.element.body.remove(el)
    for sec in doc.sections:
        if sec.top_margin and sec.top_margin > Mm(10):
            sec.top_margin = Mm(10)
        if sec.bottom_margin and sec.bottom_margin > Mm(10):
            sec.bottom_margin = Mm(10)

    # Table 6: Section 3 Switching & RZiA
    if v_data.get("sec_3_rza"):
        _set_cell_text(doc.tables[6].rows[2].cells[0], v_data["sec_3_rza"], size=9)
        _set_cell_text(doc.tables[6].rows[2].cells[2], "См. слева", size=9)
    else:
        _set_cell_text(doc.tables[6].rows[2].cells[0], "—", size=9)
        _set_cell_text(doc.tables[6].rows[2].cells[2], "—", size=9)
    _set_cell_text(doc.tables[6].rows[6].cells[0], eq.get("location_name") or "—", size=9)
    _set_cell_text(doc.tables[6].rows[6].cells[2], eq.get("location_name") or "—", size=9)

    # Manual & structured journal entries in Tables 7, 8, 0 (Sections 11, 12, 13)
    rep_rows = v_data.get("repair_records") or []
    t7 = doc.tables[7]
    r7_idx = 1
    if v_data.get("sec_11_repairs") and r7_idx < len(t7.rows):
        _set_cell_text(t7.rows[r7_idx].cells[2], str(v_data["sec_11_repairs"]), size=8)
        r7_idx += 1
    for rec in rep_rows:
        if r7_idx >= len(t7.rows):
            break
        row = t7.rows[r7_idx].cells
        _set_cell_text(row[0], _fmt_date(rec.get("date")), size=8)
        _set_cell_text(row[1], str(rec.get("order_no") or "—"), size=8)
        _set_cell_text(row[2], str(rec.get("work") or "—"), size=8)
        _set_cell_text(row[3], str(rec.get("executor") or "—"), size=8)
        _set_cell_text(row[4], str(rec.get("note") or ""), size=8)
        r7_idx += 1

    hrs_rows = v_data.get("hours_records") or []
    t8 = doc.tables[8]
    r8_idx = 2
    if v_data.get("sec_12_hours") and r8_idx < len(t8.rows):
        _set_cell_text(t8.rows[r8_idx].cells[2], str(v_data["sec_12_hours"]), size=8)
        r8_idx += 1
    for seq_i, rec in enumerate(hrs_rows, start=1):
        if r8_idx >= len(t8.rows):
            break
        row = t8.rows[r8_idx].cells
        _set_cell_text(row[0], str(seq_i), size=8)
        _set_cell_text(row[1], _fmt_date(rec.get("date")), size=8)
        _set_cell_text(row[2], str(rec.get("hours") or "—"), size=8)
        _set_cell_text(row[3], str(rec.get("facility") or "—"), size=8)
        _set_cell_text(row[4], str(rec.get("unit") or "—"), size=8)
        _set_cell_text(row[5], str(rec.get("responsible") or "—"), size=8)
        _set_cell_text(row[6], str(rec.get("note") or ""), size=8)
        r8_idx += 1

    mov_rows = v_data.get("move_records") or []
    t0 = doc.tables[0]
    r0_idx = 3
    if v_data.get("sec_13_moves") and r0_idx < len(t0.rows):
        _set_cell_text(t0.rows[r0_idx].cells[2], str(v_data["sec_13_moves"]), size=8)
        r0_idx += 1
    for seq_i, rec in enumerate(mov_rows, start=1):
        if r0_idx >= len(t0.rows):
            break
        row = t0.rows[r0_idx].cells
        _set_cell_text(row[0], str(seq_i), size=8)
        _set_cell_text(row[1], _fmt_date(rec.get("date")), size=8)
        _set_cell_text(row[2], str(rec.get("facility") or "—"), size=8)
        _set_cell_text(row[3], str(rec.get("unit") or "—"), size=8)
        _set_cell_text(row[4], str(rec.get("responsible") or "—"), size=8)
        _set_cell_text(row[5], str(rec.get("note") or ""), size=8)
        r0_idx += 1

    # Append clean Insert Page: Sections 4-10 (Auto-filled test results)
    doc.add_page_break()
    ph = doc.add_paragraph()
    ph.paragraph_format.keep_with_next = True
    _set_tnr(ph.add_run(f"ВКЛАДЫШ К ПАСПОРТУ ЭД ({eq.get('inventory_no') or 'б/н'}, Редакция № {v_num}) — Разделы 4–10. Результаты электрических испытаний и измерений"), size=11, bold=True)
    test_rows = v_data.get("test_records", [])
    ttbl = doc.add_table(rows=1, cols=5)
    ttbl.autofit = False
    tblPr = ttbl._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for bname in ("top", "left", "bottom", "right", "insideH", "insideV"):
        b = OxmlElement(f"w:{bname}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), "4")
        b.set(qn("w:color"), "000000")
        borders.append(b)
    tblPr.append(borders)
    widths = [Mm(25), Mm(60), Mm(32), Mm(95), Mm(55)]
    for i, htxt in enumerate(["Дата", "Вид испытания / МВИ", "Протокол №", "Основные результаты", "Заключение"]):
        cell = ttbl.rows[0].cells[i]
        cell.width = widths[i]
        _set_cell_text(cell, htxt, size=9, bold=True)
    if test_rows:
        for tr in test_rows:
            row = ttbl.add_row().cells
            vals = [_fmt_date(tr.get("date")), tr.get("test_type"), tr.get("protocol_no"), tr.get("summary"), tr.get("conclusion")]
            for i, v in enumerate(vals):
                row[i].width = widths[i]
                _set_cell_text(row[i], str(v or "—"), size=9)
    else:
        row = ttbl.add_row().cells
        for i in range(5):
            row[i].width = widths[i]
            _set_cell_text(row[i], "—", size=9)
    _mark_table_header_and_nosplit(ttbl)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def render_passport_docx_bytes(conn, passport_id: str, version_no: Optional[int] = None) -> Tuple[bytes, str]:
    eq, v_num, v_data, merged_specs = _load_passport_render_context(conn, passport_id, version_no)
    safe_inv = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", str(eq["inventory_no"] or eq["short_code"] or passport_id[:8]))
    fname = f"passport_{safe_inv}_v{v_num}.docx"

    # Use real 1-in-1 OGE booklet template for MOTOR
    if eq["type_code"] == "MOTOR" and (PROJECT_ROOT / "documents" / "templates" / "motor_passport_oge_template.docx").exists():
        return _render_motor_oge_template_docx(eq, v_num, v_data, merged_specs), fname

    # Universal GOST A4 passport for all other 9 equipment types (correct section order 1->2->3->4-10->11-13)
    tpl = get_template_for_type(eq["type_code"])
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.left_margin, sec.right_margin, sec.top_margin, sec.bottom_margin = Mm(20), Mm(15), Mm(15), Mm(15)
    doc.styles["Normal"].font.name = "Times New Roman"
    doc.styles["Normal"].font.size = Pt(11)

    h = doc.add_paragraph()
    _set_tnr(h.add_run("ООО «Сургут перевалка» — Отдел главного энергетика (ОГЭ) / ЭТЛ (Свид. № 58ЭТЛ035)"), size=11, bold=True)
    t = doc.add_paragraph()
    _set_tnr(t.add_run(f"ЭЛЕКТРОННЫЙ ПАСПОРТ ОБОРУДОВАНИЯ (Редакция № {v_num})"), size=13, bold=True)
    sub = doc.add_paragraph()
    _set_tnr(sub.add_run(tpl["title"]), size=11)

    tbl = doc.add_table(rows=0, cols=2)
    tbl.style = "Table Grid"
    tbl.autofit = False
    for k, val in [
        ("Наименование", eq["name"]), ("Тип оборудования", eq["type_name"]),
        ("Участок / объект", eq["location_name"] or "—"), ("Инвентарный №", eq["inventory_no"] or "—"),
        ("Заводской №", eq["serial_no"] or "—"), ("Модель / марка", eq["model"] or "—"),
        ("Завод-изготовитель", eq["manufacturer"] or "—"), ("Год ввода", _fmt_date(eq["commissioned_at"])),
        ("QR-код", eq["short_code"] or "—"),
    ]:
        r = tbl.add_row().cells
        r[0].width, r[1].width = Mm(60), Mm(115)
        _set_cell_text(r[0], k, size=10, bold=True)
        _set_cell_text(r[1], str(val), size=10)
    _mark_table_header_and_nosplit(tbl)

    if v_data.get("sec_1_scheme"):
        p1 = doc.add_paragraph()
        p1.paragraph_format.space_before = Pt(8)
        _set_tnr(p1.add_run("Раздел 1. Схема подключения и привязка"), size=11, bold=True)
        _set_tnr(doc.add_paragraph().add_run(str(v_data["sec_1_scheme"])), size=10)

    sec2 = next((s for s in tpl["sections"] if s["code"] == "sec_2"), None)
    if sec2 and sec2.get("fields"):
        p2 = doc.add_paragraph()
        p2.paragraph_format.space_before = Pt(8)
        p2.paragraph_format.keep_with_next = True
        _set_tnr(p2.add_run(f"Раздел {sec2['title']}"), size=11, bold=True)
        stbl = doc.add_table(rows=1, cols=3)
        stbl.style = "Table Grid"
        stbl.autofit = False
        w3 = [Mm(14), Mm(106), Mm(55)]
        for i, htxt in enumerate(["№", "Параметр", "Значение"]):
            stbl.rows[0].cells[i].width = w3[i]
            _set_cell_text(stbl.rows[0].cells[i], htxt, size=10, bold=True)
        for fld in sec2["fields"]:
            r = stbl.add_row().cells
            val = merged_specs.get(fld["key"])
            for i, txt in enumerate([fld["no"], fld["label"], str(val) if val not in (None, "") else "—"]):
                r[i].width = w3[i]
                _set_cell_text(r[i], txt, size=10)
        _mark_table_header_and_nosplit(stbl)

    p4 = doc.add_paragraph()
    p4.paragraph_format.space_before = Pt(8)
    p4.paragraph_format.keep_with_next = True
    _set_tnr(p4.add_run("Разделы 4–10. Результаты электрических испытаний и измерений"), size=11, bold=True)
    ttbl = doc.add_table(rows=1, cols=5)
    ttbl.style = "Table Grid"
    ttbl.autofit = False
    w5 = [Mm(22), Mm(40), Mm(26), Mm(52), Mm(35)]
    for i, htxt in enumerate(["Дата", "Вид испытания / МВИ", "Протокол №", "Результаты", "Заключение"]):
        ttbl.rows[0].cells[i].width = w5[i]
        _set_cell_text(ttbl.rows[0].cells[i], htxt, size=9, bold=True)
    test_rows = v_data.get("test_records", [])
    for tr in (test_rows or [{}]):
        r = ttbl.add_row().cells
        vals = [_fmt_date(tr.get("date")), tr.get("test_type"), tr.get("protocol_no"), tr.get("summary"), tr.get("conclusion")] if tr else ["—"]*5
        for i, txt in enumerate(vals):
            r[i].width = w5[i]
            _set_cell_text(r[i], str(txt or "—"), size=9)
    _mark_table_header_and_nosplit(ttbl)

    for title_txt, body_txt in [
        ("Сведения о ремонтах и ТО", v_data.get("sec_11_repairs")),
        ("Сведения о перемещениях", v_data.get("sec_13_moves")),
    ]:
        if body_txt and str(body_txt).strip():
            pm = doc.add_paragraph()
            pm.paragraph_format.space_before = Pt(8)
            _set_tnr(pm.add_run(title_txt), size=11, bold=True)
            _set_tnr(doc.add_paragraph().add_run(str(body_txt).strip()), size=10)

    ps = doc.add_paragraph()
    ps.paragraph_format.space_before = Pt(14)
    _set_tnr(ps.add_run("Ответственный за электрохозяйство / Начальник ЭТЛ: ______________ / Д. Ю. Лиханов"), size=10)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue(), fname


def find_soffice() -> Optional[str]:
    for cand in ("soffice", "libreoffice"):
        p = shutil.which(cand)
        if p:
            return p
    for win_p in (
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ):
        if os.path.exists(win_p):
            return win_p
    return None


def _ensure_pdf_font() -> str:
    if "ETL2DejaVu" in pdfmetrics.getRegisteredFontNames():
        return "ETL2DejaVu"
    for p in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/times.ttf",
    ):
        if os.path.exists(p):
            pdfmetrics.registerFont(TTFont("ETL2DejaVu", p))
            return "ETL2DejaVu"
    return "Helvetica"


def render_passport_pdf_fallback(eq: Dict[str, Any], v_num: int, v_data: Dict[str, Any], specs: Dict[str, Any]) -> bytes:
    """Pure-Python ReportLab PDF fallback so Windows 10 users NEVER get HTTP 500 without LibreOffice."""
    font = _ensure_pdf_font()
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    pw, ph = A4
    y = ph - 18 * mm
    c.setFont(font, 11)
    c.drawString(18 * mm, y, "ООО «Сургут перевалка» — ОГЭ / ЭТЛ (Свид. № 58ЭТЛ035)")
    y -= 7 * mm
    c.setFont(font, 13)
    c.drawString(18 * mm, y, f"ЭЛЕКТРОННЫЙ ПАСПОРТ ОБОРУДОВАНИЯ (Редакция № {v_num})")
    y -= 7 * mm
    c.setFont(font, 9)
    def _draw_wrapped(text_line: str, fsize: float = 9.0, step_mm: float = 4.8):
        nonlocal y
        c.setFont(font, fsize)
        max_w = pw - 36 * mm
        words = str(text_line).split()
        cur = ""
        for w in words:
            cand = f"{cur} {w}".strip()
            if c.stringWidth(cand, font, fsize) <= max_w:
                cur = cand
            else:
                if cur:
                    if y < 22 * mm:
                        c.showPage()
                        y = ph - 18 * mm
                        c.setFont(font, fsize)
                    c.drawString(18 * mm, y, cur)
                    y -= step_mm * mm
                cur = w
        if cur:
            if y < 22 * mm:
                c.showPage()
                y = ph - 18 * mm
                c.setFont(font, fsize)
            c.drawString(18 * mm, y, cur)
            y -= step_mm * mm

    lines = [
        f"Наименование: {eq.get('name') or '—'}   |   Тип: {eq.get('type_name') or '—'}",
        f"Участок / объект: {eq.get('location_name') or '—'}   |   Инв. №: {eq.get('inventory_no') or '—'}   |   QR: {eq.get('short_code') or '—'}",
        f"Модель / Тип: {specs.get('type') or eq.get('model') or '—'}   |   Зав. №: {eq.get('serial_no') or '—'}   |   Изготовитель: {eq.get('manufacturer') or '—'}",
    ]
    tpl = get_template_for_type(eq.get("type_code") or "MOTOR")
    sec2 = next((s for s in tpl.get("sections", []) if s.get("code") == "sec_2"), None)
    if sec2 and sec2.get("fields"):
        filled = []
        for fld in sec2["fields"]:
            val = specs.get(fld["key"])
            if val not in (None, "", "—"):
                filled.append(f"{fld['label']}: {val}")
        if filled:
            lines.append("Технические характеристики: " + " | ".join(filled))
    if v_data.get("sec_1_scheme"):
        lines.append(f"Раздел 1 (Схема): {v_data['sec_1_scheme']}")
    if v_data.get("sec_3_rza"):
        lines.append(f"Раздел 3 (РЗиА): {v_data['sec_3_rza']}")
    for ln in lines:
        _draw_wrapped(ln, 9.0, 4.8)

    y -= 3 * mm
    c.setFont(font, 10)
    c.drawString(18 * mm, y, "Разделы 4–10. Результаты электрических испытаний:")
    y -= 6 * mm
    c.setFont(font, 8.5)
    recs = v_data.get("test_records", [])
    if recs:
        for tr in recs:
            c.drawString(18 * mm, y, f"{_fmt_date(tr.get('date'))} | № {tr.get('protocol_no') or '—'} | {str(tr.get('summary') or '')[:65]} | {tr.get('conclusion') or ''}"[:115])
            y -= 5 * mm
            if y < 25 * mm:
                c.showPage()
                c.setFont(font, 8.5)
                y = ph - 18 * mm
    else:
        c.drawString(18 * mm, y, "— Записей испытаний пока нет —")
    c.save()
    return buf.getvalue()


def export_passport_bytes(conn, passport_id: str, version_no: Optional[int] = None, fmt: str = "docx") -> Tuple[bytes, str, str]:
    docx_bytes, docx_name = render_passport_docx_bytes(conn, passport_id, version_no)
    if fmt.lower() == "docx":
        return docx_bytes, docx_name, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    if fmt.lower() == "pdf":
        pdf_name = Path(docx_name).with_suffix(".pdf").name
        soffice = find_soffice()
        if soffice:
            try:
                with tempfile.TemporaryDirectory() as td:
                    in_path = os.path.join(td, docx_name)
                    Path(in_path).write_bytes(docx_bytes)
                    subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", td, in_path], check=True, timeout=60, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return Path(os.path.join(td, pdf_name)).read_bytes(), pdf_name, "application/pdf"
            except Exception:
                pass
        # Seamless Windows 10 fallback without LibreOffice!
        eq, v_num, v_data, merged = _load_passport_render_context(conn, passport_id, version_no)
        return render_passport_pdf_fallback(eq, v_num, v_data, merged), pdf_name, "application/pdf"
    raise ValueError("Поддерживаются только форматы 'docx' и 'pdf'")
