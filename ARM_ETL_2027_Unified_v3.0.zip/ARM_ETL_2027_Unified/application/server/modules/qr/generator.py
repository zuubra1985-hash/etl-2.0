import io
import os
from typing import Any, Dict, List, Optional
from PIL import Image, ImageDraw, ImageFont
from reportlab.graphics import renderPDF, renderSVG
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

_FONT_REGISTERED = False


def _ensure_cyrillic_font() -> str:
    global _FONT_REGISTERED
    if _FONT_REGISTERED:
        return "DejaVuSans"
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            pdfmetrics.registerFont(TTFont("DejaVuSans", path))
            _FONT_REGISTERED = True
            return "DejaVuSans"
    return "Helvetica"


def _fit_text(text: str, font_name: str, font_size: float, max_width: float) -> str:
    s = " ".join(str(text or "").split())
    if not s:
        return "—"
    if pdfmetrics.stringWidth(s, font_name, font_size) <= max_width:
        return s
    ell = "…"
    while len(s) > 1 and pdfmetrics.stringWidth(s + ell, font_name, font_size) > max_width:
        s = s[:-1]
    return s.rstrip() + ell


def _wrap_2lines(text: str, font_name: str, font_size: float, max_width: float) -> List[str]:
    s = " ".join(str(text or "").split())
    if pdfmetrics.stringWidth(s, font_name, font_size) <= max_width:
        return [s]
    words = s.split(" ")
    l1, l2 = "", ""
    for w in words:
        cand = (l1 + " " + w).strip()
        if not l2 and pdfmetrics.stringWidth(cand, font_name, font_size) <= max_width:
            l1 = cand
        else:
            l2 = (l2 + " " + w).strip()
    if not l1:
        l1 = _fit_text(s, font_name, font_size, max_width)
        return [l1]
    return [l1, _fit_text(l2, font_name, font_size, max_width)]


def render_qr_svg(url: str, size_px: int = 240) -> bytes:
    widget = qr.QrCodeWidget(url, barLevel="M")
    bounds = widget.getBounds()
    w, h = bounds[2] - bounds[0], bounds[3] - bounds[1]
    d = Drawing(size_px, size_px, transform=[size_px / w, 0, 0, size_px / h, 0, 0])
    d.add(widget)
    return renderSVG.drawToString(d).encode("utf-8")


def _load_pil_font(size: int, bold: bool = False):
    cands = (
        [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
            "C:/Windows/Fonts/calibrib.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "C:/Windows/Fonts/arial.ttf",
        ]
        if bold
        else [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "C:/Windows/Fonts/arial.ttf",
            "C:/Windows/Fonts/calibri.ttf",
        ]
    )
    for p in cands:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def _pil_wrap(draw: ImageDraw.ImageDraw, text: str, font, max_w: int, max_lines: int = 2) -> List[str]:
    words = str(text or "").split()
    if not words:
        return ["—"]
    lines: List[str] = []
    cur = ""
    for w in words:
        cand = f"{cur} {w}".strip()
        if draw.textlength(cand, font=font) <= max_w:
            cur = cand
        else:
            if cur:
                lines.append(cur)
                if len(lines) >= max_lines:
                    break
            cur = w
    if cur and len(lines) < max_lines:
        lines.append(cur)
    # Truncate last line with ellipsis if still too wide
    if lines:
        last = lines[-1]
        while draw.textlength(last, font=font) > max_w and len(last) > 3:
            last = last[:-2].rstrip() + "…"
        lines[-1] = last
    return lines


def render_qr_png(url: str, size_px: int = 300, label_info: Optional[Dict[str, Any]] = None) -> bytes:
    widget = qr.QrCodeWidget(url, barLevel="M")
    widget.qr.make()
    matrix = widget.qr.modules
    n = len(matrix)
    quiet = 3
    total_modules = n + 2 * quiet
    scale = max(2, size_px // total_modules)
    qr_size = total_modules * scale
    qr_img = Image.new("RGB", (qr_size, qr_size), "white")
    qdraw = ImageDraw.Draw(qr_img)
    for r, row in enumerate(matrix):
        for c, val in enumerate(row):
            if val:
                x0 = (c + quiet) * scale
                y0 = (r + quiet) * scale
                qdraw.rectangle([x0, y0, x0 + scale - 1, y0 + scale - 1], fill="black")

    if not label_info:
        buf = io.BytesIO()
        qr_img.save(buf, format="PNG")
        return buf.getvalue()

    # Compose printable labeled PNG badge with explicit installation location & equipment name
    pad = 18
    text_w = 430
    W = pad + qr_size + pad + text_w + pad
    H = max(qr_size + 2 * pad, 340)
    img = Image.new("RGB", (W, H), "white")
    draw = ImageDraw.Draw(img)
    draw.rectangle([3, 3, W - 4, H - 4], outline="#1e293b", width=3)
    img.paste(qr_img, (pad, (H - qr_size) // 2))

    tx = pad + qr_size + pad
    mw = text_w
    f_org = _load_pil_font(16, bold=False)
    f_loc = _load_pil_font(22, bold=True)
    f_name = _load_pil_font(19, bold=True)
    f_meta = _load_pil_font(17, bold=False)
    f_spec = _load_pil_font(15, bold=False)

    y = 18
    draw.text((tx, y), "ООО «Сургут перевалка» • ЭТЛ", fill="#475569", font=f_org)
    y += 28

    # Highlighted installation location banner
    loc_text = f"МЕСТО: {label_info.get('location_name') or 'Не указано'}"
    loc_lines = _pil_wrap(draw, loc_text, f_loc, mw - 16, max_lines=2)
    box_h = 12 + len(loc_lines) * 28
    draw.rectangle([tx, y, tx + mw, y + box_h], fill="#0f172a")
    ly = y + 6
    for ln in loc_lines:
        draw.text((tx + 8, ly), ln, fill="white", font=f_loc)
        ly += 28
    y += box_h + 12

    # Equipment name (up to 2 lines)
    for ln in _pil_wrap(draw, label_info.get("name") or "Оборудование", f_name, mw, max_lines=2):
        draw.text((tx, y), ln, fill="#0f172a", font=f_name)
        y += 25
    y += 6

    # Inventory No & Short Code
    inv_line = f"Инв. №: {label_info.get('inventory_no') or '—'}   |   {label_info.get('short_code') or ''}"
    for ln in _pil_wrap(draw, inv_line, f_meta, mw, max_lines=1):
        draw.text((tx, y), ln, fill="#1e293b", font=f_meta)
        y += 24

    # Specs / Model
    spec_txt = label_info.get("specs_line") or label_info.get("model") or ""
    if spec_txt:
        for ln in _pil_wrap(draw, spec_txt, f_spec, mw, max_lines=2):
            draw.text((tx, y), ln, fill="#475569", font=f_spec)
            y += 20

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _draw_qr_on_canvas(c: canvas.Canvas, url: str, x: float, y: float, size: float) -> None:
    widget = qr.QrCodeWidget(url, barLevel="M")
    b = widget.getBounds()
    w, h = b[2] - b[0], b[3] - b[1]
    d = Drawing(size, size, transform=[size / w, 0, 0, size / h, 0, 0])
    d.add(widget)
    renderPDF.draw(d, c, x, y)


def render_qr_labels_pdf(items: List[Dict[str, Any]], preset: str = "a4_3x7") -> bytes:
    font_name = _ensure_cyrillic_font()
    buf = io.BytesIO()

    if preset == "thermal_58x40":
        pw, ph = 58 * mm, 40 * mm
        c = canvas.Canvas(buf, pagesize=(pw, ph))
        for item in items:
            _draw_qr_on_canvas(c, item["qr_url"], 1.5 * mm, 10.5 * mm, 24.5 * mm)
            tx, mw = 27.2 * mm, 29.3 * mm
            c.setFont(font_name, 5.4)
            c.drawString(tx, 33.5 * mm, _fit_text("ООО «Сургут перевалка»", font_name, 5.4, mw))
            c.setFont(font_name, 6.0)
            c.drawString(tx, 28.8 * mm, _fit_text(item.get("short_code") or "", font_name, 6.0, mw))
            c.setFont(font_name, 5.6)
            c.drawString(tx, 24.2 * mm, _fit_text(f"Инв. №: {item.get('inventory_no') or '—'}", font_name, 5.6, mw))
            c.setFont(font_name, 5.4)
            c.drawString(tx, 19.6 * mm, _fit_text(item.get("location_name") or "—", font_name, 5.4, mw))
            spec_lines = _wrap_2lines(item.get("specs_line") or item.get("model") or "—", font_name, 5.0, mw)
            c.setFont(font_name, 5.0)
            c.drawString(tx, 15.2 * mm, spec_lines[0])
            if len(spec_lines) > 1:
                c.drawString(tx, 11.8 * mm, spec_lines[1])
            lines = _wrap_2lines(item.get("name") or "", font_name, 5.2, 54.5 * mm)
            c.setFont(font_name, 5.2)
            c.drawString(1.8 * mm, 6.2 * mm, lines[0])
            if len(lines) > 1:
                c.drawString(1.8 * mm, 2.5 * mm, lines[1])
            c.showPage()
        c.save()
        return buf.getvalue()

    if preset == "thermal_43x25":
        pw, ph = 43 * mm, 25 * mm
        c = canvas.Canvas(buf, pagesize=(pw, ph))
        for item in items:
            _draw_qr_on_canvas(c, item["qr_url"], 1.5 * mm, 4.8 * mm, 18.0 * mm)
            tx, mw = 20.5 * mm, 21.2 * mm
            c.setFont(font_name, 5.4)
            c.drawString(tx, 20.2 * mm, _fit_text(item.get("short_code") or "", font_name, 5.4, mw))
            c.setFont(font_name, 5.0)
            c.drawString(tx, 16.0 * mm, _fit_text(f"Инв. {item.get('inventory_no') or '—'}", font_name, 5.0, mw))
            c.setFont(font_name, 4.8)
            c.drawString(tx, 11.8 * mm, _fit_text(item.get("location_name") or "—", font_name, 4.8, mw))
            c.setFont(font_name, 4.5)
            c.drawString(tx, 7.6 * mm, _fit_text(item.get("specs_line") or item.get("model") or "—", font_name, 4.5, mw))
            c.setFont(font_name, 4.6)
            c.drawString(1.5 * mm, 1.6 * mm, _fit_text(item.get("name") or "", font_name, 4.6, 40.0 * mm))
            c.showPage()
        c.save()
        return buf.getvalue()

    # Default: A4 3x7 self-adhesive label grid (21 labels per page, clean margins, zero border overlap!)
    pw, ph = A4
    c = canvas.Canvas(buf, pagesize=A4)
    cols, rows = 3, 7
    margin_x, margin_y = 8 * mm, 12 * mm
    cell_w = (pw - 2 * margin_x) / cols
    cell_h = (ph - 2 * margin_y) / rows

    for idx, item in enumerate(items):
        slot = idx % (cols * rows)
        if idx > 0 and slot == 0:
            c.showPage()
        col = slot % cols
        row = slot // cols
        x0 = margin_x + col * cell_w
        y0 = ph - margin_y - (row + 1) * cell_h

        c.setLineWidth(0.35)
        c.rect(x0 + 1 * mm, y0 + 1 * mm, cell_w - 2 * mm, cell_h - 2 * mm)
        _draw_qr_on_canvas(c, item["qr_url"], x0 + 2 * mm, y0 + 10.0 * mm, 24.5 * mm)

        tx = x0 + 28 * mm
        mw = cell_w - 30.2 * mm
        c.setFont(font_name, 5.8)
        c.drawString(tx, y0 + cell_h - 5.8 * mm, _fit_text("ООО «Сургут перевалка»", font_name, 5.8, mw))
        c.setFont(font_name, 6.5)
        c.drawString(tx, y0 + cell_h - 10.6 * mm, _fit_text(item.get("short_code") or "", font_name, 6.5, mw))
        c.setFont(font_name, 5.8)
        c.drawString(tx, y0 + cell_h - 15.2 * mm, _fit_text(f"Инв. №: {item.get('inventory_no') or '—'}", font_name, 5.8, mw))
        c.setFont(font_name, 5.6)
        c.drawString(tx, y0 + cell_h - 19.6 * mm, _fit_text(f"Объект: {item.get('location_name') or '—'}", font_name, 5.6, mw))
        spec_lines = _wrap_2lines(item.get("specs_line") or item.get("model") or "—", font_name, 5.2, mw)
        c.setFont(font_name, 5.2)
        c.drawString(tx, y0 + cell_h - 24.0 * mm, spec_lines[0])
        if len(spec_lines) > 1:
            c.drawString(tx, y0 + cell_h - 27.4 * mm, spec_lines[1])

        lines = _wrap_2lines(item.get("name") or "", font_name, 5.4, cell_w - 5 * mm)
        c.setFont(font_name, 5.4)
        c.drawString(x0 + 2.5 * mm, y0 + 5.8 * mm, lines[0])
        if len(lines) > 1:
            c.drawString(x0 + 2.5 * mm, y0 + 2.4 * mm, lines[1])

    c.save()
    return buf.getvalue()
