import hashlib
import json
from typing import Any, Dict, List, Optional, Tuple
from application.server.core.config import load_settings
from application.server.core.storage import save_attachment_bytes
from application.server.modules.qr.generator import render_qr_labels_pdf, render_qr_png, render_qr_svg
from application.server.modules.security.audit import write_audit_log


def _detect_lan_ip() -> str:
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def build_qr_url(qr_token: str) -> str:
    base = load_settings().get("app", {}).get("base_url", "http://127.0.0.1:8080").rstrip("/")
    if "127.0.0.1" in base or "localhost" in base:
        lan = _detect_lan_ip()
        if lan and lan != "127.0.0.1":
            base = base.replace("127.0.0.1", lan).replace("localhost", lan)
    return f"{base}/eq/{qr_token}"


def compute_qr_checksum(equipment_id: str, qr_token: str) -> str:
    return hashlib.sha256(f"{equipment_id}:{qr_token}".encode("utf-8")).hexdigest()[:16]


def verify_equipment_qr(conn, equipment_id: str) -> Dict[str, Any]:
    row = conn.execute(
        """
        SELECT q.*, e.name AS equipment_name, e.status AS equipment_status, e.is_archived
        FROM qr_identities q JOIN equipment e ON e.id = q.equipment_id
        WHERE q.equipment_id = ?
        """,
        (equipment_id,),
    ).fetchone()
    if not row:
        raise KeyError("QR-идентификатор для оборудования не найден")
    expected = compute_qr_checksum(row["equipment_id"], row["qr_token"])
    return {
        "equipment_id": row["equipment_id"],
        "equipment_name": row["equipment_name"],
        "qr_token": row["qr_token"],
        "short_code": row["short_code"],
        "qr_url": build_qr_url(row["qr_token"]),
        "checksum_valid": expected == row["checksum"],
        "print_count": row["print_count"],
        "last_printed_at": row["last_printed_at"],
        "is_archived": bool(row["is_archived"]),
    }


def resolve_qr_token(conn, qr_token: str, user_id: str, ip_address: Optional[str] = None) -> Dict[str, Any]:
    row = conn.execute(
        """
        SELECT q.*, e.name AS equipment_name, e.model, e.specs_json, e.inventory_no, e.serial_no,
               e.status AS equipment_status, e.is_archived,
               et.code AS type_code, et.name AS type_name,
               l.facility_name AS location_name
        FROM qr_identities q
        JOIN equipment e ON e.id = q.equipment_id
        JOIN equipment_types et ON et.id = e.type_id
        LEFT JOIN locations l ON l.id = e.location_id
        WHERE q.qr_token = ? OR upper(q.short_code) = upper(?)
        """,
        (qr_token.strip(), qr_token.strip()),
    ).fetchone()
    if not row:
        raise KeyError("QR-код не найден в реестре ETL 2.0")

    expected = compute_qr_checksum(row["equipment_id"], row["qr_token"])
    if expected != row["checksum"]:
        raise RuntimeError("Нарушена контрольная сумма привязки QR-кода!")

    write_audit_log(
        conn,
        action="QR_SCANNED",
        entity_type="equipment",
        entity_id=row["equipment_id"],
        user_id=user_id,
        after={"short_code": row["short_code"]},
        ip_address=ip_address,
    )
    return {
        "equipment_id": row["equipment_id"],
        "short_code": row["short_code"],
        "qr_token": row["qr_token"],
        "equipment_name": row["equipment_name"],
        "type_code": row["type_code"],
        "type_name": row["type_name"],
        "model": row["model"],
        "inventory_no": row["inventory_no"],
        "location_name": row["location_name"],
        "specs_line": _fmt_specs_line(row["model"], row["specs_json"]),
        "status": row["equipment_status"],
        "checksum_valid": True,
        "redirect_url": f"/mobile?equipment_id={row['equipment_id']}",
    }


def get_qr_image_bytes(conn, equipment_id: str, fmt: str = "png") -> Tuple[bytes, str]:
    info = verify_equipment_qr(conn, equipment_id)
    if fmt.lower() == "svg":
        return render_qr_svg(info["qr_url"]), "image/svg+xml"
    if fmt.lower() == "png":
        row = conn.execute(
            """
            SELECT e.name, e.model, e.inventory_no, e.specs_json, l.facility_name AS location_name
            FROM equipment e
            LEFT JOIN locations l ON l.id = e.location_id
            WHERE e.id = ?
            """,
            (equipment_id,),
        ).fetchone()
        label_info = {
            "short_code": info["short_code"],
            "name": row["name"] if row else "",
            "inventory_no": row["inventory_no"] if row else "",
            "model": row["model"] if row else "",
            "location_name": row["location_name"] if row else "",
            "specs_line": _fmt_specs_line(row["model"], row["specs_json"]) if row else "",
        }
        return render_qr_png(info["qr_url"], label_info=label_info), "image/png"
    raise ValueError("Поддерживаются только форматы 'png' и 'svg'")


def print_qr_batch_pdf(
    conn,
    equipment_ids: List[str],
    preset: str,
    user_id: str,
    ip_address: Optional[str] = None,
) -> Tuple[bytes, str]:
    if not equipment_ids:
        raise ValueError("Список оборудования для печати QR пуст")
    if preset not in ("a4_3x7", "thermal_58x40", "thermal_43x25"):
        raise ValueError("Неизвестный формат печати (допустимо: a4_3x7, thermal_58x40, thermal_43x25)")

    items = []
    for eid in equipment_ids:
        row = conn.execute(
            """
            SELECT q.id AS qr_id, q.qr_token, q.short_code,
                   e.id AS equipment_id, e.name, e.model, e.inventory_no, e.specs_json,
                   l.facility_name AS location_name
            FROM qr_identities q
            JOIN equipment e ON e.id = q.equipment_id
            LEFT JOIN locations l ON l.id = e.location_id
            WHERE e.id = ?
            """,
            (eid,),
        ).fetchone()
        if not row:
            raise KeyError(f"Оборудование '{eid}' не найдено")
        items.append({
            "equipment_id": row["equipment_id"],
            "name": row["name"],
            "inventory_no": row["inventory_no"],
            "location_name": row["location_name"],
            "model": row["model"],
            "specs_line": _fmt_specs_line(row["model"], row["specs_json"]),
            "short_code": row["short_code"],
            "qr_url": build_qr_url(row["qr_token"]),
        })
        conn.execute(
            "UPDATE qr_identities SET print_count = print_count + 1, last_printed_at = datetime('now') WHERE id = ?",
            (row["qr_id"],),
        )

    pdf_bytes = render_qr_labels_pdf(items, preset=preset)
    fname = f"qr_labels_{preset}_{len(items)}pcs.pdf"
    save_attachment_bytes(conn, pdf_bytes, fname, "application/pdf", "qr_batch", items[0]["equipment_id"], uploaded_by=user_id)
    write_audit_log(
        conn,
        action="QR_BATCH_PRINTED",
        entity_type="qr_batch",
        user_id=user_id,
        after={"preset": preset, "count": len(items), "equipment_ids": equipment_ids},
        ip_address=ip_address,
    )
    return pdf_bytes, fname


def _fmt_specs_line(model, specs_json):
    sp = json.loads(specs_json or "{}")
    parts = []
    if model:
        parts.append(str(model))
    if sp.get("power_kw") not in (None, ""):
        parts.append(f"{sp['power_kw']} кВт")
    if sp.get("rpm") not in (None, ""):
        parts.append(f"{int(float(sp['rpm']))} об/мин" if str(sp["rpm"]).replace(".", "", 1).isdigit() else str(sp["rpm"]))
    return ", ".join(parts) if parts else "—"
