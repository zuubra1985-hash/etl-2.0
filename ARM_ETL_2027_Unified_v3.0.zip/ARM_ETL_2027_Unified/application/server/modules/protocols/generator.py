import io
import os
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Tuple
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt

UPDATED_NORM_DOCS = [
    "ПТЭЭП (утв. Приказом Минэнерго РФ от 12.08.2022 № 811)",
    "ПОТЭЭ (утв. Приказом Минтруда РФ от 15.12.2020 № 903н в ред. Приказа № 279н)",
    "ПУЭ (7-е издание, Глава 1.8)",
    "ГОСТ Р 50571.16-2019 (Электроустановки низковольтные. Испытания)",
    "СТО 34.01-23.1-001-2017 (Объём и нормы испытаний электрооборудования)",
]

COMP_RU = {"PASS": "Соответствует", "FAIL": "Не соответствует", "NOT_EVALUATED": "Не оценивалось"}


def _fmt_date(val: Any) -> str:
    s = str(val or "").strip()
    if re.match(r"^\d{4}-\d{2}-\d{2}", s):
        return f"{s[8:10]}.{s[5:7]}.{s[0:4]}"
    return s or "—"


def _run(par, text: str, size: int = 11, bold: bool = False):
    r = par.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(size)
    r.bold = bold
    rPr = r._r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rFonts.set(qn(attr), "Times New Roman")
    return r


def _style_table(table, widths_mm: List[float]):
    table.style = "Table Grid"
    table.autofit = False
    if len(table.rows) > 0:
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    for row in table.rows:
        row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        for i, w in enumerate(widths_mm):
            if i < len(row.cells):
                row.cells[i].width = Mm(w)


def compute_conclusion(measurements: List[Dict[str, Any]]) -> str:
    if not measurements:
        return "Измерения отсутствуют — заключение не сформировано"
    statuses = {m.get("compliance_status") for m in measurements}
    if "FAIL" in statuses:
        return "НЕ СООТВЕТСТВУЕТ требованиям нормативной документации (выявлены отклонения)"
    if "NOT_EVALUATED" in statuses:
        return "ТРЕБУЕТ ЭКСПЕРТНОЙ ОЦЕНКИ (часть параметров без утверждённых критериев НД)"
    return "СООТВЕТСТВУЕТ требованиям нормативной документации (ПТЭЭП № 811, ПУЭ 7-е изд.)"


def render_protocol_docx(
    protocol_no: str,
    version_no: int,
    org_cfg: Dict[str, Any],
    test_info: Dict[str, Any],
    equipment_info: Dict[str, Any],
    measurements: List[Dict[str, Any]],
    instruments: List[Dict[str, Any]],
    executor_name: str,
) -> Tuple[bytes, str]:
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.left_margin, sec.right_margin, sec.top_margin, sec.bottom_margin = Mm(20), Mm(15), Mm(15), Mm(15)
    doc.styles["Normal"].font.name = "Times New Roman"
    doc.styles["Normal"].font.size = Pt(11)

    # 1x3 Header table (175 mm total)
    htbl = doc.add_table(rows=1, cols=3)
    c0, c1, c2 = htbl.rows[0].cells
    _run(c0.paragraphs[0], f"{org_cfg.get('name', 'ООО «Сургут перевалка»')}\n{org_cfg.get('department', 'ОГЭ / ЭТЛ')}", size=9, bold=True)
    _run(
        c1.paragraphs[0],
        f"Свидетельство о регистрации ЭТЛ № {org_cfg.get('registration_cert_no', '58ЭТЛ035')} от {_fmt_date(org_cfg.get('registration_cert_date', '2024-12-25'))}\n"
        f"(действительно до {_fmt_date(org_cfg.get('registration_valid_until', '2027-12-25'))})\n"
        f"{org_cfg.get('authority', 'Северо-Уральское управление Ростехнадзора')}",
        size=9,
    )
    _run(c2.paragraphs[0], "УТВЕРЖДАЮ\n", size=9, bold=True)
    _run(c2.paragraphs[0], f"Начальник ЭТЛ\n________ / {org_cfg.get('head_of_etl', 'Лиханов Д. Ю.')}", size=9)
    _style_table(htbl, [52, 75, 48])

    tp = doc.add_paragraph()
    tp.paragraph_format.space_before = Pt(10)
    _run(tp, f"ПРОТОКОЛ № {protocol_no} (ред. {version_no})", size=13, bold=True)
    sub = doc.add_paragraph()
    tname = str(test_info.get("test_type_name") or "").replace("Протокол ", "").strip()
    _run(sub, f"{tname} ({test_info.get('methodology_code') or 'МВИ'})", size=11, bold=True)

    # General fields (1..8 sequential, no gaps)
    gtbl = doc.add_table(rows=0, cols=2)
    t_s = str(test_info["temp_c"]).replace(".", ",") if test_info.get("temp_c") is not None else "—"
    h_s = str(test_info["humidity_pct"]).replace(".", ",") if test_info.get("humidity_pct") is not None else "—"
    p_s = str(test_info["pressure_mmhg"]).replace(".", ",") if test_info.get("pressure_mmhg") is not None else "—"
    for label, val in [
        ("1. Объект / участок", equipment_info.get("location_name") or "—"),
        ("2. Электрооборудование", equipment_info.get("name") or "—"),
        ("3. Тип / модель", equipment_info.get("model") or "—"),
        ("4. Инв. № / Зав. № / QR", f"{equipment_info.get('inventory_no') or '—'} / {equipment_info.get('serial_no') or '—'} / {equipment_info.get('short_code') or '—'}"),
        ("5. Дата проведения испытания", _fmt_date(test_info.get("test_date"))),
        ("6. Цель испытания", test_info.get("purpose") or "—"),
        ("7. Климатические условия", f"t = {t_s} °C; φ = {h_s} %; P = {p_s} мм рт. ст."),
        ("8. Нормативная документация", "См. Приложение 1"),
    ]:
        row = gtbl.add_row().cells
        _run(row[0].paragraphs[0], label, size=10, bold=True)
        _run(row[1].paragraphs[0], str(val), size=10)
    _style_table(gtbl, [58, 117])

    # Appendix 1: Normative docs
    p1 = doc.add_paragraph()
    p1.paragraph_format.space_before = Pt(8)
    p1.paragraph_format.keep_with_next = True
    _run(p1, "Приложение 1. Перечень нормативной документации", size=11, bold=True)
    _run(doc.add_paragraph(), "; ".join(UPDATED_NORM_DOCS) + ".", size=9.5)

    # Appendix 2: Measurements (175 mm total, proportional widths)
    p2 = doc.add_paragraph()
    p2.paragraph_format.space_before = Pt(8)
    p2.paragraph_format.keep_with_next = True
    _run(p2, "Приложение 2. Результаты измерений и испытаний", size=11, bold=True)
    mtbl = doc.add_table(rows=1, cols=6)
    for i, h in enumerate(["№", "Точка измерения", "Параметр", "Значение", "Ед.", "Оценка / НД"]):
        _run(mtbl.rows[0].cells[i].paragraphs[0], h, size=9, bold=True)
    for idx, m in enumerate(measurements, 1):
        row = mtbl.add_row().cells
        comp_txt = COMP_RU.get(m.get("compliance_status", "NOT_EVALUATED"), "Не оценивалось")
        if m.get("norm_ref"):
            comp_txt = f"{comp_txt} ({m['norm_ref']})"
        val_s = str(m.get("raw_value", "")).replace(".", ",")
        for i, v in enumerate([str(idx), m.get("point_label") or "—", m.get("parameter_name") or m.get("parameter_code"), val_s, m.get("unit") or "—", comp_txt]):
            _run(row[i].paragraphs[0], v, size=9)
    _style_table(mtbl, [10, 34, 48, 22, 14, 47])

    # Appendix 3: Instruments (175 mm total)
    p3 = doc.add_paragraph()
    p3.paragraph_format.space_before = Pt(8)
    p3.paragraph_format.keep_with_next = True
    _run(p3, "Приложение 3. Сведения о применённых средствах измерений (СИ)", size=11, bold=True)
    stbl = doc.add_table(rows=1, cols=5)
    for i, h in enumerate(["№", "Тип / модель СИ", "Зав. №", "Рег. № ФИФ ОЕИ", "Поверка до"]):
        _run(stbl.rows[0].cells[i].paragraphs[0], h, size=9, bold=True)
    for idx, si in enumerate(instruments, 1):
        row = stbl.add_row().cells
        for i, v in enumerate([str(idx), si.get("model") or "—", si.get("serial_no") or "—", si.get("arshin_reg_no") or "—", _fmt_date(si.get("calibration_valid_until"))]):
            _run(row[i].paragraphs[0], v, size=9)
    _style_table(stbl, [10, 62, 30, 40, 33])

    conclusion = compute_conclusion(measurements)
    pc = doc.add_paragraph()
    pc.paragraph_format.space_before = Pt(10)
    _run(pc, "Заключение: ", size=11, bold=True)
    _run(pc, conclusion, size=11)

    eb = test_info.get("executor_eb_group")
    eb_str = f" (гр. {eb})" if eb and eb != "-" else ""
    ps = doc.add_paragraph()
    ps.paragraph_format.space_before = Pt(12)
    _run(ps, f"Испытания провёл: ____________________ / {executor_name}{eb_str}\n", size=10)
    _run(ps, f"Проверил (Начальник ЭТЛ): ____________ / {org_cfg.get('head_of_etl', 'Лиханов Д. Ю.')} (гр. V)", size=10)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue(), conclusion


def convert_docx_bytes_to_pdf(docx_bytes: bytes, filename_stem: str) -> bytes:
    from application.server.modules.passports.service import find_soffice
    so = find_soffice()
    if not so:
        raise FileNotFoundError("LibreOffice not installed")
    with tempfile.TemporaryDirectory() as td:
        in_p = os.path.join(td, f"{filename_stem}.docx")
        Path(in_p).write_bytes(docx_bytes)
        subprocess.run([so, "--headless", "--convert-to", "pdf", "--outdir", td, in_p], check=True, timeout=60, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return Path(os.path.join(td, f"{filename_stem}.pdf")).read_bytes()
