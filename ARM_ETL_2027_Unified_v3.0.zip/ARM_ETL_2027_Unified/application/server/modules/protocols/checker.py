import io
from typing import Any, Dict, List
from docx import Document


def check_protocol_docx(docx_bytes: bytes, expected_cert: str = "58ЭТЛ035") -> Dict[str, Any]:
    doc = Document(io.BytesIO(docx_bytes))
    all_text_parts: List[str] = [p.text for p in doc.paragraphs]
    for t in doc.tables:
        for r in t.rows:
            for c in r.cells:
                all_text_parts.append(c.text)
    full_text = "\n".join(all_text_parts)

    errors: List[str] = []
    if expected_cert not in full_text:
        errors.append(f"Отсутствует номер свидетельства регистрации ЭТЛ ({expected_cert})")
    if "Приказ № 6" in full_text or "Приказом Минэнерго РФ от 13.01.2003 № 6" in full_text:
        errors.append("Обнаружена устаревшая ссылка на отменённый Приказ № 6 от 2003 г.")
    if "811" not in full_text:
        errors.append("Отсутствует ссылка на действующие ПТЭЭП № 811")
    if len(doc.tables) < 4:
        errors.append(f"Ожидалось минимум 4 таблицы (шапка, сведения, измерения, СИ), найдено: {len(doc.tables)}")

    return {
        "passed": len(errors) == 0,
        "tables_count": len(doc.tables),
        "errors": errors,
    }
