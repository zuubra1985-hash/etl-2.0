import json
import uuid
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from application.server.core.config import load_settings
from application.server.core.storage import save_attachment_bytes
from application.server.modules.protocols.checker import check_protocol_docx
from application.server.modules.protocols.generator import convert_docx_bytes_to_pdf, render_protocol_docx
from application.server.modules.security.audit import write_audit_log

VALID_TRANSITIONS = {
    "GENERATED": {"REVIEWED", "SIGNED", "REVISED"},
    "REVIEWED": {"SIGNED", "REVISED"},
    "SIGNED": {"REVISED"},
    "REVISED": {"GENERATED"},
}


def next_protocol_number(conn, test_date: str) -> str:
    ym = str(test_date)[:7] if len(str(test_date)) >= 7 else "2026-11"
    cnt = conn.execute(
        "SELECT COUNT(DISTINCT protocol_no) FROM protocols WHERE protocol_no LIKE ?",
        (f"{ym}-%",),
    ).fetchone()[0]
    return f"{ym}-{cnt + 1:03d}"


def generate_protocol_for_test(
    conn,
    test_id: str,
    user_id: str,
    generate_pdf: bool = True,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    t = conn.execute(
        """
        SELECT t.*, tt.code AS test_type_code, tt.name AS test_type_name,
               m.code AS methodology_code, u.full_name AS executor_name, u.eb_group AS executor_eb_group
        FROM tests t
        JOIN test_types tt ON tt.id = t.test_type_id
        LEFT JOIN methodologies m ON m.id = tt.methodology_id
        LEFT JOIN users u ON u.id = t.executor_user_id
        WHERE t.id = ?
        """,
        (test_id,),
    ).fetchone()
    if not t:
        raise KeyError("Испытание не найдено")

    eq = conn.execute(
        """
        SELECT e.*, l.facility_name AS location_name, q.short_code
        FROM equipment e
        LEFT JOIN locations l ON l.id = e.location_id
        LEFT JOIN qr_identities q ON q.equipment_id = e.id
        WHERE e.id = ?
        """,
        (t["equipment_id"],),
    ).fetchone()

    measurements = [
        dict(r)
        for r in conn.execute(
            """
            SELECT m.*, mp.code AS parameter_code, mp.name AS parameter_name
            FROM measurements m
            JOIN measurement_parameters mp ON mp.id = m.parameter_id
            WHERE m.test_id = ? AND m.is_superseded = 0
            ORDER BY m.created_at ASC
            """,
            (test_id,),
        ).fetchall()
    ]
    if not measurements:
        raise ValueError("Невозможно сформировать протокол: нет активных измерений")

    instruments = json.loads(t["instruments_snapshot_json"] or "[]")
    prev = conn.execute(
        "SELECT protocol_no, MAX(version_no) AS mv FROM protocols WHERE test_id = ?",
        (test_id,),
    ).fetchone()
    if prev and prev["protocol_no"]:
        proto_no = prev["protocol_no"]
        v_no = int(prev["mv"]) + 1
    else:
        proto_no = next_protocol_number(conn, t["test_date"])
        v_no = 1

    cfg = load_settings()
    docx_bytes, conclusion = render_protocol_docx(
        protocol_no=proto_no,
        version_no=v_no,
        org_cfg=cfg.get("organization", {}),
        test_info=dict(t),
        equipment_info=dict(eq),
        measurements=measurements,
        instruments=instruments,
        executor_name=t["executor_name"] or "Инженер ЭТЛ",
    )

    qa = check_protocol_docx(docx_bytes, expected_cert=cfg.get("organization", {}).get("registration_cert_no", "58ЭТЛ035"))
    if not qa["passed"]:
        raise RuntimeError(f"Пост-проверка протокола не пройдена: {'; '.join(qa['errors'])}")

    pid = str(uuid.uuid4())
    stem = f"protocol_{proto_no}_v{v_no}"
    att_docx = save_attachment_bytes(
        conn, docx_bytes, f"{stem}.docx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "protocol", pid, uploaded_by=user_id,
    )
    att_pdf_id = None
    if generate_pdf:
        try:
            pdf_bytes = convert_docx_bytes_to_pdf(docx_bytes, stem)
            att_pdf = save_attachment_bytes(conn, pdf_bytes, f"{stem}.pdf", "application/pdf", "protocol", pid, uploaded_by=user_id)
            att_pdf_id = att_pdf["id"]
        except Exception:
            att_pdf_id = None

    signatories = [
        {"role": "executor", "name": t["executor_name"] or "Инженер ЭТЛ"},
        {"role": "head_of_etl", "name": cfg.get("organization", {}).get("head_of_etl", "Лиханов Д. Ю.")},
    ]
    conn.execute(
        """
        INSERT INTO protocols (
            id, test_id, protocol_no, version_no, status, conclusion,
            attachment_id_docx, attachment_id_pdf, signatories_json, created_by
        ) VALUES (?, ?, ?, ?, 'GENERATED', ?, ?, ?, ?, ?)
        """,
        (pid, test_id, proto_no, v_no, conclusion, att_docx["id"], att_pdf_id, json.dumps(signatories, ensure_ascii=False), user_id),
    )
    write_audit_log(
        conn,
        action="PROTOCOL_GENERATED",
        entity_type="protocol",
        entity_id=pid,
        user_id=user_id,
        after={"protocol_no": proto_no, "version_no": v_no, "qa_passed": qa["passed"], "conclusion": conclusion},
        ip_address=ip_address,
    )
    return {
        "id": pid,
        "test_id": test_id,
        "protocol_no": proto_no,
        "version_no": v_no,
        "status": "GENERATED",
        "conclusion": conclusion,
        "qa_check": qa,
        "has_pdf": bool(att_pdf_id),
    }


def transition_protocol_status(
    conn,
    protocol_id: str,
    new_status: str,
    user: Dict[str, Any],
    reason: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    p = conn.execute("SELECT * FROM protocols WHERE id = ?", (protocol_id,)).fetchone()
    if not p:
        raise KeyError("Протокол не найден")
    cur_status = p["status"]
    target = new_status.upper()
    perms = set(user["permissions"])
    if "*" not in perms and not ({"protocol:sign", "protocol:review", "test:write"} & perms):
        raise PermissionError("Изменение статуса протокола недоступно для вашей роли")
    if target == "SIGNED" and "*" not in perms and "protocol:sign" not in perms:
        raise PermissionError("Подписание протокола (SIGNED) доступно только Начальнику ЭТЛ или Администратору")
    if target == "REVIEWED" and "*" not in perms and not ({"protocol:review", "protocol:sign"} & perms):
        raise PermissionError("Проверка протокола (REVIEWED) недоступна для вашей роли")
    if target == "REVISED" and cur_status == "SIGNED" and "*" not in perms and "protocol:sign" not in perms:
        raise PermissionError("Отзыв подписанного протокола доступен только Начальнику ЭТЛ или Администратору")

    if target not in VALID_TRANSITIONS.get(cur_status, set()):
        raise ValueError(f"Недопустимый переход статуса протокола: {cur_status} -> {target}")
    if target == "REVISED" and not (reason and reason.strip()):
        raise ValueError("Для перевода в статус REVISED укажите причину")

    conn.execute("UPDATE protocols SET status = ? WHERE id = ?", (target, protocol_id))
    write_audit_log(
        conn,
        action="PROTOCOL_STATUS_CHANGED",
        entity_type="protocol",
        entity_id=protocol_id,
        user_id=user["id"],
        before={"status": cur_status},
        after={"status": target},
        reason=reason,
        ip_address=ip_address,
    )
    return {"id": protocol_id, "protocol_no": p["protocol_no"], "old_status": cur_status, "status": target}


def get_protocol_download(conn, protocol_id: str, fmt: str = "docx") -> Tuple[bytes, str, str]:
    p = conn.execute("SELECT * FROM protocols WHERE id = ?", (protocol_id,)).fetchone()
    if not p:
        raise KeyError("Протокол не найден")
    att_id = p["attachment_id_docx"] if fmt.lower() == "docx" else p["attachment_id_pdf"]
    if not att_id:
        raise KeyError(f"Файл формата '{fmt}' не найден для протокола")
    att = conn.execute("SELECT * FROM attachments WHERE id = ?", (att_id,)).fetchone()
    full_path = Path(load_settings()["resolved"]["cas_root"]) / att["storage_rel_path"]
    return full_path.read_bytes(), att["original_filename"], att["mime_type"]
