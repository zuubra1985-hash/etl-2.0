import csv
import io
import json
from datetime import date, timedelta
from typing import Any, Dict, List, Tuple
import openpyxl
from openpyxl.styles import Font, PatternFill



XLSX_STATUS_RU = {
    "ACTIVE": "В работе", "REPAIR": "В ремонте", "ARCHIVED": "В архиве",
    "CALIBRATION": "На поверке", "CONSERVATION": "Консервация",
    "DRAFT": "Черновик", "GENERATED": "Сформирован", "REVIEWED": "Проверен",
    "SIGNED": "Подписан", "REVISED": "На доработке",
}
XLSX_FLAG_RU = {
    "NO_MODEL": "Нет модели (Б/М)", "NO_MANUFACTURER": "Нет изготовителя",
    "NO_POWER_KW": "Нет кВт", "NO_RPM": "Нет об/мин",
    "SUSPECT_RPM": "Проверьте об/мин", "NO_BEARINGS": "Нет подшипников",
}

def get_dashboard_summary(conn, warn_days: int = 60) -> Dict[str, Any]:
    eq_active = conn.execute("SELECT COUNT(*) FROM equipment WHERE is_archived = 0").fetchone()[0]
    eq_archived = conn.execute("SELECT COUNT(*) FROM equipment WHERE is_archived = 1").fetchone()[0]
    eq_incomplete = conn.execute(
        "SELECT COUNT(*) FROM equipment WHERE is_archived = 0 AND specs_json LIKE ?",
        ('%"data_quality_flags": ["%',),
    ).fetchone()[0]

    by_type = [
        dict(r)
        for r in conn.execute(
            """
            SELECT et.code, et.name, COUNT(e.id) AS count
            FROM equipment_types et
            LEFT JOIN equipment e ON e.type_id = et.id AND e.is_archived = 0
            GROUP BY et.id ORDER BY count DESC, et.code ASC
            """
        ).fetchall()
    ]

    passports_total = conn.execute("SELECT COUNT(*) FROM passports").fetchone()[0]
    passports_with_orig = conn.execute("SELECT COUNT(*) FROM passports WHERE original_attachment_id IS NOT NULL").fetchone()[0]
    passports_versioned = conn.execute("SELECT COUNT(*) FROM passports WHERE current_version_id IS NOT NULL").fetchone()[0]

    tests_by_status = {
        r["status"]: r["cnt"]
        for r in conn.execute("SELECT status, COUNT(*) AS cnt FROM tests GROUP BY status").fetchall()
    }
    protocols_by_status = {
        r["status"]: r["cnt"]
        for r in conn.execute("SELECT status, COUNT(*) AS cnt FROM protocols GROUP BY status").fetchall()
    }
    failed_measurements = conn.execute(
        "SELECT COUNT(*) FROM measurements WHERE is_superseded = 0 AND compliance_status = 'FAIL'"
    ).fetchone()[0]

    today_str = date.today().isoformat()
    warn_str = (date.today() + timedelta(days=warn_days)).isoformat()
    inst_rows = [dict(r) for r in conn.execute("SELECT id, model, serial_no, arshin_reg_no, calibration_valid_until, status FROM instruments ORDER BY model").fetchall()]
    si_counts = {"ACTIVE": 0, "CALIBRATION": 0, "CONSERVATION": 0}
    si_attention: List[Dict[str, Any]] = []
    for si in inst_rows:
        st = si["status"]
        si_counts[st] = si_counts.get(st, 0) + 1
        vu = si.get("calibration_valid_until")
        if st != "ACTIVE":
            _st_ru = {"CALIBRATION": "На поверке", "CONSERVATION": "Консервация"}.get(st, st)
            si_attention.append({**si, "alert": f"Статус: {_st_ru}"})
        elif not vu or str(vu)[:10] < today_str:
            si_attention.append({**si, "alert": "Поверка просрочена"})
        elif str(vu)[:10] <= warn_str:
            si_attention.append({**si, "alert": f"Истекает в ближайшие {warn_days} дн."})

    return {
        "equipment": {
            "active": eq_active,
            "archived": eq_archived,
            "incomplete_cards": eq_incomplete,
            "by_type": by_type,
        },
        "passports": {
            "total": passports_total,
            "with_immutable_original": passports_with_orig,
            "with_versions": passports_versioned,
        },
        "tests": {
            "by_status": tests_by_status,
            "total": sum(tests_by_status.values()),
            "failed_active_measurements": failed_measurements,
        },
        "protocols": {
            "by_status": protocols_by_status,
            "total": sum(protocols_by_status.values()),
        },
        "instruments": {
            "by_status": si_counts,
            "total": len(inst_rows),
            "attention_required": si_attention,
        },
    }


def global_search(conn, q: str, limit: int = 25) -> Dict[str, Any]:
    term = f"%{q.strip()}%"
    eq = [
        dict(r)
        for r in conn.execute(
            """
            SELECT e.id, e.name, e.model, e.inventory_no, l.facility_name AS location_name, q.short_code
            FROM equipment e
            LEFT JOIN locations l ON l.id = e.location_id
            LEFT JOIN qr_identities q ON q.equipment_id = e.id
            WHERE e.is_archived = 0 AND (
                LOWER(e.name) LIKE LOWER(?) OR LOWER(e.model) LIKE LOWER(?) OR LOWER(e.inventory_no) LIKE LOWER(?) OR LOWER(e.serial_no) LIKE LOWER(?) OR LOWER(e.dispatch_name) LIKE LOWER(?) OR q.short_code LIKE ?
            )
            LIMIT ?
            """,
            (term, term, term, term, term, term, limit),
        ).fetchall()
    ]
    si = [
        dict(r)
        for r in conn.execute(
            "SELECT id, model, serial_no, arshin_reg_no, status FROM instruments WHERE model LIKE ? OR serial_no LIKE ? OR arshin_reg_no LIKE ? LIMIT ?",
            (term, term, term, limit),
        ).fetchall()
    ]
    pr = [
        dict(r)
        for r in conn.execute(
            "SELECT id, test_id, protocol_no, status, conclusion FROM protocols WHERE protocol_no LIKE ? OR conclusion LIKE ? LIMIT ?",
            (term, term, limit),
        ).fetchall()
    ]
    mvi = [
        dict(r)
        for r in conn.execute(
            "SELECT id, code, title, scope FROM methodologies WHERE code LIKE ? OR title LIKE ? LIMIT ?",
            (term, term, limit),
        ).fetchall()
    ]
    return {"query": q, "equipment": eq, "instruments": si, "protocols": pr, "methodologies": mvi}


def export_summary_report(conn, fmt: str = "xlsx") -> Tuple[bytes, str, str]:
    summary = get_dashboard_summary(conn)
    eq_rows = conn.execute(
        """
        SELECT e.inventory_no, l.facility_name, et.name AS type_name, e.name, e.model,
               e.serial_no, e.manufacturer, e.commissioned_at, q.short_code, e.status, e.specs_json
        FROM equipment e
        JOIN equipment_types et ON et.id = e.type_id
        LEFT JOIN locations l ON l.id = e.location_id
        LEFT JOIN qr_identities q ON q.equipment_id = e.id
        ORDER BY l.facility_name, e.inventory_no
        """
    ).fetchall()

    if fmt.lower() == "csv":
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=";")
        w.writerow(["Инв. №", "Участок", "Тип", "Наименование", "Модель", "Зав. №", "Изготовитель", "Ввод", "QR", "Статус", "Флаги качества"])
        for r in eq_rows:
            flags = ", ".join(XLSX_FLAG_RU.get(f, f) for f in json.loads(r["specs_json"] or "{}").get("data_quality_flags", []))
            w.writerow([r["inventory_no"] or "", r["facility_name"] or "", r["type_name"], r["name"], r["model"] or "", r["serial_no"] or "", r["manufacturer"] or "", r["commissioned_at"] or "", r["short_code"] or "", XLSX_STATUS_RU.get(r["status"], r["status"]), flags])
        return buf.getvalue().encode("utf-8-sig"), "etl2_summary_report.csv", "text/csv; charset=utf-8"

    if fmt.lower() != "xlsx":
        raise ValueError("Поддерживаются только форматы 'xlsx' и 'csv'")

    wb = openpyxl.Workbook()
    hdr_font = Font(bold=True, color="FFFFFF")
    hdr_fill = PatternFill("solid", fgColor="1A4B8C")

    def style_header(ws):
        for cell in ws[1]:
            cell.font = hdr_font
            cell.fill = hdr_fill

    # Sheet 1: KPI Summary
    ws1 = wb.active
    ws1.title = "Сводка ЭТЛ"
    ws1.append(["Показатель", "Значение"])
    style_header(ws1)
    ws1.append(["Активное оборудование", summary["equipment"]["active"]])
    ws1.append(["Архивное оборудование", summary["equipment"]["archived"]])
    ws1.append(["Неполные карточки (требуют дозаполнения)", summary["equipment"]["incomplete_cards"]])
    ws1.append(["Электронные паспорта (всего)", summary["passports"]["total"]])
    ws1.append(["Паспорта с загруженным оригиналом", summary["passports"]["with_immutable_original"]])
    ws1.append(["Проведено испытаний (всего)", summary["tests"]["total"]])
    ws1.append(["Сформировано протоколов (всего)", summary["protocols"]["total"]])
    ws1.append(["Приборы СИ (всего)", summary["instruments"]["total"]])
    ws1.append(["СИ, требующие внимания (поверка/статус)", len(summary["instruments"]["attention_required"])])
    ws1.column_dimensions["A"].width = 45
    ws1.column_dimensions["B"].width = 18

    # Sheet 2: Equipment
    ws2 = wb.create_sheet("Реестр оборудования")
    ws2.append(["Инв. №", "Участок", "Тип", "Наименование", "Модель", "Зав. №", "Изготовитель", "Ввод", "QR", "Статус", "Флаги качества"])
    style_header(ws2)
    for r in eq_rows:
        flags = ", ".join(XLSX_FLAG_RU.get(f, f) for f in json.loads(r["specs_json"] or "{}").get("data_quality_flags", []))
        ws2.append([r["inventory_no"] or "", r["facility_name"] or "", r["type_name"], r["name"], r["model"] or "", r["serial_no"] or "", r["manufacturer"] or "", r["commissioned_at"] or "", r["short_code"] or "", XLSX_STATUS_RU.get(r["status"], r["status"]), flags])

    # Sheet 3: Instruments
    ws3 = wb.create_sheet("Реестр СИ и поверки")
    ws3.append(["Модель СИ", "Зав. №", "Рег. № ФИФ ОЕИ", "Поверка годна до", "Статус"])
    style_header(ws3)
    for si in conn.execute("SELECT model, serial_no, arshin_reg_no, calibration_valid_until, status FROM instruments ORDER BY model").fetchall():
        ws3.append([si["model"], si["serial_no"], si["arshin_reg_no"] or "", si["calibration_valid_until"] or "", XLSX_STATUS_RU.get(si["status"], si["status"])])

    # Sheet 4: Protocols
    ws4 = wb.create_sheet("Журнал протоколов")
    ws4.append(["№ протокола", "Ред.", "Дата испытания", "Оборудование", "Вид испытания", "Статус", "Заключение"])
    style_header(ws4)
    for pr in conn.execute(
        """
        SELECT p.protocol_no, p.version_no, t.test_date, e.name AS eq_name, tt.code AS tt_code, p.status, p.conclusion
        FROM protocols p
        JOIN tests t ON t.id = p.test_id
        JOIN equipment e ON e.id = t.equipment_id
        JOIN test_types tt ON tt.id = t.test_type_id
        ORDER BY p.created_at DESC
        """
    ).fetchall():
        ws4.append([pr["protocol_no"], pr["version_no"], pr["test_date"], pr["eq_name"], pr["tt_code"], XLSX_STATUS_RU.get(pr["status"], pr["status"]), pr["conclusion"] or ""])

    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            max_len = max((len(str(c.value or "")) for c in col), default=10)
            ws.column_dimensions[col[0].column_letter].width = min(max(max_len + 3, 12), 48)
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue(), "etl2_summary_report.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
