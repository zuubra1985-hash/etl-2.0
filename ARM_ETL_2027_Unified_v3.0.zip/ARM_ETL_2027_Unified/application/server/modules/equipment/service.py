import hashlib
import json
import uuid
from typing import Any, Dict, List, Optional, Tuple
from application.server.modules.security.audit import write_audit_log


def get_or_create_location(conn, facility_name: str, building: Optional[str] = None, room: Optional[str] = None) -> str:
    clean = " ".join(facility_name.strip().split())
    row = conn.execute(
        "SELECT id FROM locations WHERE lower(facility_name) = lower(?)",
        (clean,),
    ).fetchone()
    if row:
        return row["id"]
    dep = conn.execute("SELECT id FROM departments WHERE code = 'OGE-ETL'").fetchone()
    lid = str(uuid.uuid4())
    conn.execute(
        "INSERT INTO locations (id, department_id, facility_name, building, room) VALUES (?, ?, ?, ?, ?)",
        (lid, dep["id"] if dep else None, clean, building, room),
    )
    return lid


def find_duplicates(
    conn,
    inventory_no: Optional[str] = None,
    serial_no: Optional[str] = None,
    dispatch_name: Optional[str] = None,
    location_id: Optional[str] = None,
    exclude_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    conds = []
    params: List[Any] = []
    if inventory_no and inventory_no.strip():
        conds.append("lower(inventory_no) = lower(?)")
        params.append(inventory_no.strip())
    if serial_no and serial_no.strip():
        conds.append("lower(serial_no) = lower(?)")
        params.append(serial_no.strip())
    if dispatch_name and dispatch_name.strip() and location_id:
        conds.append("(lower(dispatch_name) = lower(?) AND location_id = ?)")
        params.extend([dispatch_name.strip(), location_id])
    if not conds:
        return []
    where = "(" + " OR ".join(conds) + ") AND is_archived = 0"
    if exclude_id:
        where += " AND id != ?"
        params.append(exclude_id)
    rows = conn.execute(
        f"""
        SELECT e.id, e.name, e.model, e.inventory_no, e.serial_no, e.dispatch_name,
               l.facility_name AS location_name
        FROM equipment e
        LEFT JOIN locations l ON l.id = e.location_id
        WHERE {where}
        LIMIT 10
        """,
        params,
    ).fetchall()
    return [dict(r) for r in rows]


def create_equipment_record(
    conn,
    type_code: str,
    name: str,
    user_id: Optional[str] = None,
    location_id: Optional[str] = None,
    facility_name: Optional[str] = None,
    inventory_no: Optional[str] = None,
    serial_no: Optional[str] = None,
    dispatch_name: Optional[str] = None,
    manufacturer: Optional[str] = None,
    model: Optional[str] = None,
    specs: Optional[Dict[str, Any]] = None,
    commissioned_at: Optional[str] = None,
    status: str = "ACTIVE",
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    et = conn.execute("SELECT id, code, name FROM equipment_types WHERE code = ?", (type_code.upper(),)).fetchone()
    if not et:
        raise ValueError(f"Неизвестный тип оборудования: {type_code}")

    if not location_id and facility_name:
        location_id = get_or_create_location(conn, facility_name)

    eq_id = str(uuid.uuid4())
    specs_json = json.dumps(specs or {}, ensure_ascii=False)
    conn.execute(
        """
        INSERT INTO equipment (
            id, type_id, location_id, inventory_no, serial_no, dispatch_name,
            name, manufacturer, model, specs_json, commissioned_at, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            eq_id, et["id"], location_id,
            inventory_no.strip() if inventory_no else None,
            serial_no.strip() if serial_no else None,
            dispatch_name.strip() if dispatch_name else None,
            name.strip(),
            manufacturer.strip() if manufacturer else None,
            model.strip() if model else None,
            specs_json,
            str(commissioned_at).strip() if commissioned_at is not None else None,
            status,
        ),
    )

    # Permanent immutable QR identity
    qr_token = str(uuid.uuid4())
    short_code = f"EQ-{qr_token[:8].upper()}"
    checksum = hashlib.sha256(f"{eq_id}:{qr_token}".encode("utf-8")).hexdigest()[:16]
    qr_id = str(uuid.uuid4())
    conn.execute(
        """
        INSERT INTO qr_identities (id, equipment_id, qr_token, short_code, checksum)
        VALUES (?, ?, ?, ?, ?)
        """,
        (qr_id, eq_id, qr_token, short_code, checksum),
    )

    # Initial electronic passport shell
    passport_id = str(uuid.uuid4())
    conn.execute(
        "INSERT INTO passports (id, equipment_id, template_id) VALUES (?, ?, ?)",
        (passport_id, eq_id, f"tpl_{et['code'].lower()}_v1"),
    )

    write_audit_log(
        conn,
        action="EQUIPMENT_CREATED",
        entity_type="equipment",
        entity_id=eq_id,
        user_id=user_id,
        after={"name": name, "type_code": et["code"], "inventory_no": inventory_no, "short_code": short_code},
        ip_address=ip_address,
    )
    return {
        "id": eq_id,
        "type_code": et["code"],
        "name": name.strip(),
        "qr_token": qr_token,
        "short_code": short_code,
        "passport_id": passport_id,
    }


def list_equipment(
    conn,
    search: Optional[str] = None,
    type_code: Optional[str] = None,
    location_id: Optional[str] = None,
    status: Optional[str] = None,
    include_archived: bool = False,
    incomplete_only: bool = False,
    page: int = 1,
    page_size: int = 50,
) -> Dict[str, Any]:
    where = ["1=1"]
    params: List[Any] = []
    if not include_archived:
        where.append("e.is_archived = 0")
    if type_code:
        where.append("et.code = ?")
        params.append(type_code.upper())
    if location_id:
        where.append("e.location_id = ?")
        params.append(location_id)
    if status:
        where.append("e.status = ?")
        params.append(status.upper())
    if search and search.strip():
        q = f"%{search.strip()}%"
        where.append(
            "(LOWER(e.name) LIKE LOWER(?) OR LOWER(e.model) LIKE LOWER(?) OR LOWER(e.dispatch_name) LIKE LOWER(?) OR LOWER(e.inventory_no) LIKE LOWER(?) OR LOWER(e.serial_no) LIKE LOWER(?) OR LOWER(e.manufacturer) LIKE LOWER(?) OR LOWER(l.facility_name) LIKE LOWER(?) OR LOWER(q.short_code) LIKE LOWER(?))"
        )
        params.extend([q] * 8)
    if incomplete_only:
        where.append("e.specs_json LIKE ?")
        params.append('%"data_quality_flags": ["%')

    where_sql = " AND ".join(where)
    base_from = """
        FROM equipment e
        JOIN equipment_types et ON et.id = e.type_id
        LEFT JOIN locations l ON l.id = e.location_id
        LEFT JOIN qr_identities q ON q.equipment_id = e.id
    """
    total = conn.execute(f"SELECT COUNT(*) {base_from} WHERE {where_sql}", params).fetchone()[0]
    offset = max(0, (page - 1) * page_size)
    rows = conn.execute(
        f"""
        SELECT e.id, e.name, e.model, e.dispatch_name, e.inventory_no, e.serial_no,
               e.manufacturer, e.commissioned_at, e.status, e.is_archived, e.specs_json,
               et.code AS type_code, et.name AS type_name,
               l.id AS location_id, l.facility_name AS location_name,
               q.short_code, q.qr_token
        {base_from}
        WHERE {where_sql}
        ORDER BY l.facility_name ASC, e.inventory_no ASC, e.name ASC
        LIMIT ? OFFSET ?
        """,
        (*params, page_size, offset),
    ).fetchall()

    items = []
    for r in rows:
        d = dict(r)
        specs = json.loads(d.pop("specs_json") or "{}")
        d["specs"] = specs
        d["data_quality_flags"] = specs.get("data_quality_flags", [])
        items.append(d)

    return {"total": total, "page": page, "page_size": page_size, "items": items}


def get_equipment_card(conn, equipment_id: str) -> Optional[Dict[str, Any]]:
    row = conn.execute(
        """
        SELECT e.*, et.code AS type_code, et.name AS type_name,
               l.facility_name AS location_name, l.building, l.room,
               d.name AS department_name
        FROM equipment e
        JOIN equipment_types et ON et.id = e.type_id
        LEFT JOIN locations l ON l.id = e.location_id
        LEFT JOIN departments d ON d.id = l.department_id
        WHERE e.id = ?
        """,
        (equipment_id,),
    ).fetchone()
    if not row:
        return None
    eq = dict(row)
    specs = json.loads(eq.pop("specs_json") or "{}")

    qr = conn.execute("SELECT * FROM qr_identities WHERE equipment_id = ?", (equipment_id,)).fetchone()
    passport = conn.execute("SELECT * FROM passports WHERE equipment_id = ?", (equipment_id,)).fetchone()
    p_versions = []
    if passport:
        p_versions = [
            dict(v)
            for v in conn.execute(
                "SELECT id, version_no, source_test_id, change_reason, created_at FROM passport_versions WHERE passport_id = ? ORDER BY version_no DESC",
                (passport["id"],),
            ).fetchall()
        ]
    tests = [
        dict(t)
        for t in conn.execute(
            """
            SELECT t.id, t.test_date, t.status, t.purpose, tt.code AS test_type_code, tt.name AS test_type_name
            FROM tests t JOIN test_types tt ON tt.id = t.test_type_id
            WHERE t.equipment_id = ?
            ORDER BY t.test_date DESC
            """,
            (equipment_id,),
        ).fetchall()
    ]
    protocols = [
        dict(p)
        for p in conn.execute(
            """
            SELECT p.id, p.protocol_no, p.version_no, p.status, p.conclusion, p.created_at
            FROM protocols p JOIN tests t ON t.id = p.test_id
            WHERE t.equipment_id = ?
            ORDER BY p.created_at DESC
            """,
            (equipment_id,),
        ).fetchall()
    ]
    attachments = [
        dict(a)
        for a in conn.execute(
            "SELECT id, original_filename, mime_type, size_bytes, is_original_immutable, uploaded_at FROM attachments WHERE entity_type = 'equipment' AND entity_id = ?",
            (equipment_id,),
        ).fetchall()
    ]
    audit = [
        dict(a)
        for a in conn.execute(
            "SELECT id, action, user_id, reason, created_at FROM audit_log WHERE entity_type = 'equipment' AND entity_id = ? ORDER BY id DESC LIMIT 20",
            (equipment_id,),
        ).fetchall()
    ]

    return {
        "general": eq,
        "specs": specs,
        "data_quality_flags": specs.get("data_quality_flags", []),
        "passport": {"meta": dict(passport) if passport else None, "versions": p_versions},
        "tests": tests,
        "protocols": protocols,
        "attachments": attachments,
        "qr_identity": dict(qr) if qr else None,
        "audit_history": audit,
    }



def _recalc_quality_flags(model, manufacturer, specs: Dict[str, Any]) -> List[str]:
    flags: List[str] = []
    if not model or str(model).strip().upper() in ("Б/М", "Б\\М", "-"):
        flags.append("NO_MODEL")
    if not manufacturer or not str(manufacturer).strip():
        flags.append("NO_MANUFACTURER")
    if specs.get("power_kw") is None and "source_excel_row" in specs:
        flags.append("NO_POWER_KW")
    if specs.get("rpm") is None and "source_excel_row" in specs:
        flags.append("NO_RPM")
    elif specs.get("rpm") is not None:
        try:
            rv = float(specs["rpm"])
            if rv < 300 or rv > 6000:
                flags.append("SUSPECT_RPM")
        except Exception:
            pass
    if not specs.get("bearings") and not specs.get("bearing_drive") and "source_excel_row" in specs:
        flags.append("NO_BEARINGS")
    return flags

def update_equipment_record(
    conn,
    equipment_id: str,
    updates: Dict[str, Any],
    user_id: Optional[str] = None,
    reason: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    existing = conn.execute("SELECT * FROM equipment WHERE id = ?", (equipment_id,)).fetchone()
    if not existing:
        raise KeyError("Оборудование не найдено")
    before = dict(existing)

    allowed = {"name", "model", "dispatch_name", "inventory_no", "serial_no", "manufacturer", "commissioned_at", "status", "location_id"}
    sql_updates: Dict[str, Any] = {}
    for k, v in updates.items():
        if k in allowed:
            sql_updates[k] = (v.strip() or None) if isinstance(v, str) else v
    cur_specs = json.loads(before.get("specs_json") or "{}")
    if "specs" in updates and updates["specs"] is not None:
        cur_specs = updates["specs"]
    if "data_quality_flags" in cur_specs:
        new_model = sql_updates.get("model", before.get("model"))
        new_mfg = sql_updates.get("manufacturer", before.get("manufacturer"))
        cur_specs["data_quality_flags"] = _recalc_quality_flags(new_model, new_mfg, cur_specs)
        sql_updates["specs_json"] = json.dumps(cur_specs, ensure_ascii=False)
    if "specs" in updates and updates["specs"] is not None:
        sql_updates["specs_json"] = json.dumps(updates["specs"], ensure_ascii=False)
    if "facility_name" in updates and updates["facility_name"]:
        sql_updates["location_id"] = get_or_create_location(conn, updates["facility_name"])

    if sql_updates:
        set_clause = ", ".join(f"{k} = ?" for k in sql_updates) + ", updated_at = datetime('now')"
        conn.execute(f"UPDATE equipment SET {set_clause} WHERE id = ?", (*sql_updates.values(), equipment_id))
        write_audit_log(
            conn,
            action="EQUIPMENT_UPDATED",
            entity_type="equipment",
            entity_id=equipment_id,
            user_id=user_id,
            before={k: before.get(k) for k in sql_updates},
            after=sql_updates,
            reason=reason,
            ip_address=ip_address,
        )
    return {"id": equipment_id, "updated_fields": list(sql_updates.keys())}


def archive_equipment_record(
    conn,
    equipment_id: str,
    reason: str,
    user_id: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    existing = conn.execute("SELECT id, status, is_archived FROM equipment WHERE id = ?", (equipment_id,)).fetchone()
    if not existing:
        raise KeyError("Оборудование не найдено")
    conn.execute(
        "UPDATE equipment SET status = 'ARCHIVED', is_archived = 1, updated_at = datetime('now') WHERE id = ?",
        (equipment_id,),
    )
    write_audit_log(
        conn,
        action="EQUIPMENT_ARCHIVED",
        entity_type="equipment",
        entity_id=equipment_id,
        user_id=user_id,
        before={"status": existing["status"], "is_archived": existing["is_archived"]},
        after={"status": "ARCHIVED", "is_archived": 1},
        reason=reason,
        ip_address=ip_address,
    )
    return {"id": equipment_id, "status": "ARCHIVED", "is_archived": True}
