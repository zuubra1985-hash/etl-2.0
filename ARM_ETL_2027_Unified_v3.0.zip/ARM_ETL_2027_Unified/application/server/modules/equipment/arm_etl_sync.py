from typing import Any, Dict, List, Optional
import json
from pathlib import Path
from typing import Any, Dict, Optional
from application.server.core.config import PROJECT_ROOT
from application.server.core.db import db_session
from application.server.modules.equipment.service import create_equipment_record
from application.server.modules.security.audit import write_audit_log


def _guess_type_code(name: str, category: str = "") -> str:
    txt = f"{name} {category}".lower()
    if any(k in txt for k in ("двигател", "эд ", "аир", "аиму", "адм", "мотор")):
        return "MOTOR"
    if any(k in txt for k in ("тмг", "тм-", "тсз", "трансформатор силов", "ктп", "тр-р")):
        return "TRANSFORMER"
    if any(k in txt for k in ("кру", "зру", "ячейк", "ксо", "рвз", "разъединител")):
        return "KRU"
    if any(k in txt for k in ("кабел", "кл", "вл ", "шин", "ввг", "авббшв", "апвп")):
        return "CABLE_LINE"
    if any(k in txt for k in ("заземл", "молниезащ", "контур", "зу ")):
        return "GROUNDING"
    if any(k in txt for k in ("тт ", "тн ", "тол-", "тпл-", "нами", "зном", "измерительн")):
        return "CT_VT"
    if any(k in txt for k in ("вакуумн", "вв/tel", "вмп", "выключатель 6", "выключатель 10")):
        return "BREAKER_HV"
    if any(k in txt for k in ("автомат", "ав ", "ва47", "ва88", "узо", "дифавтомат", "пускател")):
        return "BREAKER_LV"
    if any(k in txt for k in ("сиз", "перчатк", "боты", "штанга", "указатель напряж")):
        return "PPE"
    return "SWITCHBOARD"


def sync_from_arm_etl_seed(
    seed_json_path: Optional[str] = None,
    db_path: Optional[str] = None,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    path = Path(seed_json_path) if seed_json_path else (PROJECT_ROOT / "objects_seed.json")
    if not path.exists():
        raise FileNotFoundError(f"Файл objects_seed.json не найден: {path}")

    raw = json.loads(path.read_text(encoding="utf-8"))
    objects_list = raw.get("objects", [])
    items = raw.get("items", [])

    imported = 0
    skipped = 0
    with db_session(db_path) as conn:
        for idx, it in enumerate(items, 1):
            arm_id = str(it.get("id") or f"eq-{idx}")
            inv_no = f"ARM-{arm_id}"
            if conn.execute("SELECT id FROM equipment WHERE inventory_no = ?", (inv_no,)).fetchone():
                skipped += 1
                continue
            facility = str(it.get("object") or "Объект АРМ ЭТЛ").strip()
            name = " ".join(str(it.get("name") or f"Оборудование #{idx}").split())
            cat = str(it.get("cat") or "").strip()
            tcode = _guess_type_code(name, cat)
            specs = {
                "arm_etl_id": arm_id,
                "arm_etl_num": it.get("num"),
                "arm_etl_cat": cat,
                "arm_etl_power_or_voltage": it.get("power"),
                "arm_etl_period": it.get("period"),
                "arm_etl_last_test_date": it.get("lastDate"),
            }
            create_equipment_record(
                conn,
                type_code=tcode,
                name=name,
                user_id=user_id,
                facility_name=facility,
                inventory_no=inv_no,
                dispatch_name=f"{facility} — {name}"[:120],
                model=str(it.get("power") or cat or "") or None,
                specs=specs,
            )
            imported += 1

        write_audit_log(
            conn,
            action="SYNC_FROM_ARM_ETL",
            entity_type="equipment",
            user_id=user_id,
            after={"imported": imported, "skipped": skipped, "total_source": len(items)},
            reason="Синхронизация базы объектов и оборудования из АРМ ЭТЛ (objects_seed.json)",
        )
    return {
        "source_objects": len(objects_list),
        "source_items": len(items),
        "imported": imported,
        "skipped_existing": skipped,
    }


_ARM_PROTO_TYPE_RU = {
    "insulation": "Измерение сопротивления изоляции (АРМ ЭТЛ)",
    "loop": "Измерение петли фаза-нуль (АРМ ЭТЛ)",
    "ground": "Измерение сопротивления заземления (АРМ ЭТЛ)",
    "bond": "Проверка металлосвязи (АРМ ЭТЛ)",
    "rcd": "Проверка УЗО / дифавтоматов (АРМ ЭТЛ)",
    "breaker": "Проверка автоматических выключателей (АРМ ЭТЛ)",
    "hv": "Испытание повышенным напряжением (АРМ ЭТЛ)",
    "motor": "Испытание электродвигателя (АРМ ЭТЛ)",
    "cable": "Испытание кабельной линии (АРМ ЭТЛ)",
    "transformer": "Испытание силового трансформатора (АРМ ЭТЛ)",
    "rza": "Проверка устройств РЗиА (АРМ ЭТЛ)",
    "visual": "Визуальный осмотр электроустановки (АРМ ЭТЛ)",
}


def _extract_row_summary(row: Any) -> tuple[str, str, str]:
    """Return (equip_hint, summary_text, conclusion_text) from an ARM ETL protocol row."""
    if isinstance(row, dict):
        hint = str(
            row.get("name") or row.get("equip") or row.get("point")
            or row.get("line") or row.get("circuit") or row.get("title") or ""
        ).strip()
        concl = str(row.get("conclusion") or row.get("result") or row.get("status") or "Соответствует").strip()
        skip = {"id", "idx", "num", "name", "equip", "point", "line", "circuit", "title", "conclusion", "result", "status", "equipmentId", "armId"}
        parts = [f"{v}" for k, v in row.items() if k not in skip and v not in (None, "", "—", "-")]
        summary = "; ".join(parts[:5]) or hint or "Проведено испытание (АРМ ЭТЛ)"
        return hint, summary[:180], concl
    if isinstance(row, (list, tuple)) and row:
        vals = [str(x).strip() for x in row if x not in (None, "")]
        hint = vals[1] if len(vals) > 1 and vals[0].isdigit() else (vals[0] if vals else "")
        summary = "; ".join(vals[:6]) or "Проведено испытание (АРМ ЭТЛ)"
        concl = "Не соответствует" if any("не соотв" in v.lower() or "брак" in v.lower() for v in vals) else "Соответствует"
        return hint, summary[:180], concl
    return "", "Проведено испытание (АРМ ЭТЛ)", "Соответствует"


def _find_matching_etl2_equipment_id(conn, arm_item_id: Optional[str], obj_name: str, row_hint: str) -> Optional[str]:
    if arm_item_id:
        cands = [arm_item_id, f"ARM-{arm_item_id}"]
        if arm_item_id.startswith("ed-reg-"):
            cands.append(arm_item_id.replace("ed-reg-", "", 1).upper())
        for inv in cands:
            r = conn.execute("SELECT id FROM equipment WHERE upper(inventory_no) = upper(?) AND is_archived = 0 LIMIT 1", (inv,)).fetchone()
            if r:
                return r["id"]
    if row_hint:
        # Try exact or substring match inside the same object/location first
        if obj_name:
            r = conn.execute(
                """
                SELECT e.id FROM equipment e
                LEFT JOIN locations l ON l.id = e.location_id
                WHERE e.is_archived = 0
                  AND lower(COALESCE(l.facility_name, '')) LIKE '%' || lower(?) || '%'
                  AND (lower(e.name) LIKE '%' || lower(?) || '%' OR lower(COALESCE(e.dispatch_name,'')) LIKE '%' || lower(?) || '%')
                LIMIT 1
                """,
                (obj_name.strip(), row_hint[:60], row_hint[:60]),
            ).fetchone()
            if r:
                return r["id"]
        r = conn.execute(
            "SELECT id FROM equipment WHERE is_archived = 0 AND (lower(name) LIKE '%' || lower(?) || '%' OR lower(COALESCE(inventory_no,'')) = lower(?)) LIMIT 1",
            (row_hint[:60], row_hint[:60]),
        ).fetchone()
        if r:
            return r["id"]
    return None


def sync_arm_etl_protocols_to_etl2_passports(protocols: List[Dict[str, Any]]) -> int:
    """Auto-sync protocols saved in ARM ETL 2027 (POST /api/state) into ETL 2.0 equipment passports (Sections 4-10) without duplicates."""
    if not protocols:
        return 0
    from application.server.core.db import db_session
    from application.server.modules.passports.service import create_passport_version, get_equipment_passport

    synced = 0
    try:
        with db_session() as conn:
            for p in protocols:
                if not isinstance(p, dict):
                    continue
                p_id = str(p.get("id") or "")
                p_num = str(p.get("number") or p.get("num") or "б/н")
                p_date = str(p.get("date") or "")[:10]
                p_obj = str(p.get("object") or "").strip()
                p_type_raw = str(p.get("type") or "")
                p_type_ru = _ARM_PROTO_TYPE_RU.get(p_type_raw, p_type_raw or "Испытание (АРМ ЭТЛ)")
                rows = p.get("rows") or []
                for idx, row in enumerate(rows):
                    arm_eq_id = row.get("equipmentId") or row.get("armId") if isinstance(row, dict) else None
                    hint, summary, concl = _extract_row_summary(row)
                    eq_id = _find_matching_etl2_equipment_id(conn, arm_eq_id, p_obj, hint)
                    if not eq_id:
                        continue
                    sync_key = f"arm:{p_id}:{idx}"
                    pass_info = get_equipment_passport(conn, eq_id)
                    cur_data = dict(pass_info["current_version"]["data"]) if pass_info.get("current_version") else {}
                    recs = list(cur_data.get("test_records") or [])
                    if any(r.get("sync_key") == sync_key or (r.get("protocol_no") == f"АРМ №{p_num}" and r.get("date") == p_date and r.get("summary") == summary) for r in recs):
                        continue
                    recs.append({
                        "sync_key": sync_key,
                        "date": p_date,
                        "test_type": p_type_ru,
                        "protocol_no": f"АРМ №{p_num}",
                        "summary": summary,
                        "conclusion": concl,
                    })
                    cur_data["test_records"] = recs
                    create_passport_version(
                        conn,
                        equipment_id=eq_id,
                        data=cur_data,
                        change_reason=f"Автосинхронизация протокола АРМ ЭТЛ № {p_num}",
                    )
                    synced += 1
    except Exception:
        return synced
    return synced


def sync_arm_etl_tested_date_to_etl2_passport(arm_item_id: str, tested_date: str) -> bool:
    """Auto-sync 'Mark as tested' from ARM ETL 2027 into ETL 2.0 passport Sections 4-10."""
    from application.server.core.db import db_session
    from application.server.modules.passports.service import create_passport_version, get_equipment_passport

    try:
        with db_session() as conn:
            eq_id = _find_matching_etl2_equipment_id(conn, arm_item_id, "", "")
            if not eq_id:
                return False
            sync_key = f"arm-tested:{arm_item_id}:{tested_date}"
            pass_info = get_equipment_passport(conn, eq_id)
            cur_data = dict(pass_info["current_version"]["data"]) if pass_info.get("current_version") else {}
            recs = list(cur_data.get("test_records") or [])
            if any(r.get("sync_key") == sync_key for r in recs):
                return False
            recs.append({
                "sync_key": sync_key,
                "date": tested_date,
                "test_type": "Плановое испытание ППР (АРМ ЭТЛ)",
                "protocol_no": "График ППР",
                "summary": "Отметка о проведении испытания в АРМ ЭТЛ 2027",
                "conclusion": "Соответствует",
            })
            cur_data["test_records"] = recs
            create_passport_version(
                conn,
                equipment_id=eq_id,
                data=cur_data,
                change_reason=f"Отметка ППР АРМ ЭТЛ от {tested_date}",
            )
            return True
    except Exception:
        return False
