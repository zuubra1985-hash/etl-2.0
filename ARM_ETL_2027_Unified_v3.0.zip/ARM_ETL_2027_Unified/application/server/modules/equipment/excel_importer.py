import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import openpyxl

from application.server.core.db import db_session
from application.server.modules.equipment.service import create_equipment_record
from application.server.modules.security.audit import write_audit_log

# Longest/most specific prefixes first so "EMS-3700" is NEVER split into "EMS"!
SITE_RULES = [
    ("ems-3700", "Котельная EMS-3700"),
    ("ems 3700", "Котельная EMS-3700"),
    ("ems", "Котельная EMS-3700"),
    ("amelin", "Котельная AMELIN"),
    ("абк", "АБК"),
    ("пож.депо", "Пож.депо"),
    ("пож. депо", "Пож.депо"),
    ("пож.насосная", "Пож.насосная"),
    ("пож. насосная", "Пож.насосная"),
    ("тех.насосная", "Тех.насосная"),
    ("тех. насосная", "Тех.насосная"),
    ("рвс парк", "РВС парк"),
    ("тсб", "ТСБ"),
    ("шпзо", "ШПЗО"),
    ("ж/д эстакада", "Ж/Д эстакада"),
    ("жд эстакада", "Ж/Д эстакада"),
    ("снин", "СНиН"),
    ("компрессорная", "Компрессорная"),
    ("урп", "УРП"),
    ("гараж", "Гараж"),
    ("кпп", "КПП"),
    ("бпр", "БПР"),
    ("асн", "АСН"),
    ("котельная", "Котельная"),
]


def normalize_site_and_dispatch(raw_place: Optional[str]) -> Tuple[str, str]:
    if not raw_place or not str(raw_place).strip():
        return ("Не указано", "")
    text = " ".join(str(raw_place).strip().split())
    clean_disp = re.sub(r"\s*-{2,}\s*", " — ", text)
    low = text.lower()
    for prefix, canonical in SITE_RULES:
        if low.startswith(prefix):
            return (canonical, clean_disp)
    parts = re.split(r"\s*[-–—]+\s*", text, maxsplit=1)
    raw_site = parts[0].strip().rstrip(".")
    return (raw_site if raw_site else "Не указано", clean_disp)


def parse_float(val: Any) -> Optional[float]:
    if val is None:
        return None
    s = str(val).strip().replace(",", ".")
    m = re.search(r"\d+(?:\.\d+)?", s)
    return float(m.group(0)) if m else None


def _sync_motors_to_arm_etl_schedule(motors_for_ppr: List[Dict[str, Any]]) -> int:
    """Distribute imported motors directly into relational tables equipment & equipment_objects of etl_base.db without duplicates."""
    try:
        import sqlite3
        import database as arm_db
    except Exception:
        return 0
    if not hasattr(arm_db, "DB_PATH"):
        return 0
    try:
        arm_db.init_db(arm_db.DB_PATH)
        with sqlite3.connect(arm_db.DB_PATH) as aconn:
            existing_ids = {r[0] for r in aconn.execute("SELECT id FROM equipment").fetchall()}
            existing_objs = {r[0] for r in aconn.execute("SELECT name FROM equipment_objects").fetchall()}
            max_obj_sort = aconn.execute("SELECT COALESCE(MAX(sort_order), -1) FROM equipment_objects").fetchone()[0]
            max_eq_sort = aconn.execute("SELECT COALESCE(MAX(sort_order), -1) FROM equipment").fetchone()[0]
            added = 0
            for m in motors_for_ppr:
                arm_id = f"ed-reg-{m['inv_no']}"
                if arm_id in existing_ids:
                    continue
                obj_name = str(m["facility_name"]).strip() or "Общий участок"
                if obj_name not in existing_objs:
                    max_obj_sort += 1
                    aconn.execute(
                        "INSERT OR IGNORE INTO equipment_objects (name, sort_order) VALUES (?, ?)",
                        (obj_name, max_obj_sort),
                    )
                    existing_objs.add(obj_name)
                pwr = f"{m['power_kw']} кВт" if m.get("power_kw") is not None else "—"
                rpm = f", {int(m['rpm'])} об/мин" if m.get("rpm") is not None else ""
                last_d = f"{m['year']}-06-01" if m.get("year") and str(m["year"]).isdigit() else ""
                max_eq_sort += 1
                aconn.execute(
                    """
                    INSERT OR IGNORE INTO equipment (id, sort_order, num, object_name, name, power, period, last_date, months_json, cat)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        arm_id,
                        max_eq_sort,
                        str(m["inv_no"]),
                        obj_name,
                        str(m["display_name"]),
                        f"{pwr}{rpm}",
                        "1 раз в 3 года",
                        last_d,
                        json.dumps([5, 9], ensure_ascii=False),
                        "Электродвигатели",
                    ),
                )
                existing_ids.add(arm_id)
                added += 1
            if added > 0:
                aconn.commit()
        return added
    except Exception:
        return 0


def import_motors_excel(
    xlsx_path: str,
    db_path: Optional[str] = None,
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    path = Path(xlsx_path)
    if not path.exists():
        raise FileNotFoundError(f"Файл реестра ЭД не найден: {xlsx_path}")

    wb = openpyxl.load_workbook(str(path), data_only=True)
    ws = wb[wb.sheetnames[0]]

    imported = 0
    skipped = 0
    locations_seen = set()
    anomaly_counts: Dict[str, int] = {}
    motors_for_ppr: List[Dict[str, Any]] = []

    with db_session(db_path) as conn:
        for r in range(4, ws.max_row + 1):
            row_vals = [ws.cell(r, c).value for c in range(1, 9)]
            if all(v is None or str(v).strip() == "" for v in row_vals):
                continue

            seq_no, raw_type, raw_year, raw_place, raw_mfg, raw_kw, raw_rpm, raw_bearings = row_vals
            if seq_no is None and raw_type is None and raw_place is None:
                continue

            inv_no = f"ED-REG-{int(seq_no):03d}" if isinstance(seq_no, (int, float)) else f"ED-ROW-{r:03d}"
            facility_name, dispatch_name = normalize_site_and_dispatch(raw_place)
            locations_seen.add(facility_name)

            model_str = str(raw_type).strip() if raw_type is not None else ""
            mfg_str = str(raw_mfg).strip() if raw_mfg is not None and str(raw_mfg).strip() else None
            kw_val = parse_float(raw_kw)
            rpm_val = parse_float(raw_rpm)
            bearings_str = str(raw_bearings).strip() if raw_bearings is not None and str(raw_bearings).strip() else None
            year_str = str(int(raw_year)) if isinstance(raw_year, (int, float)) else (str(raw_year).strip() if raw_year else None)

            display_name = f"ЭД {model_str or 'Б/М'} ({dispatch_name or facility_name})"
            motors_for_ppr.append({
                "inv_no": inv_no, "facility_name": facility_name, "display_name": display_name,
                "power_kw": kw_val, "rpm": rpm_val, "year": year_str,
            })

            if conn.execute("SELECT id FROM equipment WHERE inventory_no = ?", (inv_no,)).fetchone():
                skipped += 1
                continue

            flags: List[str] = []
            if not model_str or model_str.upper() in ("Б/М", "Б\М", "-"):
                flags.append("NO_MODEL")
            if not mfg_str:
                flags.append("NO_MANUFACTURER")
            if kw_val is None:
                flags.append("NO_POWER_KW")
            if rpm_val is None:
                flags.append("NO_RPM")
            elif rpm_val < 300 or rpm_val > 6000:
                flags.append("SUSPECT_RPM")
            if not bearings_str:
                flags.append("NO_BEARINGS")

            for fl in flags:
                anomaly_counts[fl] = anomaly_counts.get(fl, 0) + 1

            b_drive, b_nondrive = bearings_str, bearings_str
            if bearings_str and "/" in bearings_str:
                parts_b = [x.strip() for x in bearings_str.split("/", 1)]
                b_drive, b_nondrive = parts_b[0], parts_b[1]

            specs = {
                "type": model_str or "Б/М",
                "power_kw": kw_val,
                "rpm": rpm_val,
                "rpm_raw": str(raw_rpm) if raw_rpm is not None else None,
                "bearings": bearings_str,
                "bearing_drive": b_drive,
                "bearing_non_drive": b_nondrive,
                "source_excel_row": r,
                "source_seq_no": seq_no,
                "data_quality_flags": flags,
            }

            create_equipment_record(
                conn,
                type_code="MOTOR",
                name=display_name,
                user_id=user_id,
                facility_name=facility_name,
                inventory_no=inv_no,
                dispatch_name=dispatch_name,
                manufacturer=mfg_str,
                model=model_str or "Б/М",
                specs=specs,
                commissioned_at=year_str,
            )
            imported += 1

        write_audit_log(
            conn,
            action="EQUIPMENT_EXCEL_IMPORT",
            entity_type="equipment",
            user_id=user_id,
            after={"file": path.name, "imported": imported, "skipped": skipped, "anomalies": anomaly_counts},
            reason="Массовый импорт реестра электродвигателей из Excel",
        )

    ppr_synced = _sync_motors_to_arm_etl_schedule(motors_for_ppr)
    return {
        "file": path.name,
        "imported": imported,
        "skipped_existing": skipped,
        "ppr_schedule_synced": ppr_synced,
        "normalized_locations_count": len(locations_seen),
        "anomaly_counts": anomaly_counts,
    }
