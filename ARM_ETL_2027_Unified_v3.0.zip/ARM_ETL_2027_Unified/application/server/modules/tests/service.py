import json
import uuid
from typing import Any, Dict, List, Optional
from application.server.modules.security.audit import write_audit_log
from application.server.modules.tests.validators import (
    build_instrument_snapshot,
    evaluate_measurement_compliance,
    validate_instrument_for_test,
)


def get_applicable_tests(conn, equipment_id: str) -> List[Dict[str, Any]]:
    eq = conn.execute(
        "SELECT e.id, et.code AS type_code FROM equipment e JOIN equipment_types et ON et.id = e.type_id WHERE e.id = ?",
        (equipment_id,),
    ).fetchone()
    if not eq:
        raise KeyError("Оборудование не найдено")
    tcode = eq["type_code"]
    rows = conn.execute(
        """
        SELECT tt.id, tt.code, tt.name, tt.form_schema_json,
               m.code AS methodology_code, m.title AS methodology_title
        FROM test_types tt
        LEFT JOIN methodologies m ON m.id = tt.methodology_id
        ORDER BY tt.code
        """
    ).fetchall()
    result = []
    for r in rows:
        schema = json.loads(r["form_schema_json"] or "{}")
        app_types = schema.get("applicable_equipment_types", ["*"])
        if "*" in app_types or tcode in app_types:
            result.append({
                "id": r["id"],
                "code": r["code"],
                "name": r["name"],
                "methodology_code": r["methodology_code"],
                "methodology_title": r["methodology_title"],
            })
    return result


def get_test_type_form_schema(conn, test_type_id: str) -> Dict[str, Any]:
    tt = conn.execute(
        """
        SELECT tt.*, m.code AS methodology_code, m.title AS methodology_title
        FROM test_types tt LEFT JOIN methodologies m ON m.id = tt.methodology_id
        WHERE tt.id = ?
        """,
        (test_type_id,),
    ).fetchone()
    if not tt:
        raise KeyError("Вид испытания не найден")
    params = [
        dict(p)
        for p in conn.execute(
            "SELECT id, code, name, unit, data_type, is_required, validation_rules_json FROM measurement_parameters WHERE test_type_id = ? ORDER BY id",
            (test_type_id,),
        ).fetchall()
    ]
    mv = conn.execute(
        "SELECT id, edition, status, norm_criteria_json FROM methodology_versions WHERE methodology_id = ? ORDER BY CASE WHEN status='ACTIVE' THEN 0 ELSE 1 END, rowid DESC LIMIT 1",
        (tt["methodology_id"],),
    ).fetchone()
    return {
        "id": tt["id"],
        "code": tt["code"],
        "name": tt["name"],
        "methodology_code": tt["methodology_code"],
        "methodology_title": tt["methodology_title"],
        "methodology_version": dict(mv) if mv else None,
        "form_schema": json.loads(tt["form_schema_json"] or "{}"),
        "parameters": params,
    }


def approve_methodology_criteria(
    conn,
    methodology_id: str,
    norm_criteria: Dict[str, Any],
    edition: str,
    user_id: str,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    m = conn.execute("SELECT id, code FROM methodologies WHERE id = ?", (methodology_id,)).fetchone()
    if not m:
        raise KeyError("Методика не найдена")
    # Supersede previous active versions
    conn.execute(
        "UPDATE methodology_versions SET status = 'SUPERSEDED' WHERE methodology_id = ? AND status = 'ACTIVE'",
        (methodology_id,),
    )
    mvid = str(uuid.uuid4())
    conn.execute(
        """
        INSERT INTO methodology_versions (
            id, methodology_id, edition, effective_date, norm_criteria_json,
            approved_by_user_id, approved_at, status
        ) VALUES (?, ?, ?, date('now'), ?, ?, datetime('now'), 'ACTIVE')
        """,
        (mvid, methodology_id, edition, json.dumps(norm_criteria, ensure_ascii=False), user_id),
    )
    write_audit_log(
        conn,
        action="METHODOLOGY_CRITERIA_APPROVED",
        entity_type="methodology",
        entity_id=methodology_id,
        user_id=user_id,
        after={"methodology_version_id": mvid, "edition": edition, "norm_criteria": norm_criteria},
        ip_address=ip_address,
    )
    return {"id": mvid, "methodology_code": m["code"], "edition": edition, "status": "ACTIVE"}


def update_instrument_calibration(
    conn,
    instrument_id: str,
    updates: Dict[str, Any],
    user_id: str,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    inst = conn.execute("SELECT * FROM instruments WHERE id = ?", (instrument_id,)).fetchone()
    if not inst:
        raise KeyError("Прибор не найден")
    allowed = {"calibration_date", "calibration_valid_until", "status", "arshin_reg_no", "notes"}
    sql_u = {k: v for k, v in updates.items() if k in allowed and v is not None}
    if sql_u:
        set_sql = ", ".join(f"{k} = ?" for k in sql_u)
        conn.execute(f"UPDATE instruments SET {set_sql} WHERE id = ?", (*sql_u.values(), instrument_id))
        write_audit_log(
            conn,
            action="INSTRUMENT_UPDATED",
            entity_type="instrument",
            entity_id=instrument_id,
            user_id=user_id,
            before={k: inst[k] for k in sql_u},
            after=sql_u,
            ip_address=ip_address,
        )
    return {"id": instrument_id, "updated": list(sql_u.keys())}


def create_test_draft(
    conn,
    equipment_id: str,
    test_type_id: str,
    test_date: str,
    instrument_ids: List[str],
    user_id: str,
    temp_c: Optional[float] = None,
    humidity_pct: Optional[float] = None,
    pressure_mmhg: Optional[float] = None,
    purpose: str = "эксплуатационные",
    notes: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    if not conn.execute("SELECT id FROM equipment WHERE id = ?", (equipment_id,)).fetchone():
        raise KeyError("Оборудование не найдено")
    tt = conn.execute("SELECT id, methodology_id FROM test_types WHERE id = ?", (test_type_id,)).fetchone()
    if not tt:
        raise KeyError("Вид испытания не найден")
    if not instrument_ids:
        raise ValueError("Необходимо указать хотя бы один поверенный прибор (СИ)")

    snapshots = []
    all_errors = []
    for iid in instrument_ids:
        inst = conn.execute("SELECT * FROM instruments WHERE id = ?", (iid,)).fetchone()
        if not inst:
            all_errors.append(f"Прибор '{iid}' не найден в реестре СИ")
            continue
        inst_d = dict(inst)
        errs = validate_instrument_for_test(inst_d, test_date=test_date, temp_c=temp_c, humidity_pct=humidity_pct)
        all_errors.extend(errs)
        snapshots.append(build_instrument_snapshot(inst_d))

    if all_errors:
        raise PermissionError("; ".join(all_errors))

    mv = conn.execute(
        "SELECT id FROM methodology_versions WHERE methodology_id = ? ORDER BY CASE WHEN status='ACTIVE' THEN 0 ELSE 1 END, rowid DESC LIMIT 1",
        (tt["methodology_id"],),
    ).fetchone()
    tid = str(uuid.uuid4())
    conn.execute(
        """
        INSERT INTO tests (
            id, equipment_id, test_type_id, methodology_version_id, test_date,
            purpose, temp_c, humidity_pct, pressure_mmhg, executor_user_id,
            status, instruments_snapshot_json, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?, ?)
        """,
        (
            tid, equipment_id, test_type_id, mv["id"] if mv else None, test_date,
            purpose, temp_c, humidity_pct, pressure_mmhg, user_id,
            json.dumps(snapshots, ensure_ascii=False), notes,
        ),
    )
    write_audit_log(
        conn,
        action="TEST_DRAFT_CREATED",
        entity_type="test",
        entity_id=tid,
        user_id=user_id,
        after={"equipment_id": equipment_id, "test_type_id": test_type_id, "instruments_count": len(snapshots)},
        ip_address=ip_address,
    )
    return {"id": tid, "status": "DRAFT", "instruments_snapshot": snapshots}


def _get_approved_criteria(conn, methodology_version_id: Optional[str]) -> Dict[str, Any]:
    if not methodology_version_id:
        return {}
    mv = conn.execute(
        "SELECT status, norm_criteria_json FROM methodology_versions WHERE id = ?",
        (methodology_version_id,),
    ).fetchone()
    if not mv or mv["status"] != "ACTIVE":
        return {}
    return json.loads(mv["norm_criteria_json"] or "{}")


def save_draft_measurements(
    conn,
    test_id: str,
    items: List[Dict[str, Any]],
    user_id: str,
    ip_address: Optional[str] = None,
) -> List[Dict[str, Any]]:
    t = conn.execute("SELECT * FROM tests WHERE id = ?", (test_id,)).fetchone()
    if not t:
        raise KeyError("Испытание не найдено")
    if t["status"] != "DRAFT":
        raise PermissionError("Редактирование измерений напрямую разрешено только в черновике; используйте /correct")

    conn.execute("DELETE FROM measurements WHERE test_id = ? AND is_superseded = 0", (test_id,))
    criteria = _get_approved_criteria(conn, t["methodology_version_id"])
    created = []
    for item in items:
        param = conn.execute(
            "SELECT * FROM measurement_parameters WHERE test_type_id = ? AND code = ?",
            (t["test_type_id"], item["parameter_code"]),
        ).fetchone()
        if not param:
            raise ValueError(f"Параметр '{item['parameter_code']}' не относится к данному виду испытания")
        raw_val = str(item["raw_value"]).strip()
        comp, norm_ref = evaluate_measurement_compliance(raw_val, param["code"], criteria)
        mid = str(uuid.uuid4())
        conn.execute(
            """
            INSERT INTO measurements (
                id, test_id, parameter_id, point_label, raw_value, unit,
                instrument_id, compliance_status, norm_ref
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                mid, test_id, param["id"], item.get("point_label"), raw_val,
                item.get("unit") or param["unit"], item.get("instrument_id"), comp, norm_ref,
            ),
        )
        created.append({"id": mid, "parameter_code": param["code"], "raw_value": raw_val, "compliance_status": comp, "norm_ref": norm_ref})

    write_audit_log(
        conn,
        action="MEASUREMENTS_SAVED",
        entity_type="test",
        entity_id=test_id,
        user_id=user_id,
        after={"count": len(created)},
        ip_address=ip_address,
    )
    return created


def correct_measurement(
    conn,
    measurement_id: str,
    new_raw_value: str,
    reason: str,
    user_id: str,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    if not reason or not reason.strip():
        raise ValueError("Обязательно укажите причину исправления измерения (п. 21 ТЗ)")
    old = conn.execute(
        """
        SELECT m.*, mp.code AS param_code, t.methodology_version_id
        FROM measurements m
        JOIN measurement_parameters mp ON mp.id = m.parameter_id
        JOIN tests t ON t.id = m.test_id
        WHERE m.id = ?
        """,
        (measurement_id,),
    ).fetchone()
    if not old:
        raise KeyError("Запись измерения не найдена")
    if old["is_superseded"]:
        raise PermissionError("Нельзя исправлять уже заменённую запись измерения")

    criteria = _get_approved_criteria(conn, old["methodology_version_id"])
    comp, norm_ref = evaluate_measurement_compliance(new_raw_value.strip(), old["param_code"], criteria)
    new_id = str(uuid.uuid4())
    conn.execute(
        """
        INSERT INTO measurements (
            id, test_id, parameter_id, point_label, raw_value, unit,
            conditions_json, instrument_id, compliance_status, norm_ref
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            new_id, old["test_id"], old["parameter_id"], old["point_label"],
            new_raw_value.strip(), old["unit"], old["conditions_json"],
            old["instrument_id"], comp, norm_ref,
        ),
    )
    conn.execute(
        """
        UPDATE measurements
        SET is_superseded = 1, superseded_by_id = ?, correction_reason = ?,
            corrected_by = ?, corrected_at = datetime('now')
        WHERE id = ?
        """,
        (new_id, reason.strip(), user_id, measurement_id),
    )
    write_audit_log(
        conn,
        action="MEASUREMENT_CORRECTED",
        entity_type="measurement",
        entity_id=measurement_id,
        user_id=user_id,
        before={"raw_value": old["raw_value"], "compliance_status": old["compliance_status"]},
        after={"new_id": new_id, "raw_value": new_raw_value.strip(), "compliance_status": comp},
        reason=reason.strip(),
        ip_address=ip_address,
    )
    return {"old_id": measurement_id, "new_id": new_id, "raw_value": new_raw_value.strip(), "compliance_status": comp}


def get_test_details(conn, test_id: str) -> Optional[Dict[str, Any]]:
    t = conn.execute(
        """
        SELECT t.*, tt.code AS test_type_code, tt.name AS test_type_name, e.name AS equipment_name
        FROM tests t
        JOIN test_types tt ON tt.id = t.test_type_id
        JOIN equipment e ON e.id = t.equipment_id
        WHERE t.id = ?
        """,
        (test_id,),
    ).fetchone()
    if not t:
        return None
    d = dict(t)
    d["instruments_snapshot"] = json.loads(d.pop("instruments_snapshot_json") or "[]")
    ms = [
        dict(m)
        for m in conn.execute(
            """
            SELECT m.*, mp.code AS parameter_code, mp.name AS parameter_name
            FROM measurements m JOIN measurement_parameters mp ON mp.id = m.parameter_id
            WHERE m.test_id = ?
            ORDER BY m.created_at ASC
            """,
            (test_id,),
        ).fetchall()
    ]
    d["measurements"] = ms
    return d
