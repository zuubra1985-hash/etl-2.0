import json
from typing import Any, Dict, Optional
from application.server.modules.passports.service import create_passport_version, get_equipment_passport
from application.server.modules.protocols.service import generate_protocol_for_test
from application.server.modules.security.audit import write_audit_log


def confirm_test_and_autofill(
    conn,
    test_id: str,
    user_id: str,
    generate_pdf: bool = True,
    ip_address: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Atomic single-entry transaction (Main Principle of ETL 2.0):
    1. Validate test is DRAFT and has active measurements.
    2. Generate verified DOCX (+PDF) protocol from DB.
    3. Create new passport_versions edition appending test summary to Sections 4-10 (idempotent via source_test_id).
    4. Mark test CONFIRMED and log audit event.
    """
    t = conn.execute(
        """
        SELECT t.*, tt.code AS test_type_code, tt.name AS test_type_name, m.code AS methodology_code
        FROM tests t
        JOIN test_types tt ON tt.id = t.test_type_id
        LEFT JOIN methodologies m ON m.id = tt.methodology_id
        WHERE t.id = ?
        """,
        (test_id,),
    ).fetchone()
    if not t:
        raise KeyError("Испытание не найдено")
    if t["status"] in ("CONFIRMED", "VERIFIED"):
        raise PermissionError("Испытание уже подтверждено; повторное автозаполнение паспорта заблокировано (идемпотентность)")
    if t["status"] == "CANCELLED":
        raise ValueError("Невозможно подтвердить отменённое испытание")

    active_ms = [
        dict(r)
        for r in conn.execute(
            """
            SELECT m.*, mp.code AS parameter_code, mp.name AS parameter_name
            FROM measurements m
            JOIN measurement_parameters mp ON mp.id = m.parameter_id
            WHERE m.test_id = ? AND m.is_superseded = 0
            ORDER BY m.created_at ASC
            """,
            (test_id,),
        ).fetchall()
    ]
    if not active_ms:
        raise ValueError("Невозможно подтвердить испытание без активных измерений")

    # 1. Generate protocol (includes QA post-check & CAS storage)
    protocol = generate_protocol_for_test(
        conn, test_id=test_id, user_id=user_id, generate_pdf=generate_pdf, ip_address=ip_address,
    )

    # 2. Load current passport version data without losing any prior fields/history
    passport_state = get_equipment_passport(conn, t["equipment_id"])
    prev_data = dict(passport_state["current_version"]["data"]) if passport_state["current_version"] else {}
    test_records = list(prev_data.get("test_records", []))

    summary_parts = []
    for m in active_ms:
        pt = f"[{m['point_label']}] " if m.get("point_label") else ""
        unit = f" {m['unit']}" if m.get("unit") else ""
        comp_ru = {'PASS': 'Соответствует', 'FAIL': 'Не соответствует', 'NOT_EVALUATED': 'Не оценивалось'}.get(m['compliance_status'], m['compliance_status'])
        summary_parts.append(f"{pt}{m['parameter_name']}: {str(m['raw_value']).replace('.', ',')}{unit} ({comp_ru})")

    instruments_snap = json.loads(t["instruments_snapshot_json"] or "[]")
    test_records.append({
        "date": t["test_date"],
        "test_type": f"{t['test_type_code']} / {t['methodology_code'] or 'МВИ'} ({t['test_type_name']})",
        "protocol_no": protocol["protocol_no"],
        "protocol_id": protocol["id"],
        "source_test_id": test_id,
        "summary": "; ".join(summary_parts),
        "conclusion": protocol["conclusion"],
        "instruments": [f"{si.get('model')} №{si.get('serial_no')}" for si in instruments_snap],
    })
    prev_data["test_records"] = test_records

    # 3. Create new passport version (enforces unique index on (passport_id, source_test_id))
    new_pv = create_passport_version(
        conn,
        equipment_id=t["equipment_id"],
        data=prev_data,
        change_reason=f"Автозаполнение по протоколу № {protocol['protocol_no']}",
        user_id=user_id,
        source_test_id=test_id,
        ip_address=ip_address,
    )

    # 4. Mark test CONFIRMED
    conn.execute("UPDATE tests SET status = 'CONFIRMED' WHERE id = ?", (test_id,))
    write_audit_log(
        conn,
        action="TEST_CONFIRMED_AND_PASSPORT_FILLED",
        entity_type="test",
        entity_id=test_id,
        user_id=user_id,
        after={"protocol_id": protocol["id"], "protocol_no": protocol["protocol_no"], "passport_version_no": new_pv["version_no"]},
        ip_address=ip_address,
    )

    # Reverse sync: update last_date in ARM ETL 2027 PPR schedule (etl_base.db)
    try:
        import database as arm_db
        inv_no = str(eq["inventory_no"] or "")
        arm_id = inv_no[4:] if inv_no.startswith("ARM-") else (f"ed-reg-{inv_no}" if inv_no.startswith("ED-REG-") else "")
        if arm_id and hasattr(arm_db, "mark_equipment_tested"):
            arm_db.mark_equipment_tested(arm_id, str(test_row["test_date"])[:10], protocol_no=str(proto["protocol_no"]), protocol_type=str(test_row["test_type_name"]), result=str(conclusion), db_path=arm_db.DB_PATH)
    except Exception:
        pass

    return {
        "test_id": test_id,
        "test_status": "CONFIRMED",
        "protocol": protocol,
        "passport_version": new_pv,
    }
