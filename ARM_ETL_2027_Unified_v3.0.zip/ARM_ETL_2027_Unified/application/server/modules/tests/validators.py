import json
from typing import Any, Dict, List, Optional, Tuple


def validate_instrument_for_test(
    inst: Dict[str, Any],
    test_date: str,
    temp_c: Optional[float] = None,
    humidity_pct: Optional[float] = None,
) -> List[str]:
    errors: List[str] = []
    label = f"{inst.get('model')} (зав. № {inst.get('serial_no')})"

    if inst.get("status") != "ACTIVE":
        errors.append(f"Прибор {label} не допущен к работе (статус: {inst.get('status')})")

    valid_until = inst.get("calibration_valid_until")
    if not valid_until:
        errors.append(f"У прибора {label} отсутствует дата окончания поверки ФГИС «АРШИН»")
    elif str(test_date)[:10] > str(valid_until)[:10]:
        errors.append(f"У прибора {label} истёк срок поверки ({valid_until} < {test_date})")

    # Operating climate checks from verified factory passports
    op = json.loads(inst.get("operating_conditions_json") or "{}")
    t_min = op.get("temp_min_c")
    t_max = op.get("temp_max_c")
    h_max = op.get("humidity_max_pct")
    if temp_c is not None:
        if t_min is not None and temp_c < float(t_min):
            errors.append(f"Температура {temp_c} °C ниже рабочего диапазона {label} (мин. {t_min} °C)")
        if t_max is not None and temp_c > float(t_max):
            errors.append(f"Температура {temp_c} °C выше рабочего диапазона {label} (макс. {t_max} °C)")
    if humidity_pct is not None and h_max is not None and humidity_pct > float(h_max):
        errors.append(f"Влажность {humidity_pct}% превышает допустимую для {label} (макс. {h_max}%)")

    return errors


def build_instrument_snapshot(inst: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": inst["id"],
        "model": inst["model"],
        "serial_no": inst["serial_no"],
        "arshin_reg_no": inst.get("arshin_reg_no"),
        "calibration_valid_until": inst.get("calibration_valid_until"),
        "status": inst.get("status"),
    }


def evaluate_measurement_compliance(
    raw_value: str,
    param_code: str,
    norm_criteria: Dict[str, Any],
) -> Tuple[str, Optional[str]]:
    """
    Evaluates measurement ONLY against explicitly approved methodology norm_criteria.
    Never invents norms: returns ('NOT_EVALUATED', None) if no approved rule exists.
    """
    rule = (norm_criteria or {}).get(param_code)
    if not rule:
        return ("NOT_EVALUATED", None)

    norm_ref = rule.get("norm_ref")
    if "equals" in rule:
        ok = str(raw_value).strip().lower() == str(rule["equals"]).strip().lower()
        return ("PASS" if ok else "FAIL", norm_ref)

    try:
        val = float(str(raw_value).replace(",", "."))
    except ValueError:
        return ("NOT_EVALUATED", norm_ref)

    if "min" in rule and val < float(rule["min"]):
        return ("FAIL", norm_ref)
    if "max" in rule and val > float(rule["max"]):
        return ("FAIL", norm_ref)
    return ("PASS", norm_ref)
