import json
from typing import Any, Dict, Set
from fastapi import Depends, HTTPException, Request, status
from application.server.core.db import db_session
from application.server.modules.security.auth import decode_jwt


def get_current_user(request: Request) -> Dict[str, Any]:
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Требуется авторизация (Bearer token)")
    token = auth_header[7:].strip()
    try:
        payload = decode_jwt(token, expected_type="access")
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=f"Недействительный токен: {e}")

    user_id = payload.get("sub")
    with db_session() as conn:
        row = conn.execute(
            """
            SELECT u.id, u.username, u.full_name, u.position, u.eb_group, u.is_active,
                   r.code AS role_code, r.name AS role_name, r.permissions_json
            FROM users u
            JOIN roles r ON r.id = u.role_id
            WHERE u.id = ?
            """,
            (user_id,),
        ).fetchone()
        if not row or not row["is_active"]:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Пользователь не найден или отключён")
        perms: Set[str] = set(json.loads(row["permissions_json"] or "[]"))
        return {
            "id": row["id"],
            "username": row["username"],
            "full_name": row["full_name"],
            "position": row["position"],
            "eb_group": row["eb_group"],
            "role_code": row["role_code"],
            "role_name": row["role_name"],
            "permissions": sorted(perms),
        }


def require_permission(permission: str):
    def _checker(user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
        perms = set(user["permissions"])
        if "*" not in perms and permission not in perms:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Недостаточно прав: требуется '{permission}' (роль {user['role_code']})",
            )
        return user
    return _checker
