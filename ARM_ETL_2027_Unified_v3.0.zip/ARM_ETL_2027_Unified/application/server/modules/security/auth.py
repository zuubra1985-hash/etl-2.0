import base64
import hashlib
import hmac
import json
import secrets
import time
from typing import Any, Dict, Optional
from application.server.core.config import load_settings

PBKDF2_ITERATIONS = 200_000


def hash_password(password: str, salt: Optional[str] = None) -> str:
    salt_hex = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt_hex}${dk.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algo, iters_s, salt_hex, expected_hex = stored_hash.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters_s))
        return hmac.compare_digest(dk.hex(), expected_hex)
    except Exception:
        return False


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def create_jwt(payload: Dict[str, Any], token_type: str = "access", expires_seconds: Optional[int] = None) -> str:
    cfg = load_settings()["resolved"]
    secret = cfg["jwt_secret"].encode("utf-8")
    now = int(time.time())
    if expires_seconds is None:
        expires_seconds = cfg["access_token_minutes"] * 60 if token_type == "access" else cfg["refresh_token_days"] * 86400
    body = dict(payload)
    body.update({"iat": now, "exp": now + expires_seconds, "typ": token_type})
    header_b64 = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode("utf-8"))
    payload_b64 = _b64url_encode(json.dumps(body, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    sig = hmac.new(secret, signing_input, hashlib.sha256).digest()
    return f"{header_b64}.{payload_b64}.{_b64url_encode(sig)}"


def decode_jwt(token: str, expected_type: Optional[str] = None) -> Dict[str, Any]:
    cfg = load_settings()["resolved"]
    secret = cfg["jwt_secret"].encode("utf-8")
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid token structure")
    signing_input = f"{parts[0]}.{parts[1]}".encode("ascii")
    expected_sig = _b64url_encode(hmac.new(secret, signing_input, hashlib.sha256).digest())
    if not hmac.compare_digest(parts[2], expected_sig):
        raise ValueError("Invalid token signature")
    payload = json.loads(_b64url_decode(parts[1]).decode("utf-8"))
    if int(time.time()) > int(payload.get("exp", 0)):
        raise ValueError("Token expired")
    if expected_type and payload.get("typ") != expected_type:
        raise ValueError("Invalid token type")
    return payload
