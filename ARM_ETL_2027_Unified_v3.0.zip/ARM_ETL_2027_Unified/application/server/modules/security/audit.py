import json
from typing import Any, Optional


def write_audit_log(
    conn,
    action: str,
    entity_type: str,
    entity_id: Optional[str] = None,
    user_id: Optional[str] = None,
    before: Any = None,
    after: Any = None,
    reason: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> int:
    cur = conn.execute(
        """
        INSERT INTO audit_log (user_id, action, entity_type, entity_id, before_json, after_json, reason, ip_address)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            user_id,
            action,
            entity_type,
            entity_id,
            json.dumps(before, ensure_ascii=False) if before is not None else None,
            json.dumps(after, ensure_ascii=False) if after is not None else None,
            reason,
            ip_address,
        ),
    )
    return int(cur.lastrowid)
