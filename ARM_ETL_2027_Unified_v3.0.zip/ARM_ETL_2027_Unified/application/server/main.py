from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from application.server.api.v1.routes import router as v1_router
from application.server.core.config import PROJECT_ROOT, load_settings
from etl2_db.migrator import upgrade
from etl2_db.seed import seed_all
from etl2_db.seed_stage6 import seed_stage6_metadata
from etl2_db.seed_stage8 import seed_stage8_mappings


def create_app() -> FastAPI:
    cfg = load_settings()
    app = FastAPI(
        title=cfg["app"]["name"],
        version="1.0.0",
        description="Единая цифровая система учёта электрооборудования, паспортов, QR и испытаний ЭТЛ",
    )

    @app.on_event("startup")
    def _startup():
        upgrade()
        seed_all()
        seed_stage6_metadata()
        seed_stage8_mappings()

    @app.get("/", response_class=HTMLResponse)
    def desktop_ui():
        ui_file = PROJECT_ROOT / "application" / "desktop" / "index.html"
        if ui_file.exists():
            return ui_file.read_text(encoding="utf-8")
        return "<h1>ETL 2.0 Server Running</h1>"

    @app.get('/eq/{qr_token}')
    def qr_landing(qr_token: str):
        return RedirectResponse(url=f'/mobile?token={qr_token}', status_code=302)


    @app.get("/mobile", response_class=HTMLResponse)
    def mobile_pwa():
        p = PROJECT_ROOT / "application" / "mobile" / "index.html"
        return p.read_text(encoding="utf-8")

    @app.get("/mobile/manifest.json")
    def mobile_manifest():
        p = PROJECT_ROOT / "application" / "mobile" / "manifest.json"
        return Response(content=p.read_text(encoding="utf-8"), media_type="application/manifest+json")

    @app.get("/mobile/sw.js")
    def mobile_sw():
        p = PROJECT_ROOT / "application" / "mobile" / "sw.js"
        return Response(content=p.read_text(encoding="utf-8"), media_type="application/javascript")

    app.include_router(v1_router)
    return app


app = create_app()
