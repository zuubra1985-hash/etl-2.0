import hashlib
import os
import uuid
from pathlib import Path
from typing import Dict, Optional
from application.server.core.config import load_settings


def save_attachment_bytes(
    conn,
    content: bytes,
    original_filename: str,
    mime_type: str,
    entity_type: str,
    entity_id: str,
    uploaded_by: Optional[str] = None,
    is_original_immutable: bool = False,
    cas_root: Optional[str] = None,
) -> Dict[str, object]:
    root = Path(cas_root or load_settings()["resolved"]["cas_root"])
    sha256 = hashlib.sha256(content).hexdigest()
    att_id = str(uuid.uuid4())
    rel_dir = Path(sha256[:2]) / sha256[2:4]
    ext = Path(original_filename).suffix.lower()
    rel_path = rel_dir / f"{att_id}_{sha256[:12]}{ext}"
    full_path = root / rel_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    with open(full_path, "wb") as f:
        f.write(content)

    conn.execute(
        """
        INSERT INTO attachments (
            id, entity_type, entity_id, original_filename, storage_rel_path,
            sha256, mime_type, size_bytes, is_original_immutable, uploaded_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            att_id,
            entity_type,
            entity_id,
            original_filename,
            str(rel_path).replace("\\", "/"),
            sha256,
            mime_type,
            len(content),
            1 if is_original_immutable else 0,
            uploaded_by,
        ),
    )
    return {"id": att_id, "sha256": sha256, "size_bytes": len(content), "storage_rel_path": str(rel_path)}


def verify_attachment(conn, attachment_id: str, cas_root: Optional[str] = None) -> bool:
    row = conn.execute("SELECT storage_rel_path, sha256 FROM attachments WHERE id = ?", (attachment_id,)).fetchone()
    if not row:
        return False
    full_path = Path(cas_root or load_settings()["resolved"]["cas_root"]) / row["storage_rel_path"]
    if not full_path.exists():
        return False
    h = hashlib.sha256(full_path.read_bytes()).hexdigest()
    return h == row["sha256"]


def delete_attachment(conn, attachment_id: str, cas_root: Optional[str] = None) -> None:
    row = conn.execute(
        "SELECT storage_rel_path, is_original_immutable FROM attachments WHERE id = ?",
        (attachment_id,),
    ).fetchone()
    if not row:
        return
    if row["is_original_immutable"]:
        raise PermissionError("Удаление неизменяемого оригинала документа запрещено (ADR-005)")
    full_path = Path(cas_root or load_settings()["resolved"]["cas_root"]) / row["storage_rel_path"]
    if full_path.exists():
        os.remove(full_path)
    conn.execute("DELETE FROM attachments WHERE id = ?", (attachment_id,))
