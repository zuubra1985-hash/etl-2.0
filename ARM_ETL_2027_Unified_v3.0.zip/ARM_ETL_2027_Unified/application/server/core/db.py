import os
import sqlite3
from contextlib import contextmanager
from typing import Iterator, Optional
from application.server.core.config import load_settings


def get_db_path(explicit_path: Optional[str] = None) -> str:
    if explicit_path:
        return explicit_path
    return load_settings()["resolved"]["db_path"]


def connect_db(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = get_db_path(db_path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.create_function("LOWER", 1, lambda s: s.lower() if isinstance(s, str) else s)
    conn.create_function("UPPER", 1, lambda s: s.upper() if isinstance(s, str) else s)
    conn.execute("PRAGMA busy_timeout = 30000;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    return conn


@contextmanager
def db_session(db_path: Optional[str] = None) -> Iterator[sqlite3.Connection]:
    conn = connect_db(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
