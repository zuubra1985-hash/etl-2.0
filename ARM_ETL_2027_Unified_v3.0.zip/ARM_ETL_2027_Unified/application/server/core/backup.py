import hashlib
import json
import re
import shutil
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
from application.server.core.config import PROJECT_ROOT, load_settings
from application.server.core.db import connect_db, get_db_path


def create_backup(db_path: Optional[str] = None, backup_root: Optional[str] = None) -> Dict[str, Any]:
    cfg = load_settings()["resolved"]
    src_db = get_db_path(db_path)
    b_root = Path(backup_root or cfg["backup_root"]).resolve()
    b_root.mkdir(parents=True, exist_ok=True)

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_id = f"etl2_backup_{ts}"
    target_dir = b_root / backup_id
    target_dir.mkdir(parents=True, exist_ok=True)
    target_db = target_dir / "etl2.db"

    src_conn = connect_db(src_db)
    dst_conn = sqlite3.connect(str(target_db))
    try:
        src_conn.backup(dst_conn)
    finally:
        dst_conn.close()
        src_conn.close()

    # Also snapshot ARM ETL etl_base.db & CAS attachments if present
    arm_db = PROJECT_ROOT / "etl_base.db"
    includes_arm = False
    if arm_db.exists():
        shutil.copy2(arm_db, target_dir / "etl_base.db")
        includes_arm = True
    cas_dir = Path(cfg["cas_root"])
    cas_files = 0
    if cas_dir.exists():
        dst_cas = target_dir / "cas_storage"
        shutil.copytree(cas_dir, dst_cas, dirs_exist_ok=True)
        cas_files = sum(1 for _ in dst_cas.rglob("*") if _.is_file())

    sha256 = hashlib.sha256(target_db.read_bytes()).hexdigest()
    manifest = {
        "backup_id": backup_id,
        "created_at_utc": ts,
        "db_file": "etl2.db",
        "sha256": sha256,
        "size_bytes": target_db.stat().st_size,
        "includes_arm_etl_db": includes_arm,
        "cas_files_count": cas_files,
    }
    (target_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def verify_backup(backup_id: str, backup_root: Optional[str] = None) -> Dict[str, Any]:
    if not re.match(r"^[a-zA-Z0-9._-]+$", backup_id or ""):
        raise ValueError("Недопустимый идентификатор бэкапа")
    cfg = load_settings()["resolved"]
    b_root = Path(backup_root or cfg["backup_root"]).resolve()
    target_dir = (b_root / backup_id).resolve()
    if not str(target_dir).startswith(str(b_root)):
        raise ValueError("Доступ за пределы каталога бэкапов запрещён")
    manifest_path = target_dir / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Бэкап '{backup_id}' не найден")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    db_file = (target_dir / manifest["db_file"]).resolve()
    if not str(db_file).startswith(str(target_dir)):
        raise ValueError("Некорректный путь файла БД в манифесте")
    actual_sha = hashlib.sha256(db_file.read_bytes()).hexdigest()
    hash_ok = actual_sha == manifest["sha256"]

    conn = sqlite3.connect(str(db_file))
    try:
        res = conn.execute("PRAGMA integrity_check;").fetchone()[0]
    finally:
        conn.close()

    return {
        "backup_id": backup_id,
        "hash_ok": hash_ok,
        "sqlite_integrity": res,
        "verified": bool(hash_ok and res == "ok"),
    }
