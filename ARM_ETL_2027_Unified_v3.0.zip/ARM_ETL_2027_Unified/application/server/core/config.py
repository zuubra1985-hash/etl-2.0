import os
import secrets
from pathlib import Path
from typing import Any, Dict
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_SETTINGS_PATH = PROJECT_ROOT / "configuration" / "settings.yaml"


def load_settings(settings_path: Path = None) -> Dict[str, Any]:
    path = settings_path or Path(os.environ.get("ETL2_SETTINGS_PATH", str(DEFAULT_SETTINGS_PATH)))
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    # Resolve paths relative to PROJECT_ROOT with env overrides
    db_path = os.environ.get("ETL2_DB_PATH") or cfg.get("database", {}).get("sqlite_path", "database/etl2.db")
    cas_root = os.environ.get("ETL2_CAS_ROOT") or cfg.get("storage", {}).get("cas_root", "data/cas_storage")
    backup_root = os.environ.get("ETL2_BACKUP_ROOT") or cfg.get("storage", {}).get("backup_root", "backups")

    cfg.setdefault("resolved", {})
    cfg["resolved"]["project_root"] = str(PROJECT_ROOT)
    cfg["resolved"]["db_path"] = str(Path(db_path) if os.path.isabs(db_path) else PROJECT_ROOT / db_path)
    cfg["resolved"]["cas_root"] = str(Path(cas_root) if os.path.isabs(cas_root) else PROJECT_ROOT / cas_root)
    cfg["resolved"]["backup_root"] = str(Path(backup_root) if os.path.isabs(backup_root) else PROJECT_ROOT / backup_root)

    sec = cfg.get("security", {})
    secret_env = sec.get("jwt_secret_env", "ETL2_SECRET_KEY")
    env_sec = os.environ.get(secret_env)
    if env_sec:
        cfg["resolved"]["jwt_secret"] = env_sec
    else:
        key_file = PROJECT_ROOT / "configuration" / ".secret_key"
        if not key_file.exists():
            key_file.parent.mkdir(parents=True, exist_ok=True)
            key_file.write_text(secrets.token_hex(32), encoding="utf-8")
            try:
                os.chmod(key_file, 0o600)
            except OSError:
                pass
        cfg["resolved"]["jwt_secret"] = key_file.read_text(encoding="utf-8").strip()
    cfg["resolved"]["access_token_minutes"] = int(sec.get("access_token_minutes", 60))
    cfg["resolved"]["refresh_token_days"] = int(sec.get("refresh_token_days", 7))
    return cfg
