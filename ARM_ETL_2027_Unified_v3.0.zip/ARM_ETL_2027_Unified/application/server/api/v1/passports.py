from urllib.parse import quote
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, File, HTTPException, Request, Response, UploadFile, status
from pydantic import BaseModel

from application.server.core.db import db_session
from application.server.modules.passports.service import (
    create_passport_version,
    export_passport_bytes,
    get_equipment_passport,
    upload_original_passport,
)
from application.server.modules.passports.templates import PASSPORT_TEMPLATES
from application.server.modules.security.rbac import require_permission

passports_router = APIRouter(tags=["passports"])


class PassportVersionRequest(BaseModel):
    data: Dict[str, Any]
    change_reason: str


@passports_router.get("/passport-templates")
def api_list_passport_templates(user: Dict[str, Any] = Depends(require_permission("passport:read"))) -> List[Dict[str, Any]]:
    return list(PASSPORT_TEMPLATES.values())


@passports_router.get("/equipment/{equipment_id}/passport")
def api_get_passport(
    equipment_id: str,
    user: Dict[str, Any] = Depends(require_permission("passport:read")),
) -> Dict[str, Any]:
    with db_session() as conn:
        try:
            return get_equipment_passport(conn, equipment_id)
        except KeyError as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@passports_router.post("/equipment/{equipment_id}/passport/original", status_code=status.HTTP_201_CREATED)
async def api_upload_original(
    equipment_id: str,
    request: Request,
    file: UploadFile = File(...),
    user: Dict[str, Any] = Depends(require_permission("passport:write")),
) -> Dict[str, Any]:
    content = await file.read()
    if not content:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Файл пуст")
    with db_session() as conn:
        try:
            return upload_original_passport(
                conn,
                equipment_id=equipment_id,
                content=content,
                filename=file.filename or "original_passport.bin",
                mime_type=file.content_type or "application/octet-stream",
                user_id=user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
        except PermissionError as e:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))


@passports_router.post("/equipment/{equipment_id}/passport/versions", status_code=status.HTTP_201_CREATED)
def api_create_passport_version(
    equipment_id: str,
    body: PassportVersionRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("passport:write")),
) -> Dict[str, Any]:
    if not body.change_reason.strip():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Укажите причину создания редакции паспорта")
    with db_session() as conn:
        try:
            return create_passport_version(
                conn,
                equipment_id=equipment_id,
                data=body.data,
                change_reason=body.change_reason.strip(),
                user_id=user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@passports_router.get("/passports/{passport_id}/versions/{version_no}/export")
def api_export_passport(
    passport_id: str,
    version_no: int,
    format: str = "docx",
    user: Dict[str, Any] = Depends(require_permission("passport:read")),
):
    with db_session() as conn:
        try:
            data, fname, media = export_passport_bytes(conn, passport_id, version_no=version_no if version_no > 0 else None, fmt=format)
        except KeyError as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    return Response(
        content=data,
        media_type=media,
        headers={"Content-Disposition": f"attachment; filename=\"export\"; filename*=UTF-8''{quote(fname)}"},
    )
