from urllib.parse import quote
from typing import Any, Dict, List
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel

from application.server.core.db import db_session
from application.server.modules.qr.service import (
    get_qr_image_bytes,
    print_qr_batch_pdf,
    resolve_qr_token,
    verify_equipment_qr,
)
from application.server.modules.security.rbac import require_permission

qr_router = APIRouter(tags=["qr"])


class PrintBatchRequest(BaseModel):
    equipment_ids: List[str]
    preset: str = "a4_3x7"


@qr_router.get("/qr/resolve/{qr_token}")
def api_resolve_qr(
    qr_token: str,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("equipment:read")),
):
    with db_session() as conn:
        try:
            return resolve_qr_token(
                conn, qr_token, user["id"], ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except RuntimeError as e:
            raise HTTPException(status_code=500, detail=str(e))


@qr_router.get("/equipment/{equipment_id}/qr/verify")
def api_verify_qr(equipment_id: str, user: Dict[str, Any] = Depends(require_permission("equipment:read"))):
    with db_session() as conn:
        try:
            return verify_equipment_qr(conn, equipment_id)
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))


@qr_router.get("/equipment/{equipment_id}/qr/image")
def api_qr_image(
    equipment_id: str,
    format: str = "png",
    user: Dict[str, Any] = Depends(require_permission("equipment:read")),
):
    with db_session() as conn:
        try:
            data, mime = get_qr_image_bytes(conn, equipment_id, fmt=format)
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    return Response(content=data, media_type=mime)


@qr_router.post("/qr/print-batch")
def api_print_qr_batch(
    body: PrintBatchRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("equipment:read")),
):
    with db_session() as conn:
        try:
            pdf_bytes, fname = print_qr_batch_pdf(
                conn, body.equipment_ids, body.preset, user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=\"export\"; filename*=UTF-8''{quote(fname)}"},
    )
