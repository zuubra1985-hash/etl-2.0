from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel

from application.server.core.db import db_session
from application.server.modules.security.rbac import require_permission
from application.server.modules.tests.service import (
    approve_methodology_criteria,
    correct_measurement,
    create_test_draft,
    get_applicable_tests,
    get_test_details,
    get_test_type_form_schema,
    save_draft_measurements,
    update_instrument_calibration,
)

tests_router = APIRouter(tags=["tests"])


class ApproveCriteriaRequest(BaseModel):
    edition: str = "2026-утв"
    norm_criteria: Dict[str, Any]


class InstrumentUpdateRequest(BaseModel):
    calibration_date: Optional[str] = None
    calibration_valid_until: Optional[str] = None
    status: Optional[str] = None
    arshin_reg_no: Optional[str] = None
    notes: Optional[str] = None


class CreateTestRequest(BaseModel):
    equipment_id: str
    test_type_id: str
    test_date: str
    instrument_ids: List[str]
    temp_c: Optional[float] = None
    humidity_pct: Optional[float] = None
    pressure_mmhg: Optional[float] = None
    purpose: str = "эксплуатационные"
    notes: Optional[str] = None


class MeasurementItem(BaseModel):
    parameter_code: str
    raw_value: str
    point_label: Optional[str] = None
    unit: Optional[str] = None
    instrument_id: Optional[str] = None


class SaveMeasurementsRequest(BaseModel):
    items: List[MeasurementItem]


class CorrectMeasurementRequest(BaseModel):
    new_raw_value: str
    reason: str


@tests_router.get("/equipment/{equipment_id}/applicable-tests")
def api_applicable_tests(equipment_id: str, user: Dict[str, Any] = Depends(require_permission("test:read"))):
    with db_session() as conn:
        try:
            return get_applicable_tests(conn, equipment_id)
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))


@tests_router.get("/test-types")
def api_list_test_types(user: Dict[str, Any] = Depends(require_permission("test:read"))):
    with db_session() as conn:
        rows = conn.execute(
            "SELECT tt.id, tt.code, tt.name, m.code AS methodology_code FROM test_types tt LEFT JOIN methodologies m ON m.id = tt.methodology_id ORDER BY tt.code"
        ).fetchall()
    return [dict(r) for r in rows]


@tests_router.get("/test-types/{test_type_id}/form-schema")
def api_test_form_schema(test_type_id: str, user: Dict[str, Any] = Depends(require_permission("test:read"))):
    with db_session() as conn:
        try:
            return get_test_type_form_schema(conn, test_type_id)
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))


@tests_router.post("/methodologies/{methodology_id}/approve-criteria")
def api_approve_criteria(
    methodology_id: str,
    body: ApproveCriteriaRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("methodology:approve")),
):
    with db_session() as conn:
        try:
            return approve_methodology_criteria(
                conn, methodology_id, body.norm_criteria, body.edition, user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))


@tests_router.patch("/instruments/{instrument_id}")
def api_update_instrument(
    instrument_id: str,
    body: InstrumentUpdateRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("instrument:write")),
):
    with db_session() as conn:
        try:
            return update_instrument_calibration(
                conn, instrument_id, body.dict(exclude_unset=True), user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))


@tests_router.post("/tests", status_code=status.HTTP_201_CREATED)
def api_create_test(
    body: CreateTestRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("test:write")),
):
    with db_session() as conn:
        try:
            return create_test_draft(
                conn,
                equipment_id=body.equipment_id,
                test_type_id=body.test_type_id,
                test_date=body.test_date,
                instrument_ids=body.instrument_ids,
                user_id=user["id"],
                temp_c=body.temp_c,
                humidity_pct=body.humidity_pct,
                pressure_mmhg=body.pressure_mmhg,
                purpose=body.purpose,
                notes=body.notes,
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except PermissionError as e:
            raise HTTPException(status_code=422, detail=str(e))


@tests_router.get("/tests/{test_id}")
def api_get_test(test_id: str, user: Dict[str, Any] = Depends(require_permission("test:read"))):
    with db_session() as conn:
        res = get_test_details(conn, test_id)
    if not res:
        raise HTTPException(status_code=404, detail="Испытание не найдено")
    return res


@tests_router.put("/tests/{test_id}/measurements")
def api_save_measurements(
    test_id: str,
    body: SaveMeasurementsRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("test:write")),
):
    with db_session() as conn:
        try:
            return save_draft_measurements(
                conn, test_id, [i.dict() for i in body.items], user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except PermissionError as e:
            raise HTTPException(status_code=409, detail=str(e))


@tests_router.post("/measurements/{measurement_id}/correct")
def api_correct_measurement(
    measurement_id: str,
    body: CorrectMeasurementRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("test:write")),
):
    with db_session() as conn:
        try:
            return correct_measurement(
                conn, measurement_id, body.new_raw_value, body.reason, user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except PermissionError as e:
            raise HTTPException(status_code=409, detail=str(e))

from application.server.modules.tests.confirm_service import confirm_test_and_autofill


@tests_router.post("/tests/{test_id}/confirm")
def api_confirm_test(
    test_id: str,
    request: Request,
    generate_pdf: bool = True,
    user: Dict[str, Any] = Depends(require_permission("test:confirm")),
):
    with db_session() as conn:
        try:
            return confirm_test_and_autofill(
                conn, test_id, user["id"], generate_pdf=generate_pdf,
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except PermissionError as e:
            raise HTTPException(status_code=409, detail=str(e))


@tests_router.get("/passport-fill-mappings")
def api_list_fill_mappings(user: Dict[str, Any] = Depends(require_permission("passport:read"))):
    with db_session() as conn:
        rows = conn.execute(
            """
            SELECT m.id, et.code AS equipment_type_code, tt.code AS test_type_code,
                   m.passport_section_code, m.mapping_rules_json, m.is_active
            FROM passport_fill_mappings m
            JOIN equipment_types et ON et.id = m.equipment_type_id
            JOIN test_types tt ON tt.id = m.test_type_id
            ORDER BY et.code, tt.code
            """
        ).fetchall()
    return [dict(r) for r in rows]
