from urllib.parse import quote
from typing import Any, Dict
from fastapi import APIRouter, Depends, HTTPException, Response

from application.server.core.db import db_session
from application.server.modules.reports.service import export_summary_report, get_dashboard_summary, global_search
from application.server.modules.security.rbac import require_permission

reports_router = APIRouter(tags=["reports"])


@reports_router.get("/dashboard/summary")
def api_dashboard_summary(
    warn_days: int = 60,
    user: Dict[str, Any] = Depends(require_permission("equipment:read")),
) -> Dict[str, Any]:
    with db_session() as conn:
        return get_dashboard_summary(conn, warn_days=warn_days)


@reports_router.get("/search")
def api_global_search(
    q: str,
    limit: int = 25,
    user: Dict[str, Any] = Depends(require_permission("equipment:read")),
) -> Dict[str, Any]:
    if not q or not q.strip():
        raise HTTPException(status_code=400, detail="Укажите поисковый запрос 'q'")
    with db_session() as conn:
        return global_search(conn, q=q, limit=min(limit, 100))


@reports_router.get("/reports/export")
def api_export_report(
    format: str = "xlsx",
    user: Dict[str, Any] = Depends(require_permission("report:export")),
):
    with db_session() as conn:
        try:
            data, fname, mime = export_summary_report(conn, fmt=format)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    return Response(content=data, media_type=mime, headers={"Content-Disposition": f"attachment; filename=\"export\"; filename*=UTF-8''{quote(fname)}"})
