import json
import uuid
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel

from application.server.core.backup import create_backup, verify_backup
from application.server.core.config import load_settings
from application.server.core.db import db_session
from application.server.modules.security.audit import write_audit_log
from application.server.modules.security.auth import create_jwt, decode_jwt, hash_password, verify_password
from application.server.modules.security.rbac import get_current_user, require_permission
from etl2_db.migrator import get_applied_versions

router = APIRouter(prefix="/api/v1")


class LoginRequest(BaseModel):
    username: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class CreateUserRequest(BaseModel):
    username: str
    full_name: str
    password: str
    role_code: str
    position: Optional[str] = None
    eb_group: Optional[str] = None


class UpdateUserRequest(BaseModel):
    full_name: Optional[str] = None
    position: Optional[str] = None
    eb_group: Optional[str] = None
    role_code: Optional[str] = None
    is_active: Optional[bool] = None


@router.get("/health")
def health_check() -> Dict[str, Any]:
    cfg = load_settings()
    with db_session() as conn:
        wal = conn.execute("PRAGMA journal_mode;").fetchone()[0]
        tables = conn.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name != 'schema_migrations'"
        ).fetchone()[0]
        instruments_cnt = conn.execute("SELECT COUNT(*) FROM instruments").fetchone()[0]
        eq_types_cnt = conn.execute("SELECT COUNT(*) FROM equipment_types").fetchone()[0]
        mvi_cnt = conn.execute("SELECT COUNT(*) FROM methodologies").fetchone()[0]
        migrations = get_applied_versions(conn)
    return {
        "status": "ok",
        "app": cfg["app"]["name"],
        "version": cfg["app"]["version"],
        "organization": cfg["organization"]["name"],
        "db_journal_mode": wal,
        "domain_tables": tables,
        "applied_migrations": migrations,
        "seeded": {
            "equipment_types": eq_types_cnt,
            "methodologies": mvi_cnt,
            "instruments": instruments_cnt,
        },
    }


@router.post("/auth/login")
def login(body: LoginRequest, request: Request) -> Dict[str, Any]:
    with db_session() as conn:
        row = conn.execute(
            """
            SELECT u.id, u.username, u.full_name, u.password_hash, u.is_active, r.code AS role_code
            FROM users u
            JOIN roles r ON r.id = u.role_id
            WHERE u.username = ?
            """,
            (body.username,),
        ).fetchone()
        if not row or not row["is_active"] or not verify_password(body.password, row["password_hash"]):
            write_audit_log(
                conn,
                action="LOGIN_FAILED",
                entity_type="user",
                after={"username": body.username},
                ip_address=request.client.host if request.client else None,
            )
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Неверный логин или пароль")

        access = create_jwt({"sub": row["id"], "username": row["username"], "role": row["role_code"]}, "access")
        refresh = create_jwt({"sub": row["id"], "username": row["username"], "role": row["role_code"]}, "refresh")
        write_audit_log(
            conn,
            action="LOGIN_SUCCESS",
            entity_type="user",
            entity_id=row["id"],
            user_id=row["id"],
            ip_address=request.client.host if request.client else None,
        )
        return {
            "access_token": access,
            "refresh_token": refresh,
            "token_type": "bearer",
            "user": {"id": row["id"], "username": row["username"], "full_name": row["full_name"], "role": row["role_code"]},
        }


@router.post("/auth/refresh")
def refresh_token(body: RefreshRequest) -> Dict[str, Any]:
    try:
        payload = decode_jwt(body.refresh_token, expected_type="refresh")
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=f"Недействительный refresh-токен: {e}")
    with db_session() as conn:
        row = conn.execute(
            "SELECT u.id, u.username, u.is_active, r.code AS role_code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?",
            (payload.get("sub"),),
        ).fetchone()
    if not row or not row["is_active"]:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Пользователь отключён или не найден")
    access = create_jwt({"sub": row["id"], "username": row["username"], "role": row["role_code"]}, "access")
    return {"access_token": access, "token_type": "bearer"}


@router.get("/auth/me")
def me(user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    return user


@router.get("/users")
def list_users(user: Dict[str, Any] = Depends(require_permission("users:manage"))) -> List[Dict[str, Any]]:
    with db_session() as conn:
        rows = conn.execute(
            """
            SELECT u.id, u.username, u.full_name, u.position, u.eb_group, u.is_active, u.created_at,
                   r.code AS role_code, r.name AS role_name
            FROM users u JOIN roles r ON r.id = u.role_id
            ORDER BY u.username
            """
        ).fetchall()
    return [dict(r) for r in rows]


@router.post("/users", status_code=status.HTTP_201_CREATED)
def create_user(
    body: CreateUserRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_permission("users:manage")),
) -> Dict[str, Any]:
    with db_session() as conn:
        if conn.execute("SELECT id FROM users WHERE username = ?", (body.username,)).fetchone():
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Пользователь с таким логином уже существует")
        role = conn.execute("SELECT id FROM roles WHERE code = ?", (body.role_code.upper(),)).fetchone()
        if not role:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Неизвестная роль")
        uid = str(uuid.uuid4())
        conn.execute(
            """
            INSERT INTO users (id, username, full_name, position, eb_group, password_hash, role_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (uid, body.username, body.full_name, body.position, body.eb_group, hash_password(body.password), role["id"]),
        )
        write_audit_log(
            conn,
            action="USER_CREATED",
            entity_type="user",
            entity_id=uid,
            user_id=admin["id"],
            after={"username": body.username, "role_code": body.role_code.upper()},
            ip_address=request.client.host if request.client else None,
        )
    return {"id": uid, "username": body.username, "role_code": body.role_code.upper()}


@router.patch("/users/{user_id}")
def update_user(
    user_id: str,
    body: UpdateUserRequest,
    request: Request,
    admin: Dict[str, Any] = Depends(require_permission("users:manage")),
) -> Dict[str, Any]:
    with db_session() as conn:
        existing = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if not existing:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Пользователь не найден")
        updates = {}
        if body.full_name is not None:
            updates["full_name"] = body.full_name
        if body.position is not None:
            updates["position"] = body.position
        if body.eb_group is not None:
            updates["eb_group"] = body.eb_group
        if body.is_active is not None:
            updates["is_active"] = 1 if body.is_active else 0
        if body.role_code is not None:
            role = conn.execute("SELECT id FROM roles WHERE code = ?", (body.role_code.upper(),)).fetchone()
            if not role:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Неизвестная роль")
            updates["role_id"] = role["id"]
        if updates:
            set_clause = ", ".join(f"{k} = ?" for k in updates)
            conn.execute(f"UPDATE users SET {set_clause} WHERE id = ?", (*updates.values(), user_id))
            write_audit_log(
                conn,
                action="USER_UPDATED",
                entity_type="user",
                entity_id=user_id,
                user_id=admin["id"],
                after=updates,
                ip_address=request.client.host if request.client else None,
            )
    return {"id": user_id, "updated": list(updates.keys())}


@router.get("/instruments")
def list_instruments(user: Dict[str, Any] = Depends(require_permission("instrument:read"))) -> List[Dict[str, Any]]:
    with db_session() as conn:
        rows = conn.execute("SELECT * FROM instruments ORDER BY model").fetchall()
    return [dict(r) for r in rows]


@router.get("/equipment-types")
def list_equipment_types(user: Dict[str, Any] = Depends(require_permission("equipment:read"))) -> List[Dict[str, Any]]:
    with db_session() as conn:
        rows = conn.execute("SELECT id, code, name FROM equipment_types ORDER BY code").fetchall()
    return [dict(r) for r in rows]


@router.get("/methodologies")
def list_methodologies(user: Dict[str, Any] = Depends(require_permission("equipment:read"))) -> List[Dict[str, Any]]:
    with db_session() as conn:
        rows = conn.execute("SELECT id, code, title, scope, is_active FROM methodologies ORDER BY code").fetchall()
    return [dict(r) for r in rows]


@router.get("/audit-log")
def get_audit_log(limit: int = 50, user: Dict[str, Any] = Depends(require_permission("audit:read"))) -> List[Dict[str, Any]]:
    with db_session() as conn:
        rows = conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (min(limit, 500),)).fetchall()
    return [dict(r) for r in rows]


@router.post("/admin/backups", status_code=status.HTTP_201_CREATED)
def run_backup(request: Request, user: Dict[str, Any] = Depends(require_permission("backup:run"))) -> Dict[str, Any]:
    manifest = create_backup()
    with db_session() as conn:
        write_audit_log(
            conn,
            action="BACKUP_CREATED",
            entity_type="backup",
            entity_id=manifest["backup_id"],
            user_id=user["id"],
            after=manifest,
            ip_address=request.client.host if request.client else None,
        )
    return manifest


@router.post("/admin/backups/{backup_id}/verify")
def check_backup(backup_id: str, user: Dict[str, Any] = Depends(require_permission("backup:run"))) -> Dict[str, Any]:
    try:
        return verify_backup(backup_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

from application.server.api.v1.equipment import equipment_router
router.include_router(equipment_router)

from application.server.api.v1.passports import passports_router
router.include_router(passports_router)

from application.server.api.v1.tests_api import tests_router
router.include_router(tests_router)

from application.server.api.v1.protocols import protocols_router
router.include_router(protocols_router)

from application.server.api.v1.qr import qr_router
router.include_router(qr_router)

from application.server.api.v1.reports import reports_router
router.include_router(reports_router)
