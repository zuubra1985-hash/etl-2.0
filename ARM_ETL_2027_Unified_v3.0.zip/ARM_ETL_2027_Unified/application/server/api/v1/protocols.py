from urllib.parse import quote
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel

from application.server.core.db import db_session
from application.server.modules.protocols.service import (
    generate_protocol_for_test,
    get_protocol_download,
    transition_protocol_status,
)
from application.server.modules.security.rbac import get_current_user, require_permission

protocols_router = APIRouter(tags=["protocols"])


class ProtocolStatusRequest(BaseModel):
    status: str
    reason: Optional[str] = None


@protocols_router.post("/tests/{test_id}/generate-protocol", status_code=status.HTTP_201_CREATED)
def api_generate_protocol(
    test_id: str,
    request: Request,
    generate_pdf: bool = True,
    user: Dict[str, Any] = Depends(require_permission("test:write")),
):
    with db_session() as conn:
        try:
            return generate_protocol_for_test(
                conn, test_id, user["id"], generate_pdf=generate_pdf,
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except RuntimeError as e:
            raise HTTPException(status_code=422, detail=str(e))


@protocols_router.get("/protocols")
def api_list_protocols(
    test_id: Optional[str] = None,
    status_filter: Optional[str] = None,
    user: Dict[str, Any] = Depends(require_permission("test:read")),
) -> List[Dict[str, Any]]:
    where = ["1=1"]
    params = []
    if test_id:
        where.append("test_id = ?")
        params.append(test_id)
    if status_filter:
        where.append("status = ?")
        params.append(status_filter.upper())
    with db_session() as conn:
        rows = conn.execute(
            f"SELECT id, test_id, protocol_no, version_no, status, conclusion, created_at FROM protocols WHERE {' AND '.join(where)} ORDER BY created_at DESC",
            params,
        ).fetchall()
    return [dict(r) for r in rows]


@protocols_router.get("/protocols/{protocol_id}/download")
def api_download_protocol(
    protocol_id: str,
    format: str = "docx",
    user: Dict[str, Any] = Depends(require_permission("test:read")),
):
    with db_session() as conn:
        try:
            data, fname, mime = get_protocol_download(conn, protocol_id, fmt=format)
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
    return Response(content=data, media_type=mime, headers={"Content-Disposition": f"attachment; filename=\"export\"; filename*=UTF-8''{quote(fname)}"})


@protocols_router.post("/protocols/{protocol_id}/status")
def api_change_protocol_status(
    protocol_id: str,
    body: ProtocolStatusRequest,
    request: Request,
    user: Dict[str, Any] = Depends(get_current_user),
):
    with db_session() as conn:
        try:
            return transition_protocol_status(
                conn, protocol_id, body.status, user, reason=body.reason,
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except PermissionError as e:
            raise HTTPException(status_code=403, detail=str(e))
