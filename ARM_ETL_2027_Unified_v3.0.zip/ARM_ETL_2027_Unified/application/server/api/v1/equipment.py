from pathlib import Path
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel

from application.server.core.config import PROJECT_ROOT
from application.server.core.db import db_session
from application.server.modules.equipment.excel_importer import import_motors_excel
from application.server.modules.equipment.service import (
    archive_equipment_record,
    create_equipment_record,
    find_duplicates,
    get_equipment_card,
    get_or_create_location,
    list_equipment,
    update_equipment_record,
)
from application.server.modules.security.rbac import require_permission

equipment_router = APIRouter(tags=["equipment"])


class EquipmentCreateRequest(BaseModel):
    type_code: str
    name: str
    location_id: Optional[str] = None
    facility_name: Optional[str] = None
    inventory_no: Optional[str] = None
    serial_no: Optional[str] = None
    dispatch_name: Optional[str] = None
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    specs: Optional[Dict[str, Any]] = None
    commissioned_at: Optional[str] = None
    force_create: bool = False


class EquipmentUpdateRequest(BaseModel):
    name: Optional[str] = None
    model: Optional[str] = None
    dispatch_name: Optional[str] = None
    inventory_no: Optional[str] = None
    serial_no: Optional[str] = None
    manufacturer: Optional[str] = None
    commissioned_at: Optional[str] = None
    status: Optional[str] = None
    location_id: Optional[str] = None
    facility_name: Optional[str] = None
    specs: Optional[Dict[str, Any]] = None
    reason: Optional[str] = None


class ArchiveRequest(BaseModel):
    reason: str


@equipment_router.get("/locations")
def api_list_locations(user: Dict[str, Any] = Depends(require_permission("equipment:read"))) -> List[Dict[str, Any]]:
    with db_session() as conn:
        rows = conn.execute(
            """
            SELECT l.id, l.facility_name, l.building, l.room,
                   (SELECT COUNT(*) FROM equipment e WHERE e.location_id = l.id AND e.is_archived = 0) AS equipment_count
            FROM locations l
            ORDER BY l.facility_name ASC
            """
        ).fetchall()
    return [dict(r) for r in rows]


@equipment_router.get("/equipment")
def api_list_equipment(
    search: Optional[str] = None,
    type_code: Optional[str] = None,
    location_id: Optional[str] = None,
    status_filter: Optional[str] = None,
    include_archived: bool = False,
    incomplete_only: bool = False,
    page: int = 1,
    page_size: int = 50,
    user: Dict[str, Any] = Depends(require_permission("equipment:read")),
) -> Dict[str, Any]:
    with db_session() as conn:
        return list_equipment(
            conn,
            search=search,
            type_code=type_code,
            location_id=location_id,
            status=status_filter,
            include_archived=include_archived,
            incomplete_only=incomplete_only,
            page=max(1, page),
            page_size=max(1, min(page_size, 250)),
        )


@equipment_router.post("/equipment", status_code=status.HTTP_201_CREATED)
def api_create_equipment(
    body: EquipmentCreateRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("equipment:write")),
) -> Dict[str, Any]:
    with db_session() as conn:
        loc_id = body.location_id
        if not loc_id and body.facility_name:
            loc_id = get_or_create_location(conn, body.facility_name)
        if not body.force_create:
            dups = find_duplicates(
                conn,
                inventory_no=body.inventory_no,
                serial_no=body.serial_no,
                dispatch_name=body.dispatch_name,
                location_id=loc_id,
            )
            if dups:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={"message": "Обнаружены возможные дубликаты оборудования", "duplicates": dups},
                )
        try:
            return create_equipment_record(
                conn,
                type_code=body.type_code,
                name=body.name,
                user_id=user["id"],
                location_id=loc_id,
                inventory_no=body.inventory_no,
                serial_no=body.serial_no,
                dispatch_name=body.dispatch_name,
                manufacturer=body.manufacturer,
                model=body.model,
                specs=body.specs,
                commissioned_at=body.commissioned_at,
                ip_address=request.client.host if request.client else None,
            )
        except ValueError as e:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@equipment_router.get("/equipment/{equipment_id}")
def api_get_equipment_card(
    equipment_id: str,
    user: Dict[str, Any] = Depends(require_permission("equipment:read")),
) -> Dict[str, Any]:
    with db_session() as conn:
        card = get_equipment_card(conn, equipment_id)
    if not card:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Оборудование не найдено")
    return card


@equipment_router.patch("/equipment/{equipment_id}")
def api_update_equipment(
    equipment_id: str,
    body: EquipmentUpdateRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("equipment:write")),
) -> Dict[str, Any]:
    with db_session() as conn:
        try:
            return update_equipment_record(
                conn,
                equipment_id=equipment_id,
                updates=body.dict(exclude_unset=True),
                user_id=user["id"],
                reason=body.reason,
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@equipment_router.post("/equipment/{equipment_id}/archive")
def api_archive_equipment(
    equipment_id: str,
    body: ArchiveRequest,
    request: Request,
    user: Dict[str, Any] = Depends(require_permission("equipment:write")),
) -> Dict[str, Any]:
    if not body.reason.strip():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Укажите причину архивирования")
    with db_session() as conn:
        try:
            return archive_equipment_record(
                conn,
                equipment_id=equipment_id,
                reason=body.reason.strip(),
                user_id=user["id"],
                ip_address=request.client.host if request.client else None,
            )
        except KeyError as e:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@equipment_router.post("/equipment/import-excel")
def api_import_motors_excel(
    user: Dict[str, Any] = Depends(require_permission("backup:run")),
) -> Dict[str, Any]:
    xlsx = PROJECT_ROOT / "data" / "equipment" / "motors_register_2024.xlsx"
    try:
        return import_motors_excel(str(xlsx), user_id=user["id"])
    except FileNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

from application.server.modules.equipment.arm_etl_sync import sync_from_arm_etl_seed


@equipment_router.post("/sync/from-arm-etl")
def api_sync_from_arm_etl(user: Dict[str, Any] = Depends(require_permission("backup:run"))) -> Dict[str, Any]:
    try:
        return sync_from_arm_etl_seed(user_id=user["id"])
    except FileNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
