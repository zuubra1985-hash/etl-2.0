const CACHE_NAME = "etl2-mobile-v1";
const SHELL_URLS = ["/mobile", "/mobile/manifest.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_URLS)));
});

self.addEventListener("fetch", (event) => {
  if (event.request.url.includes("/api/")) {
    return; // API calls always go to network for data integrity
  }
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
