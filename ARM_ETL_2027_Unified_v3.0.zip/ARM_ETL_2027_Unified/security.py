"""Модуль безопасности АРМ ЭТЛ: пользователи, роли, сессии, журнал аудита, проверка загрузок и ZIP-бэкапы."""

from __future__ import annotations

import datetime
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shutil
import sqlite3
import tempfile
import zipfile
from pathlib import Path
from typing import Any

import database

SESSION_COOKIE = "etl_session"
SESSION_TTL_DAYS = 7

ROLES = {
    "admin": "Начальник ЭТЛ (Администратор)",
    "engineer": "Инженер / Производитель работ",
    "viewer": "Наблюдатель (только чтение)",
}

DEFAULT_USERS = [
    ("likhanov", "Лиханов Д.Ю. (Начальник ЭТЛ)", "admin", "2027"),
    ("kalimullin", "Калимуллин Р.Р. (Инженер РЗиА)", "engineer", "1234"),
    ("viewer", "Наблюдатель (только чтение)", "viewer", "0000"),
]

MAX_SCAN_BYTES = 20 * 1024 * 1024
MAX_TABLE_BYTES = 10 * 1024 * 1024
MAX_BACKUP_BYTES = 100 * 1024 * 1024


def _connect(db_path: Path = database.DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def _now_iso() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def hash_password(password: str, salt: str | None = None) -> str:
    s = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), s.encode("utf-8"), 120_000)
    return f"pbkdf2_sha256${s}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, s, hex_hash = stored.split("$", 2)
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), s.encode("utf-8"), 120_000)
        return hmac.compare_digest(dk.hex(), hex_hash)
    except Exception:
        return False


def init_security_tables(db_path: Path = database.DB_PATH) -> None:
    with _connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                login TEXT UNIQUE NOT NULL,
                full_name TEXT NOT NULL,
                role TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                login TEXT NOT NULL,
                role TEXT NOT NULL,
                full_name TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                user_login TEXT NOT NULL,
                user_role TEXT NOT NULL,
                action TEXT NOT NULL,
                entity TEXT NOT NULL,
                details TEXT NOT NULL,
                ip TEXT NOT NULL DEFAULT ''
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts DESC)")
        cnt = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if cnt == 0:
            now = _now_iso()
            for login, full_name, role, raw_pwd in DEFAULT_USERS:
                conn.execute(
                    "INSERT INTO users(login, full_name, role, password_hash, active, created_at) VALUES (?, ?, ?, ?, 1, ?)",
                    (login, full_name, role, hash_password(raw_pwd), now),
                )
        conn.commit()


def authenticate_user(login: str, password: str, db_path: Path = database.DB_PATH) -> dict[str, Any] | None:
    init_security_tables(db_path)
    clean_login = (login or "").strip().lower()
    with _connect(db_path) as conn:
        row = conn.execute(
            "SELECT id, login, full_name, role, password_hash, active FROM users WHERE lower(login)=?",
            (clean_login,),
        ).fetchone()
        if not row or not row["active"]:
            return None
        if not verify_password(password or "", row["password_hash"]):
            return None
        token = secrets.token_urlsafe(32)
        now = datetime.datetime.now()
        exp = (now + datetime.timedelta(days=SESSION_TTL_DAYS)).strftime("%Y-%m-%d %H:%M:%S")
        conn.execute(
            "INSERT INTO sessions(token, user_id, login, role, full_name, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (token, row["id"], row["login"], row["role"], row["full_name"], exp, now.strftime("%Y-%m-%d %H:%M:%S")),
        )
        conn.commit()
        return {
            "token": token,
            "user_id": row["id"],
            "login": row["login"],
            "role": row["role"],
            "full_name": row["full_name"],
            "expires_at": exp,
        }


def get_session(token: str | None, db_path: Path = database.DB_PATH) -> dict[str, Any] | None:
    if not token:
        return None
    init_security_tables(db_path)
    with _connect(db_path) as conn:
        row = conn.execute(
            "SELECT token, user_id, login, role, full_name, expires_at FROM sessions WHERE token=?",
            (token,),
        ).fetchone()
        if not row:
            return None
        if row["expires_at"] < _now_iso():
            conn.execute("DELETE FROM sessions WHERE token=?", (token,))
            conn.commit()
            return None
        u = conn.execute("SELECT active, role, full_name FROM users WHERE id=?", (row["user_id"],)).fetchone()
        if not u or not u["active"]:
            return None
        return {
            "token": row["token"],
            "user_id": row["user_id"],
            "login": row["login"],
            "role": u["role"],
            "full_name": u["full_name"],
        }


def delete_session(token: str | None, db_path: Path = database.DB_PATH) -> None:
    if not token:
        return
    with _connect(db_path) as conn:
        conn.execute("DELETE FROM sessions WHERE token=?", (token,))
        conn.commit()


def list_users(db_path: Path = database.DB_PATH) -> list[dict[str, Any]]:
    init_security_tables(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT id, login, full_name, role, active, created_at FROM users ORDER BY id"
        ).fetchall()
        return [dict(r) for r in rows]


def create_or_update_user(
    login: str,
    full_name: str,
    role: str,
    password: str | None = None,
    active: bool = True,
    db_path: Path = database.DB_PATH,
) -> dict[str, Any]:
    init_security_tables(db_path)
    clean_login = re.sub(r"[^a-zA-Z0-9_.-]", "", (login or "").strip().lower())
    if len(clean_login) < 2:
        raise ValueError("Логин должен содержать минимум 2 латинских символа или цифры.")
    if role not in ROLES:
        raise ValueError("Недопустимая роль пользователя.")
    with _connect(db_path) as conn:
        existing = conn.execute("SELECT id, password_hash FROM users WHERE login=?", (clean_login,)).fetchone()
        if existing:
            pwd_hash = hash_password(password) if (password and password.strip()) else existing["password_hash"]
            conn.execute(
                "UPDATE users SET full_name=?, role=?, password_hash=?, active=? WHERE id=?",
                (full_name.strip() or clean_login, role, pwd_hash, 1 if active else 0, existing["id"]),
            )
        else:
            if not password or len(password.strip()) < 4:
                raise ValueError("Для нового пользователя задайте пароль длиной от 4 символов.")
            conn.execute(
                "INSERT INTO users(login, full_name, role, password_hash, active, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (clean_login, full_name.strip() or clean_login, role, hash_password(password.strip()), 1 if active else 0, _now_iso()),
            )
        conn.commit()
    return {"login": clean_login, "full_name": full_name.strip() or clean_login, "role": role, "active": active}


def delete_user(login: str, db_path: Path = database.DB_PATH) -> None:
    clean_login = (login or "").strip().lower()
    with _connect(db_path) as conn:
        admins = conn.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1 AND login!=?", (clean_login,)).fetchone()[0]
        if admins < 1:
            raise ValueError("Нельзя удалить последнего активного администратора.")
        conn.execute("DELETE FROM sessions WHERE login=?", (clean_login,))
        conn.execute("DELETE FROM users WHERE login=?", (clean_login,))
        conn.commit()


def log_audit(
    user_login: str,
    user_role: str,
    action: str,
    entity: str,
    details: str = "",
    ip: str = "",
    db_path: Path = database.DB_PATH,
) -> None:
    init_security_tables(db_path)
    with _connect(db_path) as conn:
        conn.execute(
            "INSERT INTO audit_log(ts, user_login, user_role, action, entity, details, ip) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (_now_iso(), user_login, user_role, action, entity, details[:500], ip[:64]),
        )
        conn.commit()


def list_audit(limit: int = 120, db_path: Path = database.DB_PATH) -> list[dict[str, Any]]:
    init_security_tables(db_path)
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT id, ts, user_login, user_role, action, entity, details, ip FROM audit_log ORDER BY id DESC LIMIT ?",
            (max(1, min(limit, 500)),),
        ).fetchall()
        return [dict(r) for r in rows]


def sanitize_filename(filename: str) -> str:
    base = os.path.basename(filename or "file").strip()
    clean = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", base)
    return clean or "file"


def validate_upload(filename: str, content: bytes, kind: str) -> str:
    """Проверяет размер, расширение и магические байты загружаемого файла."""
    clean_name = sanitize_filename(filename)
    ext = Path(clean_name).suffix.lower()

    if not content:
        raise ValueError("Загруженный файл пуст.")

    if kind == "scan":
        if len(content) > MAX_SCAN_BYTES:
            raise ValueError("Размер скана превышает 20 МБ.")
        allowed = {".pdf", ".jpg", ".jpeg", ".png", ".webp"}
        if ext not in allowed:
            raise ValueError("Разрешены только файлы PDF, JPG, PNG, WEBP.")
        if ext == ".pdf" and not content.startswith(b"%PDF-"):
            raise ValueError("Файл не является корректным PDF (ошибка сигнатуры).")
        if ext == ".png" and not content.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("Файл не является корректным PNG (ошибка сигнатуры).")
        if ext in (".jpg", ".jpeg") and not content.startswith(b"\xff\xd8\xff"):
            raise ValueError("Файл не является корректным JPEG (ошибка сигнатуры).")
        if ext == ".webp" and not (content[:4] == b"RIFF" and content[8:12] == b"WEBP"):
            raise ValueError("Файл не является корректным WEBP (ошибка сигнатуры).")
    elif kind == "xlsx":
        if len(content) > MAX_TABLE_BYTES:
            raise ValueError("Размер таблицы превышает 10 МБ.")
        if ext != ".xlsx":
            raise ValueError("Разрешены только файлы .xlsx.")
        if not content.startswith(b"PK\x03\x04"):
            raise ValueError("Файл .xlsx повреждён или имеет неверную сигнатуру.")
    elif kind == "measurements":
        if len(content) > MAX_TABLE_BYTES:
            raise ValueError("Размер файла замеров превышает 10 МБ.")
        if ext not in (".xlsx", ".csv"):
            raise ValueError("Разрешены только файлы .xlsx и .csv.")
        if ext == ".xlsx" and not content.startswith(b"PK\x03\x04"):
            raise ValueError("Файл .xlsx повреждён или имеет неверную сигнатуру.")
        if ext == ".csv" and b"\x00" in content[:4096]:
            raise ValueError("Файл .csv содержит недопустимые бинарные байты.")
    elif kind == "backup":
        if len(content) > MAX_BACKUP_BYTES:
            raise ValueError("Размер резервной копии превышает 100 МБ.")
        if ext != ".zip" or not content.startswith(b"PK\x03\x04"):
            raise ValueError("Резервная копия должна быть корректным ZIP-архивом.")
    return clean_name


def create_backup_zip(db_path: Path = database.DB_PATH, uploads_dir: Path = database.UPLOADS_DIR) -> bytes:
    """Создаёт согласованную резервную копию SQLite БД + всех сканов uploads/."""
    with tempfile.TemporaryDirectory() as td:
        tmp_db = Path(td) / "etl_base.db"
        src_conn = sqlite3.connect(str(db_path))
        dst_conn = sqlite3.connect(str(tmp_db))
        try:
            src_conn.backup(dst_conn)
        finally:
            dst_conn.close()
            src_conn.close()

        buf = io.BytesIO()
        uploads_count = 0
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(tmp_db, "etl_base.db")
            if uploads_dir.exists():
                for fp in sorted(uploads_dir.rglob("*")):
                    if fp.is_file():
                        rel = fp.relative_to(uploads_dir).as_posix()
                        zf.write(fp, f"uploads/{rel}")
                        uploads_count += 1
            manifest = {
                "created_at": _now_iso(),
                "db_bytes": tmp_db.stat().st_size,
                "uploads_count": uploads_count,
            }
            zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        return buf.getvalue()


def restore_backup_zip(
    zip_bytes: bytes,
    db_path: Path = database.DB_PATH,
    uploads_dir: Path = database.UPLOADS_DIR,
) -> dict[str, Any]:
    """Проверяет ZIP-бэкап, делает страховочный снимок текущей БД и восстанавливает систему."""
    validate_upload("backup.zip", zip_bytes, "backup")
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
            names = zf.namelist()
            if "etl_base.db" not in names:
                raise ValueError("В архиве отсутствует файл базы данных etl_base.db.")
            for name in names:
                if name.startswith("/") or ".." in Path(name).parts:
                    raise ValueError(f"Небезопасный путь в архиве: {name}")
            zf.extractall(td_path)

        cand_db = td_path / "etl_base.db"
        conn = sqlite3.connect(str(cand_db))
        try:
            ic = conn.execute("PRAGMA integrity_check").fetchone()[0]
            if ic != "ok":
                raise ValueError(f"База в архиве повреждена: {ic}")
            tbls = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            if "app_state" not in tbls or "equipment" not in tbls:
                raise ValueError("База в архиве не принадлежит АРМ ЭТЛ.")
        finally:
            conn.close()

        # Страховочный бэкап перед заменой
        if db_path.exists():
            backups_dir = db_path.parent / "backups"
            backups_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            (backups_dir / f"pre_restore_{stamp}.zip").write_bytes(create_backup_zip(db_path, uploads_dir))

        # Замена БД через sqlite3.backup (безопасно при открытых соединениях)
        src_conn = sqlite3.connect(str(cand_db))
        dst_conn = sqlite3.connect(str(db_path))
        try:
            src_conn.backup(dst_conn)
        finally:
            dst_conn.close()
            src_conn.close()

        # Восстановление uploads/
        cand_uploads = td_path / "uploads"
        uploads_restored = 0
        uploads_dir.mkdir(parents=True, exist_ok=True)
        if cand_uploads.exists():
            for fp in cand_uploads.rglob("*"):
                if fp.is_file():
                    rel = fp.relative_to(cand_uploads)
                    dest = uploads_dir / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(fp, dest)
                    uploads_restored += 1

        init_security_tables(db_path)
        return {"status": "ok", "uploads_restored": uploads_restored}
