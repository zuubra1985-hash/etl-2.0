"""Веб-сервер АРМ ЭТЛ ООО «Сургут перевалка» (FastAPI + SQLite + python-docx).

Поддерживает:
- Полный офлайн-режим (static/app.css, static/icons.js, static/charts.js)
- Доступ с телефона по Wi-Fi / Tailscale (bind 0.0.0.0:8080)
- Живую синхронизацию в реальном времени между телефоном и ноутбуком (SSE /api/events)
"""

from __future__ import annotations

import asyncio
import datetime
import json
import os
import socket
import sys
import threading
import webbrowser
from pathlib import Path
from typing import Any
from urllib.parse import quote

import uvicorn
from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

import database
import docx_generator
import mvi_catalog
import security


def _bundle_dir() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent


TEMPLATE_HTML = _bundle_dir() / "templates" / "index.html"
STATIC_DIR = _bundle_dir() / "static"

app = FastAPI(title="АРМ ЭТЛ — ООО «Сургут перевалка»")
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# ==================== ЖИВАЯ СИНХРОНИЗАЦИЯ (SSE PUB/SUB) ====================

_SYNC_REV = 1
_SUBSCRIBERS: set[asyncio.Queue[str]] = set()


def _notify_sync(scope: str, request: Request | None = None) -> int:
    global _SYNC_REV
    _SYNC_REV += 1
    client_id = request.headers.get("x-client-id", "") if request else ""
    payload = json.dumps({"rev": _SYNC_REV, "scope": scope, "clientId": client_id}, ensure_ascii=False)
    for q in list(_SUBSCRIBERS):
        try:
            q.put_nowait(payload)
        except Exception:
            pass
    return _SYNC_REV


def _detect_local_ips() -> list[str]:
    ips: list[str] = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            ips.append(ip)
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip and not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except Exception:
        pass
    return ips


@app.on_event("startup")
def on_startup() -> None:
    database.init_db()
    import unified_passports as _up
    _up.init_unified_passport_tables()
    _up.seed_motors_into_arm_db()
    security.init_security_tables()


@app.get("/", response_class=HTMLResponse)
def index() -> HTMLResponse:
    return HTMLResponse(TEMPLATE_HTML.read_text(encoding="utf-8"))


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else ""


def _get_arm_api_token() -> str:
    env_t = os.environ.get("ARM_ETL_TOKEN", "").strip()
    if env_t:
        return env_t
    tf = _bundle_dir() / "configuration" / ".arm_token"
    if not tf.exists():
        tf.parent.mkdir(parents=True, exist_ok=True)
        import secrets as _sec
        tf.write_text(_sec.token_hex(16), encoding="utf-8")
    return tf.read_text(encoding="utf-8").strip()


def _current_user(request: Request) -> dict[str, Any] | None:
    hdr_tok = (request.headers.get("x-arm-etl-token") or "").strip()
    if hdr_tok:
        import hmac as _hmac
        if _hmac.compare_digest(hdr_tok, _get_arm_api_token()):
            return {"login": "android_sync", "full_name": "Android APK", "role": "admin"}
    token = request.cookies.get(security.SESSION_COOKIE)
    return security.get_session(token)


def _require_role(request: Request, allowed: tuple[str, ...]) -> dict[str, Any]:
    user = _current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Требуется авторизация (войдите в систему).")
    if user["role"] not in allowed:
        raise HTTPException(status_code=403, detail="Недостаточно прав для выполнения этой операции.")
    return user


@app.get("/api/auth/me")
def api_auth_me(request: Request) -> dict[str, Any]:
    user = _current_user(request)
    if not user:
        return {"authenticated": False, "user": None, "roles": security.ROLES}
    return {
        "authenticated": True,
        "user": {
            "login": user["login"],
            "role": user["role"],
            "role_label": security.ROLES.get(user["role"], user["role"]),
            "full_name": user["full_name"],
        },
        "roles": security.ROLES,
    }


@app.post("/api/auth/login")
async def api_auth_login(request: Request) -> JSONResponse:
    body: dict[str, Any] = await request.json()
    sess = security.authenticate_user(body.get("login", ""), body.get("password", ""))
    if not sess:
        security.log_audit(str(body.get("login") or "?"), "anon", "LOGIN_FAIL", "auth", "Неверный логин или пароль", _client_ip(request))
        raise HTTPException(status_code=401, detail="Неверный логин или пароль (либо учётная запись отключена).")
    security.log_audit(sess["login"], sess["role"], "LOGIN", "auth", "Вход в систему", _client_ip(request))
    resp = JSONResponse({
        "status": "ok",
        "user": {
            "login": sess["login"],
            "role": sess["role"],
            "role_label": security.ROLES.get(sess["role"], sess["role"]),
            "full_name": sess["full_name"],
        },
    })
    resp.set_cookie(
        key=security.SESSION_COOKIE,
        value=sess["token"],
        httponly=True,
        samesite="lax",
        max_age=security.SESSION_TTL_DAYS * 86400,
    )
    return resp


@app.post("/api/auth/logout")
def api_auth_logout(request: Request) -> JSONResponse:
    user = _current_user(request)
    token = request.cookies.get(security.SESSION_COOKIE)
    if user:
        security.log_audit(user["login"], user["role"], "LOGOUT", "auth", "Выход из системы", _client_ip(request))
    security.delete_session(token)
    resp = JSONResponse({"status": "ok"})
    resp.delete_cookie(security.SESSION_COOKIE)
    return resp


@app.get("/api/users")
def api_list_users(request: Request) -> dict[str, Any]:
    _require_role(request, ("admin",))
    return {"users": security.list_users(), "roles": security.ROLES}


@app.post("/api/users")
async def api_save_user(request: Request) -> dict[str, Any]:
    actor = _require_role(request, ("admin",))
    body: dict[str, Any] = await request.json()
    try:
        u = security.create_or_update_user(
            login=body.get("login", ""),
            full_name=body.get("full_name", ""),
            role=body.get("role", "engineer"),
            password=body.get("password"),
            active=bool(body.get("active", True)),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    security.log_audit(actor["login"], actor["role"], "USER_SAVE", u["login"], f"Роль: {u['role']}, активен: {u['active']}", _client_ip(request))
    return {"status": "ok", "user": u}


@app.delete("/api/users/{login}")
def api_delete_user(login: str, request: Request) -> dict[str, Any]:
    actor = _require_role(request, ("admin",))
    if login.lower() == actor["login"].lower():
        raise HTTPException(status_code=400, detail="Нельзя удалить собственную активную учётную запись.")
    try:
        security.delete_user(login)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    security.log_audit(actor["login"], actor["role"], "USER_DELETE", login, "Удалена учётная запись", _client_ip(request))
    return {"status": "ok"}


@app.get("/api/audit")
def api_audit(request: Request, limit: int = Query(default=120, ge=1, le=500)) -> dict[str, Any]:
    _require_role(request, ("admin", "engineer"))
    return {"items": security.list_audit(limit=limit)}


@app.get("/api/backup")
@app.get("/api/backup/download")
def api_backup_download(request: Request) -> Response:
    actor = _require_role(request, ("admin", "engineer"))
    data = security.create_backup_zip()
    stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M")
    fname = f"ARM_ETL_Backup_{stamp}.zip"
    security.log_audit(actor["login"], actor["role"], "BACKUP_DOWNLOAD", fname, f"Размер {len(data)} байт", _client_ip(request))
    return Response(
        content=data,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.post("/api/backup/restore")
async def api_backup_restore(request: Request, file: UploadFile = File(...)) -> dict[str, Any]:
    actor = _require_role(request, ("admin",))
    content = await file.read()
    try:
        res = security.restore_backup_zip(content)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Ошибка восстановления резервной копии: {exc}") from exc
    security.log_audit(actor["login"], actor["role"], "BACKUP_RESTORE", file.filename or "backup.zip", f"Восстановлено сканов: {res.get('uploads_restored', 0)}", _client_ip(request))
    rev = _notify_sync("all", request)
    return {**res, "rev": rev}


@app.get("/api/network-info")
def api_network_info() -> JSONResponse:
    ips = _detect_local_ips()
    urls = [f"http://{ip}:8080" for ip in ips]
    return JSONResponse({"ips": ips, "urls": urls, "port": 8080, "rev": _SYNC_REV})


@app.get("/api/version")
def api_version() -> JSONResponse:
    return JSONResponse({"rev": _SYNC_REV})


@app.get("/api/events")
async def api_events(request: Request) -> StreamingResponse:
    queue: asyncio.Queue[str] = asyncio.Queue(maxsize=64)
    _SUBSCRIBERS.add(queue)

    async def event_stream():
        try:
            yield f"data: {json.dumps({'rev': _SYNC_REV, 'scope': 'hello'})}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    msg = await asyncio.wait_for(queue.get(), timeout=20.0)
                    yield f"data: {msg}\n\n"
                except asyncio.TimeoutError:
                    yield ": ping\n\n"
        finally:
            _SUBSCRIBERS.discard(queue)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


# ==================== СОСТОЯНИЕ СИ / СИЗ / ПРОТОКОЛЫ ====================


@app.get("/api/state")
def api_get_state(response: Response) -> JSONResponse:
    return JSONResponse(database.load_state(), headers={"ETag": f'"{_SYNC_REV}"'})


@app.post("/api/state")
async def api_save_state(request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    payload: dict[str, Any] = await request.json()
    database.save_state(payload)
    try:
        from application.server.modules.equipment.arm_etl_sync import sync_arm_etl_protocols_to_etl2_passports
        sync_arm_etl_protocols_to_etl2_passports(payload.get("protocols") or [])
    except Exception:
        pass
    security.log_audit(actor["login"], actor["role"], "STATE_SAVE", "app_state", f"Протоколов: {len(payload.get('protocols') or [])}", _client_ip(request))
    rev = _notify_sync("state", request)
    return JSONResponse({"status": "ok", "rev": rev})


@app.post("/api/reset")
def api_reset_state(request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin",))
    st = database.reset_state()
    security.log_audit(actor["login"], actor["role"], "DB_RESET", "app_state", "Сброс к заводским настройкам", _client_ip(request))
    _notify_sync("state", request)
    return JSONResponse(st)


# ==================== ОБЪЕКТЫ И ГРАФИК ППР (ЭТАП 2) ====================


@app.get("/api/objects")
def api_get_objects() -> JSONResponse:
    return JSONResponse(database.list_objects_summary())


@app.get("/api/ppr/calendar")
def api_get_ppr_calendar() -> JSONResponse:
    return JSONResponse(database.get_ppr_calendar_summary())


@app.get("/api/equipment")
def api_get_equipment(
    object: str = Query(default=""),
    cat: str = Query(default=""),
    month: int | None = Query(default=None, ge=1, le=12),
    q: str = Query(default=""),
) -> JSONResponse:
    items = database.query_equipment(object_name=object, cat=cat, month=month, q=q)
    return JSONResponse({"items": items, "total": len(items)})


@app.post("/api/equipment/{item_id}/tested")
async def api_mark_equipment_tested(item_id: str, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    body: dict[str, Any] = await request.json() if await request.body() else {}
    security.log_audit(actor["login"], actor["role"], "EQUIP_TESTED", item_id, str(body.get("date") or ""), _client_ip(request))
    date_iso = str(body.get("date") or datetime.date.today().isoformat())
    ok = database.mark_equipment_tested(item_id, date_iso, protocol_no=str(body.get("protocolNo") or ""), protocol_type=str(body.get("protocolType") or ""), result=str(body.get("result") or "Соотв."), actor=actor["login"], note=str(body.get("note") or ""))
    if not ok:
        raise HTTPException(status_code=404, detail="Оборудование не найдено")
    try:
        from application.server.modules.equipment.arm_etl_sync import sync_arm_etl_tested_date_to_etl2_passport
        sync_arm_etl_tested_date_to_etl2_passport(item_id, date_iso)
    except Exception:
        pass
    rev = _notify_sync("equipment", request)
    return JSONResponse({"status": "ok", "id": item_id, "lastDate": date_iso, "rev": rev})


@app.post("/api/objects/tested")
async def api_mark_object_tested(request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    body: dict[str, Any] = await request.json()
    security.log_audit(actor["login"], actor["role"], "OBJ_TESTED", str(body.get("object") or ""), str(body.get("date") or ""), _client_ip(request))
    obj_name = str(body.get("object") or "").strip()
    if not obj_name:
        raise HTTPException(status_code=400, detail="Не указан объект")
    date_iso = str(body.get("date") or datetime.date.today().isoformat())
    updated = database.mark_object_tested(obj_name, date_iso, protocol_no=str(body.get("protocolNo") or ""), result=str(body.get("result") or "Соотв."), actor=actor["login"], note=str(body.get("note") or ""))
    rev = _notify_sync("equipment", request)
    return JSONResponse({"status": "ok", "object": obj_name, "updated": updated, "lastDate": date_iso, "rev": rev})


@app.post("/api/equipment/import-xlsx")
async def api_import_schedule_xlsx(request: Request, file: UploadFile = File(...)) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    content = await file.read()
    try:
        clean_name = security.validate_upload(file.filename or "schedule.xlsx", content, "xlsx")
        stats = database.replace_equipment_from_xlsx(content)
        security.log_audit(actor["login"], actor["role"], "SCHEDULE_IMPORT", clean_name, f"Объектов: {stats.get('objects', '?')}", _client_ip(request))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Ошибка разбора графика: {exc}") from exc
    rev = _notify_sync("equipment", request)
    return JSONResponse({"status": "ok", "rev": rev, **stats})


# ==================== ПЕРСОНАЛ, НАРЯДЫ-ДОПУСКИ И РОСТЕХНАДЗОР (ЭТАП 3) ====================



@app.get("/api/equipment/{item_id}/history")
def api_equipment_history(item_id: str) -> JSONResponse:
    return JSONResponse(database.list_equipment_history(item_id))


@app.get("/api/archive/tests")
def api_tests_archive(
    q: str = Query(default=""),
    object: str = Query(default=""),
    result: str = Query(default=""),
) -> JSONResponse:
    return JSONResponse(database.list_tests_archive(q=q, object_name=object, result_filter=result))


@app.get("/api/personnel/check")
def api_check_personnel(
    fios: str = Query(default=""),
    date: str = Query(default=""),
    hv: bool = Query(default=False),
) -> JSONResponse:
    fio_list = [x.strip() for x in fios.split("|") if x.strip()]
    return JSONResponse(database.check_personnel_clearance(fio_list, ref_date=date, require_hv=hv))


@app.get("/api/personnel")
def api_list_personnel() -> JSONResponse:
    return JSONResponse({"items": database.list_personnel()})


@app.post("/api/personnel")
async def api_upsert_personnel(request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    body: dict[str, Any] = await request.json()
    if not str(body.get("fio") or "").strip():
        raise HTTPException(status_code=400, detail="Укажите ФИО сотрудника")
    res = database.upsert_personnel(body)
    security.log_audit(actor["login"], actor["role"], "PERSON_SAVE", str(body.get("fio") or ""), f"Группа {body.get('groupEb', '')}", _client_ip(request))
    res["rev"] = _notify_sync("staff", request)
    return JSONResponse(res)


@app.delete("/api/personnel/{pid}")
def api_delete_personnel(pid: str, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    ok = database.delete_personnel(pid)
    if ok:
        security.log_audit(actor["login"], actor["role"], "PERSON_DELETE", pid, "", _client_ip(request))
    if not ok:
        raise HTTPException(status_code=404, detail="Сотрудник не найден")
    rev = _notify_sync("staff", request)
    return JSONResponse({"status": "ok", "rev": rev})


@app.get("/api/permits")
def api_list_permits() -> JSONResponse:
    return JSONResponse({"items": database.list_work_permits()})


@app.post("/api/permits")
async def api_save_permit(request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    body: dict[str, Any] = await request.json()
    saved = database.save_work_permit(body)
    security.log_audit(actor["login"], actor["role"], "PERMIT_SAVE", str(body.get("number") or ""), str(body.get("workPlace") or ""), _client_ip(request))
    saved["rev"] = _notify_sync("staff", request)
    return JSONResponse(saved)


@app.delete("/api/permits/{pid}")
def api_delete_permit(pid: str, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    ok = database.delete_work_permit(pid)
    if ok:
        security.log_audit(actor["login"], actor["role"], "PERMIT_DELETE", pid, "", _client_ip(request))
    if not ok:
        raise HTTPException(status_code=404, detail="Наряд-допуск не найден")
    rev = _notify_sync("staff", request)
    return JSONResponse({"status": "ok", "rev": rev})


@app.post("/api/permits/docx")
async def api_export_permit_docx(request: Request) -> Response:
    permit: dict[str, Any] = await request.json()
    data = docx_generator.generate_work_permit_docx(permit)
    num = str(permit.get("number") or "1").replace("/", "_")
    fname = f"Naryad_dopusk_{num}.docx"
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.get("/api/rostech")
def api_list_rostech() -> JSONResponse:
    return JSONResponse({"items": database.list_rostech_checklist()})


@app.post("/api/rostech/{item_id}")
async def api_update_rostech(item_id: str, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    body: dict[str, Any] = await request.json()
    security.log_audit(actor["login"], actor["role"], "ROSTECH_UPDATE", item_id, "Выполнено" if body.get("done") else "Снято", _client_ip(request))
    ok = database.update_rostech_item(item_id, bool(body.get("done")), str(body.get("note") or ""))
    if not ok:
        raise HTTPException(status_code=404, detail="Пункт чек-листа не найден")
    rev = _notify_sync("staff", request)
    return JSONResponse({"status": "ok", "rev": rev})


# ==================== АРХИВ СКАНОВ (PDF / ИЗОБРАЖЕНИЯ ДЛЯ СИ И СИЗ) ====================


@app.get("/api/attachments")
def api_list_attachments(entity_id: str = Query(default="")) -> JSONResponse:
    return JSONResponse({"items": database.list_attachments(entity_id)})


@app.post("/api/attachments/{entity_id}")
async def api_upload_attachment(entity_id: str, request: Request, file: UploadFile = File(...)) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    content = await file.read()
    try:
        clean_name = security.validate_upload(file.filename or "scan.pdf", content, "scan")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    saved = database.save_attachment(entity_id, clean_name, file.content_type or "application/octet-stream", content)
    security.log_audit(actor["login"], actor["role"], "SCAN_UPLOAD", entity_id, clean_name, _client_ip(request))
    rev = _notify_sync("attachments", request)
    return JSONResponse({"status": "ok", "attachment": saved, "rev": rev})


@app.get("/api/attachments/file/{att_id}")
def api_download_attachment(att_id: str) -> Response:
    found = database.get_attachment(att_id)
    if not found:
        raise HTTPException(status_code=404, detail="Файл не найден")
    meta, content = found
    return Response(
        content=content,
        media_type=meta.get("mimeType") or "application/octet-stream",
        headers={"Content-Disposition": f"inline; filename*=UTF-8''{quote(meta['filename'])}"},
    )


@app.delete("/api/attachments/{att_id}")
def api_delete_attachment(att_id: str, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    ok = database.delete_attachment(att_id)
    if ok:
        security.log_audit(actor["login"], actor["role"], "SCAN_DELETE", att_id, "", _client_ip(request))
    if not ok:
        raise HTTPException(status_code=404, detail="Файл не найден")
    rev = _notify_sync("attachments", request)
    return JSONResponse({"status": "ok", "rev": rev})


# ==================== ИМПОРТ ЗАМЕРОВ EXCEL / CSV В ПРИЛОЖЕНИЕ №2 ====================


@app.get("/api/methods")
def api_methods() -> dict[str, Any]:
    return {
        "methods": mvi_catalog.MVI_CATALOG,
        "climate_limits": mvi_catalog.CLIMATE_LIMITS,
        "section7_rule": mvi_catalog.SECTION7_RULE,
        "seasonal_soil_coeffs": mvi_catalog.SEASONAL_SOIL_COEFFS,
    }


@app.get("/api/protocols/template-xlsx")
def api_protocol_template_xlsx(proto_type: str = Query(default="breaker_3p")) -> Response:
    data = database.generate_protocol_template_xlsx(proto_type)
    fname = f"Shablon_{proto_type}.xlsx"
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.post("/api/protocols/import-rows")
async def api_import_protocol_rows(
    request: Request,
    proto_type: str = Query(default="breaker_3p"),
    file: UploadFile = File(...),
) -> JSONResponse:
    _require_role(request, ("admin", "engineer"))
    content = await file.read()
    try:
        security.validate_upload(file.filename or "rows.xlsx", content, "measurements")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    try:
        parsed = database.parse_measurements_file_detailed(proto_type, file.filename, content)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Ошибка импорта замеров: {exc}") from exc
    return JSONResponse({"status": "ok", **parsed})


# ==================== ЭКСПОРТ DOCX (ПРОТОКОЛ И ТЕХНИЧЕСКИЙ ОТЧЁТ) ====================


@app.post("/api/export/protocol-docx")
async def api_export_protocol_docx(request: Request) -> Response:
    body: dict[str, Any] = await request.json()
    proto = body.get("protocol", body)
    use_footer = bool(body.get("useWordFooter", False))
    st = database.load_state()
    by_id = {x["id"]: x for x in st.get("si", [])}
    devs = [by_id[k] for k in (proto.get("instrumentId"), proto.get("instrumentId2")) if k and k in by_id]
    data = docx_generator.generate_protocol_docx(proto, devs, start_page=1, use_word_footer=use_footer)
    fname = f"Protokol_{proto.get('number', '1')}.docx"
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


@app.post("/api/export/report-docx")
async def api_export_report_docx(request: Request) -> Response:
    body: dict[str, Any] = await request.json()
    report_meta = body.get("reportMeta", {})
    protocols = body.get("protocols", [])
    manual_defects = body.get("manualDefects", [])
    use_footer = bool(body.get("useWordFooter", False))
    st = database.load_state()
    by_id = {x["id"]: x for x in st.get("si", [])}
    data = docx_generator.generate_report_docx(
        report_meta, protocols, by_id, manual_defects, use_word_footer=use_footer
    )
    fname = f"Tehnicheskiy_otchet_{report_meta.get('number', '16')}.docx"
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(fname)}"},
    )


def _open_browser_later(url: str) -> None:
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()




# ==================== ИНТЕГРАЦИЯ МОДУЛЕЙ ETL 2.0 (ПАСПОРТА, QR, 230 ЭД, СИ, МВИ) ====================
from fastapi.responses import RedirectResponse as _ETL2RedirectResponse

# ==================== ЕДИНЫЙ МОДУЛЬ ПАСПОРТОВ И QR (АРМ ЭТЛ v3.0) ====================
import unified_passports as _up
from fastapi.responses import RedirectResponse as _RedirectResponse

_QR_MOBILE_HTML = _bundle_dir() / "templates" / "qr_mobile.html"


@app.get("/api/unified/passport/{equipment_id}")
async def api_unified_get_passport(equipment_id: str, request: Request) -> JSONResponse:
    _require_role(request, ("admin", "engineer", "viewer"))
    try:
        return JSONResponse(_up.get_full_passport_payload(equipment_id))
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.post("/api/unified/passport/{equipment_id}")
async def api_unified_save_passport(equipment_id: str, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    body: dict[str, Any] = await request.json()
    try:
        res = _up.save_passport_fields(equipment_id, body, actor=actor["login"])
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    security.log_audit(actor["login"], actor["role"], "PASSPORT_SAVE", equipment_id, str(body.get("change_reason") or "Обновление паспорта"), _client_ip(request))
    _notify_sync("equipment", request)
    return JSONResponse(res)


@app.post("/api/unified/passport/{equipment_id}/journal")
async def api_unified_add_journal(equipment_id: str, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    body: dict[str, Any] = await request.json()
    try:
        entry_id = _up.add_journal_entry(
            equipment_id,
            section=str(body.get("section") or ""),
            event_date=str(body.get("event_date") or datetime.date.today().isoformat()),
            col1=str(body.get("col1") or ""),
            col2=str(body.get("col2") or ""),
            col3=str(body.get("col3") or ""),
            col4=str(body.get("col4") or ""),
            col5=str(body.get("col5") or ""),
            actor=actor["login"],
        )
    except (KeyError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    security.log_audit(actor["login"], actor["role"], "PASSPORT_JOURNAL_ADD", equipment_id, str(body.get("section") or ""), _client_ip(request))
    return JSONResponse({"status": "ok", "id": entry_id})


@app.delete("/api/unified/passport/{equipment_id}/journal/{entry_id}")
async def api_unified_del_journal(equipment_id: str, entry_id: int, request: Request) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    ok = _up.delete_journal_entry(equipment_id, entry_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Запись не найдена")
    security.log_audit(actor["login"], actor["role"], "PASSPORT_JOURNAL_DEL", equipment_id, str(entry_id), _client_ip(request))
    return JSONResponse({"status": "ok"})


@app.post("/api/unified/passport/{equipment_id}/original")
async def api_unified_upload_original(equipment_id: str, request: Request, file: UploadFile = File(...)) -> JSONResponse:
    actor = _require_role(request, ("admin", "engineer"))
    content = await file.read()
    try:
        res = _up.save_original_passport_file(equipment_id, file.filename or "passport.pdf", content)
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    security.log_audit(actor["login"], actor["role"], "PASSPORT_ORIG_UPLOAD", equipment_id, file.filename or "", _client_ip(request))
    return JSONResponse(res)


@app.get("/api/unified/passport/{equipment_id}/original")
async def api_unified_download_original(equipment_id: str, request: Request) -> Response:
    _require_role(request, ("admin", "engineer", "viewer"))
    import sqlite3
    with sqlite3.connect(database.DB_PATH) as conn:
        row = conn.execute("SELECT original_file_path, original_filename FROM equipment_passports WHERE equipment_id = ?", (equipment_id,)).fetchone()
    if not row or not row[0] or not Path(row[0]).exists():
        raise HTTPException(status_code=404, detail="Оригинал паспорта не загружен")
    fname = row[1] or Path(row[0]).name
    disp = f"attachment; filename*=UTF-8''{quote(fname)}"
    return Response(content=Path(row[0]).read_bytes(), media_type="application/octet-stream", headers={"Content-Disposition": disp})


@app.get("/api/unified/passport/{equipment_id}/export")
async def api_unified_export_passport(equipment_id: str, request: Request, format: str = Query("docx")) -> Response:
    _require_role(request, ("admin", "engineer", "viewer"))
    try:
        data, fname, media = _up.export_unified_passport(equipment_id, fmt=format)
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    disp = f"attachment; filename*=UTF-8''{quote(fname)}"
    return Response(content=data, media_type=media, headers={"Content-Disposition": disp})


@app.get("/api/unified/qr/{equipment_id}/image")
async def api_unified_qr_image(equipment_id: str, request: Request, format: str = Query("png")) -> Response:
    _require_role(request, ("admin", "engineer", "viewer"))
    try:
        data, media = _up.get_qr_badge_bytes(equipment_id, fmt=format)
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    fname = f"qr_badge_{equipment_id}.{format.lower()}"
    disp = f"inline; filename*=UTF-8''{quote(fname)}"
    return Response(content=data, media_type=media, headers={"Content-Disposition": disp})


@app.post("/api/unified/qr/print-batch")
async def api_unified_qr_print_batch(request: Request) -> Response:
    actor = _require_role(request, ("admin", "engineer", "viewer"))
    body: dict[str, Any] = await request.json()
    eq_ids = body.get("equipment_ids") or []
    preset = str(body.get("preset") or "a4_3x7")
    try:
        pdf_bytes, fname = _up.print_qr_batch(eq_ids, preset=preset)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    security.log_audit(actor["login"], actor["role"], "QR_PRINT_BATCH", preset, f"Штук: {len(eq_ids)}", _client_ip(request))
    disp = f"attachment; filename*=UTF-8''{quote(fname)}"
    return Response(content=pdf_bytes, media_type="application/pdf", headers={"Content-Disposition": disp})


@app.get("/eq/{qr_token}", response_class=HTMLResponse)
def unified_qr_mobile_page(qr_token: str) -> HTMLResponse:
    eq_id = _up.resolve_equipment_by_qr(qr_token)
    if not eq_id:
        return HTMLResponse("<h3>QR-код не найден в базе АРМ ЭТЛ</h3><p><a href='/'>Открыть АРМ ЭТЛ</a></p>", status_code=404)
    html = _QR_MOBILE_HTML.read_text(encoding="utf-8").replace("__EQUIPMENT_ID_JSON__", json.dumps(eq_id, ensure_ascii=False))
    return HTMLResponse(html)


@app.get("/passports")
def legacy_passports_redirect():
    return _RedirectResponse(url="/", status_code=302)


@app.get("/mobile")
def legacy_mobile_redirect():
    return _RedirectResponse(url="/", status_code=302)
