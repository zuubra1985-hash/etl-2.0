"""Модуль базы данных SQLite для АРМ ЭТЛ ООО «Сургут перевалка»."""

from __future__ import annotations

import datetime
import io
import json
import re
import sqlite3
import sys
from pathlib import Path
from typing import Any


def _runtime_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _bundle_dir() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent


DB_PATH = _runtime_dir() / "etl_base.db"
SEED_PATH = _bundle_dir() / "objects_seed.json"
UPLOADS_DIR = _runtime_dir() / "uploads"

DEFAULT_SI: list[dict[str, Any]] = [
    {"id": "si-1", "name": "Мегаомметр", "model": "ТМ-5001 (Sonel)", "serial": "EG0113", "range": "0 кОм…5 ТОм", "accuracy": "±(3% и.в. + 10 е.м.р.)", "lastCalDate": "", "validUntil": "2028-03-22", "arshinNote": "Поверен до 22.03.2028", "status": "ДОПУЩЕН", "basis": "Собственность ООО"},
    {"id": "si-2", "name": "Вольтамперфазометр", "model": "РЕТОМЕТР-М2", "serial": "4381", "range": "0…500 В; 0…40 А", "accuracy": "по паспорту СИ", "lastCalDate": "", "validUntil": "2028-03-10", "arshinNote": "Поверен до 10.03.2028", "status": "ДОПУЩЕН", "basis": "Собственность ООО"},
    {"id": "si-3", "name": "Устройство испытательное", "model": "РЕТОМ-30кА", "serial": "1300", "range": "0 - 30000 А", "accuracy": "2%", "lastCalDate": "2025-12-10", "validUntil": "2029-12-09", "arshinNote": "Поверен до 09.12.2029", "status": "ДОПУЩЕН", "basis": "Собственность ООО"},
    {"id": "si-4", "name": "Мультиметр", "model": "APPA-138", "serial": "06550060", "range": "0…750 В", "accuracy": "по паспорту СИ", "lastCalDate": "2026-02-16", "validUntil": "2027-02-15", "arshinNote": "Поверен до 15.02.2027", "status": "ДОПУЩЕН", "basis": "Собственность ООО"},
    {"id": "si-5", "name": "Кабелетрассоискатель", "model": "АТЛЕТ АГ-319СКИН", "serial": "178316", "range": "Индикатор", "accuracy": "не подл. поверке", "lastCalDate": "", "validUntil": "", "arshinNote": "Индикатор (не подл. поверке)", "status": "ДОПУЩЕН", "basis": "Собственность ООО"},
    {"id": "si-6", "name": "Микроомметр", "model": "MMR-630", "serial": "323424", "range": "0…999,9 мкОм", "accuracy": "±(0,25%R+2е.м.р.)", "lastCalDate": "2025-10-07", "validUntil": "2026-10-06", "arshinNote": "Истекла 06.10.2026 (в поверке)", "status": "ОБНОВИТЬ АРШИН", "basis": "Собственность ООО"},
    {"id": "si-7", "name": "Измеритель параметров электробезопасности электроустановок", "model": "MPI-530-IT", "serial": "С50355", "range": "0,01 Ом…1999 Ом; петля; УЗО", "accuracy": "±(3% и. в. + 20 е. м. р.)", "lastCalDate": "2025-10-08", "validUntil": "2026-10-07", "arshinNote": "Истекла 07.10.2026 (в поверке)", "status": "ОБНОВИТЬ АРШИН", "basis": "Собственность ООО"},
    {"id": "si-8", "name": "Мегаомметр", "model": "Sonel MIC-10k1", "serial": "EN0231", "range": "0 кОм - 40 ТОм", "accuracy": "±3% и.в. + 10 е.м.р.", "lastCalDate": "2025-10-08", "validUntil": "2026-10-07", "arshinNote": "Истекла 07.10.2026 (в поверке)", "status": "ОБНОВИТЬ АРШИН", "basis": "Собственность ООО"},
    {"id": "si-9", "name": "Установка проверки РЗиА", "model": "УРАН-2 (НПФ «Радиус»)", "serial": "1943", "range": "0…250 В; 0…100 А", "accuracy": "по паспорту СИ", "lastCalDate": "", "validUntil": "2026-09-30", "arshinNote": "Истекла 30.09.2026 (в поверке)", "status": "ОБНОВИТЬ АРШИН", "basis": "Собственность ООО"},
    {"id": "si-10", "name": "Аппарат испытания диэлектриков", "model": "АИД-70Ц", "serial": "1135", "range": "0…70 кВ DC / 0…50 кВ AC", "accuracy": "±3%", "lastCalDate": "", "validUntil": "2026-09-25", "arshinNote": "Истекла 25.09.2026 (в поверке)", "status": "ОБНОВИТЬ АРШИН", "basis": "Собственность ООО"},
    {"id": "si-11", "name": "Комплекс релейной защиты", "model": "РЕТОМ-21", "serial": "2499", "range": "0…500 В; 0…700 А", "accuracy": "по паспорту СИ", "lastCalDate": "", "validUntil": "2026-05-29", "arshinNote": "Истекла 29.05.2026 (в поверке)", "status": "ОБНОВИТЬ АРШИН", "basis": "Собственность ООО"},
    {"id": "si-12", "name": "Виброметр", "model": "VM-82A (RION)", "serial": "31271891", "range": "—", "accuracy": "—", "lastCalDate": "", "validUntil": "2026-01-19", "arshinNote": "Консервация (истекла 19.01.2026)", "status": "ИСКЛЮЧИТЬ", "basis": "Консервация"},
    {"id": "si-13", "name": "Клещи токовые", "model": "APPA A16HR", "serial": "06550060", "range": "—", "accuracy": "—", "lastCalDate": "", "validUntil": "2026-01-16", "arshinNote": "Консервация (истекла 16.01.2026)", "status": "ИСКЛЮЧИТЬ", "basis": "Консервация"},
    {"id": "si-14", "name": "Термогигрометр-барометр", "model": "ИВА-6Н-Д / МЭС-200А", "serial": "—", "range": "t, φ, P", "accuracy": "—", "lastCalDate": "", "validUntil": "", "arshinNote": "ОТСУТСТВУЕТ — докупить с поверкой", "status": "ЗАКУПИТЬ", "basis": "Собственность ООО"},
]

DEFAULT_SIZ: list[dict[str, Any]] = [
    {"id": "siz-1", "name": "Перчатки диэлектрические", "qty": "2 пары", "period": "1 раз в 6 мес.", "protocolNo": "—", "validUntil": ""},
    {"id": "siz-2", "name": "Боты (галоши) диэлектрические", "qty": "1 пара", "period": "1 раз в 36 (12) мес.", "protocolNo": "—", "validUntil": ""},
    {"id": "siz-3", "name": "Указатель напряжения до 1000 В", "qty": "1 шт.", "period": "1 раз в 12 мес.", "protocolNo": "—", "validUntil": ""},
    {"id": "siz-4", "name": "Указатель напряжения 6–10 кВ", "qty": "1 шт.", "period": "1 раз в 12 мес.", "protocolNo": "—", "validUntil": ""},
    {"id": "siz-5", "name": "Штанга изолирующая оперативная до 10 кВ", "qty": "1 шт.", "period": "1 раз в 24 мес.", "protocolNo": "—", "validUntil": ""},
    {"id": "siz-6", "name": "Заземление переносное (ПЗ)", "qty": "2 шт.", "period": "Осмотр 1 раз в 3 мес.", "protocolNo": "—", "validUntil": ""},
    {"id": "siz-7", "name": "Плакаты и ограждения безопасности", "qty": "Комплект", "period": "Осмотр перед примен.", "protocolNo": "—", "validUntil": ""},
]


def default_state() -> dict[str, Any]:
    return {
        "si": json.loads(json.dumps(DEFAULT_SI)),
        "siz": json.loads(json.dumps(DEFAULT_SIZ)),
        "protocols": [],
        "reportSelection": [],
        "manualDefects": [],
    }


def _seed_equipment_if_empty(conn: sqlite3.Connection) -> None:
    count = conn.execute("SELECT COUNT(*) FROM equipment").fetchone()[0]
    if count > 0:
        return
    if not SEED_PATH.exists():
        return
    data = json.loads(SEED_PATH.read_text(encoding="utf-8"))
    objects: list[str] = [o for o in data.get("objects", []) if o and o != "тип, марка, конструкция"]
    items: list[dict[str, Any]] = data.get("items", [])
    _write_equipment_records(conn, objects, items)


def _write_equipment_records(
    conn: sqlite3.Connection,
    objects: list[str],
    items: list[dict[str, Any]],
) -> None:
    conn.execute("DELETE FROM equipment")
    conn.execute("DELETE FROM equipment_objects")
    seen_objs: list[str] = []
    seen_set: set[str] = set()
    for o in objects:
        clean_o = o.strip()
        if clean_o and clean_o not in seen_set:
            seen_set.add(clean_o)
            seen_objs.append(clean_o)
    for it in items:
        obj = str(it.get("object", "")).strip()
        if obj and obj not in seen_set:
            seen_set.add(obj)
            seen_objs.append(obj)

    conn.executemany(
        "INSERT INTO equipment_objects (name, sort_order) VALUES (?, ?)",
        [(o, idx) for idx, o in enumerate(seen_objs)],
    )
    conn.executemany(
        """
        INSERT INTO equipment (id, sort_order, num, object_name, name, power, period, last_date, months_json, cat)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            (
                str(it.get("id") or f"eq-{idx + 1}"),
                idx,
                str(it.get("num") or ""),
                str(it.get("object") or "").strip(),
                str(it.get("name") or "").strip(),
                str(it.get("power") or "").strip(),
                str(it.get("period") or "").strip(),
                str(it.get("lastDate") or "").strip(),
                json.dumps(it.get("months") or [], ensure_ascii=False),
                str(it.get("cat") or "Прочее").strip(),
            )
            for idx, it in enumerate(items)
        ],
    )


def init_db(db_path: Path = DB_PATH) -> None:
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS app_state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                payload TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS equipment_objects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                sort_order INTEGER NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS equipment (
                id TEXT PRIMARY KEY,
                sort_order INTEGER NOT NULL,
                num TEXT DEFAULT '',
                object_name TEXT NOT NULL,
                name TEXT NOT NULL,
                power TEXT DEFAULT '',
                period TEXT DEFAULT '',
                last_date TEXT DEFAULT '',
                months_json TEXT NOT NULL DEFAULT '[]',
                cat TEXT NOT NULL DEFAULT 'Прочее'
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_equipment_object ON equipment(object_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_equipment_cat ON equipment(cat)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS personnel (
                id TEXT PRIMARY KEY,
                fio TEXT NOT NULL,
                position TEXT NOT NULL,
                eb_group TEXT NOT NULL,
                voltage TEXT NOT NULL DEFAULT 'до и выше 1000 В',
                special_rights TEXT DEFAULT '',
                check_date TEXT DEFAULT '',
                valid_until TEXT DEFAULT '',
                cert_no TEXT DEFAULT ''
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS work_permits (
                id TEXT PRIMARY KEY,
                number TEXT NOT NULL,
                issue_date TEXT NOT NULL,
                object_name TEXT DEFAULT '',
                payload TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS rostech_checklist (
                id TEXT PRIMARY KEY,
                sort_order INTEGER NOT NULL,
                title TEXT NOT NULL,
                norm_ref TEXT DEFAULT '',
                done INTEGER NOT NULL DEFAULT 0,
                note TEXT DEFAULT ''
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS attachments (
                id TEXT PRIMARY KEY,
                entity_id TEXT NOT NULL,
                filename TEXT NOT NULL,
                stored_name TEXT NOT NULL,
                mime_type TEXT DEFAULT 'application/octet-stream',
                size_bytes INTEGER DEFAULT 0,
                uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_att_entity ON attachments(entity_id)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS equipment_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                equipment_id TEXT NOT NULL,
                object_name TEXT NOT NULL,
                equipment_name TEXT NOT NULL,
                test_date TEXT NOT NULL,
                protocol_no TEXT DEFAULT '',
                protocol_type TEXT DEFAULT '',
                result TEXT DEFAULT 'Проведено',
                actor TEXT DEFAULT '',
                note TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_eq_hist_id ON equipment_history(equipment_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_eq_hist_date ON equipment_history(test_date DESC)")
        _seed_stage3_if_empty(conn)

        row = conn.execute("SELECT payload FROM app_state WHERE id = 1").fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO app_state (id, payload) VALUES (1, ?)",
                (json.dumps(default_state(), ensure_ascii=False),),
            )
        _seed_equipment_if_empty(conn)
        conn.commit()


def load_state(db_path: Path = DB_PATH) -> dict[str, Any]:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute("SELECT payload FROM app_state WHERE id = 1").fetchone()
        if not row:
            return default_state()
        return json.loads(row[0])


def save_state(state: dict[str, Any], db_path: Path = DB_PATH) -> None:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            UPDATE app_state
            SET payload = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
            """,
            (json.dumps(state, ensure_ascii=False),),
        )
        conn.commit()


def reset_state(db_path: Path = DB_PATH) -> dict[str, Any]:
    st = default_state()
    save_state(st, db_path)
    return st


# ==================== БАЗА ОБЪЕКТОВ И ГРАФИК ППР ====================


def list_objects_summary(db_path: Path = DB_PATH) -> dict[str, Any]:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT o.name,
                   COUNT(e.id) AS total_cnt,
                   SUM(CASE WHEN e.months_json != '[]' THEN 1 ELSE 0 END) AS planned_cnt
            FROM equipment_objects o
            LEFT JOIN equipment e ON e.object_name = o.name
            GROUP BY o.name, o.sort_order
            HAVING total_cnt > 0
            ORDER BY o.sort_order ASC
            """
        ).fetchall()
        cat_rows = conn.execute(
            "SELECT cat, COUNT(*) FROM equipment GROUP BY cat ORDER BY COUNT(*) DESC"
        ).fetchall()

    objects = [
        {"name": r[0], "count": int(r[1] or 0), "plannedCount": int(r[2] or 0)}
        for r in rows
    ]
    total_items = sum(o["count"] for o in objects)
    total_planned = sum(o["plannedCount"] for o in objects)
    categories = [{"name": r[0], "count": int(r[1])} for r in cat_rows]
    return {
        "objects": objects,
        "categories": categories,
        "totalObjects": len(objects),
        "totalItems": total_items,
        "totalPlanned": total_planned,
    }


def query_equipment(
    object_name: str = "",
    cat: str = "",
    month: int | None = None,
    q: str = "",
    db_path: Path = DB_PATH,
) -> list[dict[str, Any]]:
    init_db(db_path)
    sql = """
        SELECT e.id, e.num, e.object_name, e.name, e.power, e.period, e.last_date, e.months_json, e.cat
        FROM equipment e
        LEFT JOIN equipment_objects o ON o.name = e.object_name
        WHERE 1=1
    """
    params: list[Any] = []
    if object_name:
        sql += " AND e.object_name = ?"
        params.append(object_name)
    if cat:
        sql += " AND e.cat = ?"
        params.append(cat)
    sql += " ORDER BY COALESCE(o.sort_order, 9999) ASC, e.sort_order ASC"

    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(sql, params).fetchall()

    q_low = q.strip().lower()
    result: list[dict[str, Any]] = []
    for r in rows:
        months = json.loads(r[7]) if r[7] else []
        if month is not None and month not in months:
            continue
        if q_low:
            hay = f"{r[1]} {r[2]} {r[3]} {r[4]} {r[5]} {r[8]}".lower()
            if q_low not in hay:
                continue
        result.append(
            {
                "id": r[0],
                "num": r[1],
                "object": r[2],
                "name": r[3],
                "power": r[4],
                "period": r[5],
                "lastDate": r[6],
                "months": months,
                "cat": r[8],
            }
        )
    return result


def mark_equipment_tested(
    item_id: str,
    date_iso: str,
    protocol_no: str = "",
    protocol_type: str = "",
    result: str = "Соотв.",
    actor: str = "",
    note: str = "",
    db_path: Path = DB_PATH,
) -> bool:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute("SELECT object_name, name FROM equipment WHERE id = ?", (item_id,)).fetchone()
        if not row:
            return False
        conn.execute("UPDATE equipment SET last_date = ? WHERE id = ?", (date_iso, item_id))
        conn.execute(
            """
            INSERT INTO equipment_history
            (equipment_id, object_name, equipment_name, test_date, protocol_no, protocol_type, result, actor, note)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (item_id, row[0], row[1], date_iso, protocol_no, protocol_type, result, actor, note),
        )
        conn.commit()
        return True


def mark_object_tested(
    object_name: str,
    date_iso: str,
    protocol_no: str = "",
    result: str = "Соотв.",
    actor: str = "",
    note: str = "",
    db_path: Path = DB_PATH,
) -> int:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute("SELECT id, name FROM equipment WHERE object_name = ?", (object_name,)).fetchall()
        cur = conn.execute(
            "UPDATE equipment SET last_date = ? WHERE object_name = ?",
            (date_iso, object_name),
        )
        for eq_id, eq_name in rows:
            conn.execute(
                """
                INSERT INTO equipment_history
                (equipment_id, object_name, equipment_name, test_date, protocol_no, protocol_type, result, actor, note)
                VALUES (?, ?, ?, ?, ?, '', ?, ?, ?)
                """,
                (eq_id, object_name, eq_name, date_iso, protocol_no, result, actor, note),
            )
        conn.commit()
        return cur.rowcount


def list_equipment_history(item_id: str, db_path: Path = DB_PATH) -> dict[str, Any]:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        eq = conn.execute(
            "SELECT id, object_name, name, power, period, last_date, cat FROM equipment WHERE id = ?",
            (item_id,),
        ).fetchone()
        if not eq:
            return {"equipment": None, "history": []}
        rows = conn.execute(
            """
            SELECT id, test_date, protocol_no, protocol_type, result, actor, note, created_at
            FROM equipment_history WHERE equipment_id = ? ORDER BY test_date DESC, id DESC
            """,
            (item_id,),
        ).fetchall()
        return {
            "equipment": {
                "id": eq[0], "object": eq[1], "name": eq[2], "eqType": eq[3],
                "period": eq[4], "lastDate": eq[5], "cat": eq[6],
            },
            "history": [
                {
                    "id": r[0], "testDate": r[1], "protocolNo": r[2], "protocolType": r[3],
                    "result": r[4], "actor": r[5], "note": r[6], "createdAt": r[7],
                }
                for r in rows
            ],
        }


def list_tests_archive(
    q: str = "",
    object_name: str = "",
    result_filter: str = "",
    limit: int = 200,
    db_path: Path = DB_PATH,
) -> dict[str, Any]:
    init_db(db_path)
    st = load_state(db_path)
    protocols = st.get("protocols") or []
    q_low = q.strip().lower()
    obj_low = object_name.strip().lower()

    proto_items: list[dict[str, Any]] = []
    for p in protocols:
        p_obj = str(p.get("object") or "")
        p_num = str(p.get("number") or "")
        p_type = str(p.get("type") or "")
        if obj_low and obj_low not in p_obj.lower():
            continue
        if q_low and q_low not in f"{p_num} {p_obj} {p_type}".lower():
            continue
        proto_items.append({
            "id": p.get("id"),
            "number": p_num,
            "date": p.get("date") or "",
            "object": p_obj,
            "type": p_type,
            "rowsCount": len(p.get("rows") or []),
            "exec1": p.get("exec1") or "",
            "exec2": p.get("exec2") or "",
        })

    with sqlite3.connect(db_path) as conn:
        sql = """
            SELECT id, equipment_id, object_name, equipment_name, test_date, protocol_no, protocol_type, result, actor, note
            FROM equipment_history WHERE 1=1
        """
        params: list[Any] = []
        if object_name.strip():
            sql += " AND object_name = ?"
            params.append(object_name.strip())
        if result_filter.strip():
            sql += " AND result = ?"
            params.append(result_filter.strip())
        sql += " ORDER BY test_date DESC, id DESC LIMIT ?"
        params.append(max(1, min(limit * 3, 1500)))
        hrows = conn.execute(sql, params).fetchall()

    history_items = []
    for r in hrows:
        if q_low and q_low not in f"{r[2]} {r[3]} {r[5]} {r[7]}".lower():
            continue
        history_items.append({
            "id": r[0], "equipmentId": r[1], "object": r[2], "equipmentName": r[3],
            "testDate": r[4], "protocolNo": r[5], "protocolType": r[6],
            "result": r[7], "actor": r[8], "note": r[9],
        })
        if len(history_items) >= limit:
            break
    return {"protocols": proto_items, "history": history_items}


def check_personnel_clearance(
    fios: list[str],
    ref_date: str = "",
    require_hv: bool = False,
    db_path: Path = DB_PATH,
) -> dict[str, Any]:
    """Проверяет допуски персонала по ПОТЭЭ № 903н (группа ЭБ, срок проверки, спецработы)."""
    staff = list_personnel(db_path)
    check_date = ref_date.strip() or datetime.date.today().isoformat()
    results: list[dict[str, Any]] = []
    group_rank = {"I": 1, "II": 2, "III": 3, "IV": 4, "V": 5}

    for idx, raw_fio in enumerate(fios):
        q = str(raw_fio or "").strip()
        if not q:
            continue
        q_low = q.lower()
        match = next((p for p in staff if q_low in p["fio"].lower() or p["fio"].lower() in q_low), None)
        if not match:
            results.append({"fio": q, "found": False, "status": "НЕ НАЙДЕН", "issues": ["Сотрудник не внесён в реестр персонала ЭТЛ."]})
            continue
        issues: list[str] = []
        grp = str(match.get("ebGroup") or "").strip().upper()
        min_grp = 4 if idx == 0 else 3
        if group_rank.get(grp, 0) < min_grp:
            issues.append(f"Группа ЭБ «{grp or '—'}» ниже требуемой ({'IV' if min_grp == 4 else 'III'}).")
        vu = str(match.get("validUntil") or "").strip()
        if not vu:
            issues.append("Не указана дата следующей проверки знаний.")
        elif vu < check_date:
            issues.append(f"Проверка знаний просрочена ({vu} < {check_date}).")
        sr = str(match.get("specialRights") or "").lower()
        if require_hv and not any(k in sr for k in ("испыт", "вви", "спец", "повыш")):
            issues.append("В карточке не указана отметка о праве на спецработы (испытания повышенным напряжением).")
        results.append({
            "fio": match["fio"],
            "found": True,
            "ebGroup": grp,
            "validUntil": vu,
            "specialRights": match.get("specialRights") or "",
            "status": "ДОПУЩЕН" if not issues else "ТРЕБУЕТСЯ ВНИМАНИЕ",
            "issues": issues,
        })
    return {"checkDate": check_date, "requireHv": require_hv, "items": results}


def _classify_equipment(name: str) -> str:
    low = name.lower()
    if any(k in low for k in ("автоматический выключатель", "авт. выкл", "ав ", "авдт", "узо", "диф")):
        return "АВ"
    if any(k in low for k in ("электродвигател", "двигател", "насос", "вентилятор", "компрессор", "привод")):
        return "ЭД"
    if any(k in low for k in ("заземл", "молниезащ", "контур", "металлосвяз", "зу ")):
        return "ЗУ / Молниезащита"
    if any(k in low for k in ("трансформатор", "тсн", "тт ", "тн ", "тмг", "тм-")):
        return "ТТ / Трансформаторы"
    if any(k in low for k in ("опн", "ограничитель перенапряж", "разрядник")):
        return "ОПН"
    if any(k in low for k in ("кабел", "кл ", "кл-", "шин", "вл ", "вл-", "опора")):
        return "КЛ / Шины"
    if any(k in low for k in ("разъединител", "вакуумн", "выключатель нагрузки", "реклоузер", "ячейк")):
        return "ВВ / Разъединители"
    if any(k in low for k in ("рзиа", "защит", "бмрз", "сириус", "сепам", "sepam", "реле")):
        return "РЗиА"
    if any(k in low for k in ("укм", "конденсатор")):
        return "УКМ"
    return "Прочее"


def _normalize_excel_date(val: Any) -> str:
    if val is None:
        return ""
    if isinstance(val, (datetime.datetime, datetime.date)):
        return val.strftime("%Y-%m-%d")
    s = str(val).strip()
    if not s or s == "-":
        return ""
    m = re.search(r"(\d{2})\.(\d{2})\.(\d{4})", s)
    if m:
        return f"{m.group(3)}-{m.group(2)}-{m.group(1)}"
    m2 = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m2:
        return m2.group(0)
    return s


def _cell_has_plan_mark(cell: Any) -> bool:
    if cell.value is not None and str(cell.value).strip():
        return True
    fill = getattr(cell, "fill", None)
    if not fill or fill.fill_type in (None, "none"):
        return False
    fg = getattr(fill, "fgColor", None)
    if not fg:
        return False
    if fg.type == "rgb" and fg.rgb:
        rgb = str(fg.rgb).upper()
        if rgb not in ("00000000", "FFFFFFFF", "00FFFFFF"):
            return True
    if fg.type in ("theme", "indexed") and fg.value is not None:
        if fg.type == "indexed" and fg.value in (64, 65):
            return False
        return True
    return False


def parse_schedule_xlsx(file_bytes: bytes) -> dict[str, Any]:
    """Парсит Excel-график испытаний по заголовкам объектов (разделы до следующего заголовка)."""
    import openpyxl

    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
    ws = wb.active

    # Находим строку заголовка таблицы («тип, марка, конструкция» или «№ п/п»)
    start_row = 1
    for r in range(1, min(30, ws.max_row + 1)):
        b_val = str(ws.cell(r, 2).value or "").strip().lower()
        a_val = str(ws.cell(r, 1).value or "").strip().lower()
        if "тип, марка" in b_val:
            start_row = r + 1
            break
        if "№ п/п" in a_val:
            start_row = r + 1

    objects: list[str] = []
    seen_objs: set[str] = set()
    items: list[dict[str, Any]] = []
    current_obj = "Без раздела"
    seq = 0

    for r in range(start_row, ws.max_row + 1):
        c1 = ws.cell(r, 1).value
        c2 = ws.cell(r, 2).value
        c3 = ws.cell(r, 3).value
        c4 = ws.cell(r, 4).value
        c5 = ws.cell(r, 5).value

        s1 = str(c1).strip() if c1 is not None else ""
        s2 = str(c2).strip() if c2 is not None else ""
        s3 = str(c3).strip() if c3 is not None else ""
        s4 = str(c4).strip() if c4 is not None else ""
        s5 = _normalize_excel_date(c5)

        if not any((s1, s2, s3, s4, s5)):
            continue
        if "тип, марка, конструкция" in s2.lower() or "№ п/п" in s1.lower():
            continue
        if s1.lower().startswith("итого") or s2.lower().startswith("итого") or any(k in s2.lower() for k in ("составил", "утверждаю", "согласовано")):
            continue

        # Строка-заголовок объекта: заполнена только одна ячейка в колонках A–E (не порядковый номер)
        is_num_c1 = bool(re.fullmatch(r"\d+(\.\d+)?", s1))
        non_empty = [v for v in (s1, s2, s3, s4, s5) if v]
        if len(non_empty) == 1 and not is_num_c1:
            header_text = non_empty[0].replace("\n", " ").strip()
            header_text = re.sub(r"\s{2,}", " ", header_text)
            if len(header_text) >= 2:
                if header_text in seen_objs:
                    idx_dup = 2
                    while f"{header_text} (раздел {idx_dup})" in seen_objs:
                        idx_dup += 1
                    header_text = f"{header_text} (раздел {idx_dup})"
                current_obj = header_text
                seen_objs.add(current_obj)
                objects.append(current_obj)
            continue

        eq_name = s2 or s1
        if not eq_name:
            continue

        months: list[int] = []
        for m_idx in range(1, 13):
            col_idx = 5 + m_idx
            if col_idx <= ws.max_column and _cell_has_plan_mark(ws.cell(r, col_idx)):
                months.append(m_idx)

        if current_obj not in seen_objs:
            seen_objs.add(current_obj)
            objects.append(current_obj)

        seq += 1
        items.append(
            {
                "id": f"eq-{seq}",
                "num": s1 if is_num_c1 else str(seq),
                "object": current_obj,
                "name": eq_name,
                "power": s3,
                "period": s4,
                "lastDate": s5,
                "months": months,
                "cat": _classify_equipment(eq_name),
            }
        )

    # Оставляем только непустые объекты
    non_empty_objs = [o for o in objects if any(it["object"] == o for it in items)]
    return {"objects": non_empty_objs, "items": items}


def replace_equipment_from_xlsx(file_bytes: bytes, db_path: Path = DB_PATH) -> dict[str, int]:
    parsed = parse_schedule_xlsx(file_bytes)
    if not parsed["items"]:
        raise ValueError("В файле не найдено строк оборудования. Проверьте структуру графика.")
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        _write_equipment_records(conn, parsed["objects"], parsed["items"])
        conn.commit()
    planned = sum(1 for it in parsed["items"] if it["months"])
    return {
        "objectsCount": len(parsed["objects"]),
        "itemsCount": len(parsed["items"]),
        "plannedCount": planned,
    }


# ==================== ПЕРСОНАЛ, НАРЯДЫ-ДОПУСКИ, ЧЕК-ЛИСТ РОСТЕХНАДЗОРА ====================

DEFAULT_PERSONNEL: list[dict[str, Any]] = [
    {"id": "per-1", "fio": "Лиханов Дмитрий Юрьевич", "position": "Начальник ЭТЛ", "eb_group": "V", "voltage": "до и выше 1000 В", "special_rights": "Испытания повышенным напряжением, право выдачи нарядов, ответственный руководитель, производитель работ", "check_date": "", "valid_until": "", "cert_no": ""},
    {"id": "per-2", "fio": "Калимуллин Р.Р.", "position": "Инженер РЗиА", "eb_group": "IV", "voltage": "до и выше 1000 В", "special_rights": "Испытания повышенным напряжением, производитель работ", "check_date": "", "valid_until": "", "cert_no": ""},
    {"id": "per-3", "fio": "Болышев В.С.", "position": "Главный энергетик", "eb_group": "V", "voltage": "до и выше 1000 В", "special_rights": "Право выдачи нарядов и распоряжений, ответственный за электрохозяйство", "check_date": "", "valid_until": "", "cert_no": ""},
    {"id": "per-4", "fio": "Пригарин А.Н.", "position": "Главный инженер", "eb_group": "V", "voltage": "до и выше 1000 В", "special_rights": "Право выдачи нарядов, председатель комиссии по проверке знаний", "check_date": "", "valid_until": "", "cert_no": ""},
]

DEFAULT_ROSTECH_CHECKLIST: list[tuple[str, str, str]] = [
    ("rtn-1", "Заявление о регистрации / перерегистрации ЭТЛ в Северо-Уральское управление Ростехнадзора", "Св-во №58ЭТЛ035 (срок до 25.12.2027)"),
    ("rtn-2", "Приказ о создании ЭТЛ и назначении начальника ЭТЛ (Лиханов Д.Ю.)", "ПТЭЭП № 811"),
    ("rtn-3", "Положение об электротехнической лаборатории ООО «Сургут перевалка»", "Утверждено ген. директором С.М. Бабаевым"),
    ("rtn-4", "Перечень разрешённых видов испытаний и измерений (до и выше 1000 В)", "Св-во №58ЭТЛ035"),
    ("rtn-5", "Утверждённые методики измерений и испытаний (№№ 2, 4, 5, 6, 7, 8, 9, 10, 16, 20, 22, 23)", "Комплект МИИ ООО «Сургут перевалка»"),
    ("rtn-6", "Ведомость СИ, ИО и СИЗ с действующими сведениями ФГИС «АРШИН» (обновить 6 приборов в поверке)", "102-ФЗ, Приказ Минпромторга № 2510"),
    ("rtn-7", "Закупка и поверка термогигрометра-барометра (ИВА-6Н-Д / МЭС-200А)", "Обязательный контроль климата п. 11 протокола"),
    ("rtn-8", "Исключение законсервированных приборов (VM-82A, APPA A16HR) из перечня рабочих СИ", "Ведомость СИ/ИО 2027"),
    ("rtn-9", "Удостоверения о проверке знаний ЭБ (IV–V гр.) с отметкой на право проведения спецработ (испытаний)", "ПОТЭЭ № 903н (ред. № 279н)"),
    ("rtn-10", "Протоколы испытаний диэлектрических СИЗ (перчатки, боты, указатели УВН, штанги, ПЗ)", "Приказ Минэнерго № 261"),
    ("rtn-11", "Однолинейные схемы и перечень стационарных/переносных испытательных стендов и установок", "ПОТЭЭ № 903н гл. XXXIX"),
    ("rtn-12", "Образцы форм протоколов испытаний и технического отчёта", "Эталоны ООО «Сургут перевалка»"),
]


def _seed_stage3_if_empty(conn: sqlite3.Connection) -> None:
    if conn.execute("SELECT COUNT(*) FROM personnel").fetchone()[0] == 0:
        conn.executemany(
            """
            INSERT INTO personnel (id, fio, position, eb_group, voltage, special_rights, check_date, valid_until, cert_no)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (p["id"], p["fio"], p["position"], p["eb_group"], p["voltage"], p["special_rights"], p["check_date"], p["valid_until"], p["cert_no"])
                for p in DEFAULT_PERSONNEL
            ],
        )
    if conn.execute("SELECT COUNT(*) FROM rostech_checklist").fetchone()[0] == 0:
        conn.executemany(
            "INSERT INTO rostech_checklist (id, sort_order, title, norm_ref, done, note) VALUES (?, ?, ?, ?, 0, '')",
            [(cid, idx, title, norm) for idx, (cid, title, norm) in enumerate(DEFAULT_ROSTECH_CHECKLIST)],
        )


def list_personnel(db_path: Path = DB_PATH) -> list[dict[str, Any]]:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            "SELECT id, fio, position, eb_group, voltage, special_rights, check_date, valid_until, cert_no FROM personnel ORDER BY rowid ASC"
        ).fetchall()
    return [
        {
            "id": r[0], "fio": r[1], "position": r[2], "ebGroup": r[3],
            "voltage": r[4], "specialRights": r[5], "checkDate": r[6],
            "validUntil": r[7], "certNo": r[8],
        }
        for r in rows
    ]


def upsert_personnel(item: dict[str, Any], db_path: Path = DB_PATH) -> dict[str, Any]:
    init_db(db_path)
    pid = str(item.get("id") or f"per-{int(datetime.datetime.now().timestamp() * 1000)}")
    rec = (
        pid,
        str(item.get("fio") or "").strip(),
        str(item.get("position") or "").strip(),
        str(item.get("ebGroup") or "IV").strip(),
        str(item.get("voltage") or "до и выше 1000 В").strip(),
        str(item.get("specialRights") or "").strip(),
        str(item.get("checkDate") or "").strip(),
        str(item.get("validUntil") or "").strip(),
        str(item.get("certNo") or "").strip(),
    )
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO personnel (id, fio, position, eb_group, voltage, special_rights, check_date, valid_until, cert_no)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                fio=excluded.fio, position=excluded.position, eb_group=excluded.eb_group,
                voltage=excluded.voltage, special_rights=excluded.special_rights,
                check_date=excluded.check_date, valid_until=excluded.valid_until, cert_no=excluded.cert_no
            """,
            rec,
        )
        conn.commit()
    return {"id": pid, "status": "ok"}


def delete_personnel(pid: str, db_path: Path = DB_PATH) -> bool:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute("DELETE FROM personnel WHERE id = ?", (pid,))
        conn.commit()
        return cur.rowcount > 0


def list_work_permits(db_path: Path = DB_PATH) -> list[dict[str, Any]]:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            "SELECT id, payload FROM work_permits ORDER BY created_at DESC, rowid DESC"
        ).fetchall()
    out = []
    for r in rows:
        p = json.loads(r[1])
        p["id"] = r[0]
        out.append(p)
    return out


def save_work_permit(permit: dict[str, Any], db_path: Path = DB_PATH) -> dict[str, Any]:
    init_db(db_path)
    pid = str(permit.get("id") or f"wp-{int(datetime.datetime.now().timestamp() * 1000)}")
    permit_copy = dict(permit)
    permit_copy["id"] = pid
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO work_permits (id, number, issue_date, object_name, payload)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                number=excluded.number, issue_date=excluded.issue_date,
                object_name=excluded.object_name, payload=excluded.payload
            """,
            (
                pid,
                str(permit_copy.get("number") or "1"),
                str(permit_copy.get("issueDate") or datetime.date.today().isoformat()),
                str(permit_copy.get("object") or ""),
                json.dumps(permit_copy, ensure_ascii=False),
            ),
        )
        conn.commit()
    return permit_copy


def delete_work_permit(pid: str, db_path: Path = DB_PATH) -> bool:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute("DELETE FROM work_permits WHERE id = ?", (pid,))
        conn.commit()
        return cur.rowcount > 0


def list_rostech_checklist(db_path: Path = DB_PATH) -> list[dict[str, Any]]:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            "SELECT id, title, norm_ref, done, note FROM rostech_checklist ORDER BY sort_order ASC"
        ).fetchall()
    return [
        {"id": r[0], "title": r[1], "normRef": r[2], "done": bool(r[3]), "note": r[4]}
        for r in rows
    ]


def update_rostech_item(item_id: str, done: bool, note: str = "", db_path: Path = DB_PATH) -> bool:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        cur = conn.execute(
            "UPDATE rostech_checklist SET done = ?, note = ? WHERE id = ?",
            (1 if done else 0, note, item_id),
        )
        conn.commit()
        return cur.rowcount > 0


# ==================== КАЛЕНДАРЬ ППР (12 МЕСЯЦЕВ) ====================


def get_ppr_calendar_summary(db_path: Path = DB_PATH) -> dict[str, Any]:
    init_db(db_path)
    month_counts = {m: 0 for m in range(1, 13)}
    month_objects: dict[int, set[str]] = {m: set() for m in range(1, 13)}
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute("SELECT object_name, months_json FROM equipment").fetchall()
    for obj, m_json in rows:
        months = json.loads(m_json) if m_json else []
        for m in months:
            if 1 <= m <= 12:
                month_counts[m] += 1
                month_objects[m].add(obj)
    return {
        "months": [
            {"month": m, "itemsCount": month_counts[m], "objectsCount": len(month_objects[m])}
            for m in range(1, 13)
        ]
    }


# ==================== АРХИВ СКАНОВ (PDF / ИЗОБРАЖЕНИЯ ДЛЯ СИ И СИЗ) ====================


def list_attachments(entity_id: str = "", db_path: Path = DB_PATH) -> list[dict[str, Any]]:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        if entity_id:
            rows = conn.execute(
                "SELECT id, entity_id, filename, stored_name, mime_type, size_bytes, uploaded_at FROM attachments WHERE entity_id = ? ORDER BY uploaded_at DESC",
                (entity_id,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, entity_id, filename, stored_name, mime_type, size_bytes, uploaded_at FROM attachments ORDER BY uploaded_at DESC"
            ).fetchall()
    return [
        {
            "id": r[0], "entityId": r[1], "filename": r[2], "storedName": r[3],
            "mimeType": r[4], "sizeBytes": int(r[5] or 0), "uploadedAt": r[6],
        }
        for r in rows
    ]


def save_attachment(
    entity_id: str,
    filename: str,
    mime_type: str,
    content: bytes,
    db_path: Path = DB_PATH,
    uploads_dir: Path = UPLOADS_DIR,
) -> dict[str, Any]:
    init_db(db_path)
    uploads_dir.mkdir(parents=True, exist_ok=True)
    att_id = f"att-{int(datetime.datetime.now().timestamp() * 1000)}"
    safe_ext = Path(filename).suffix.lower() or ".bin"
    stored_name = f"{att_id}{safe_ext}"
    (uploads_dir / stored_name).write_bytes(content)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "INSERT INTO attachments (id, entity_id, filename, stored_name, mime_type, size_bytes) VALUES (?, ?, ?, ?, ?, ?)",
            (att_id, entity_id, filename, stored_name, mime_type or "application/octet-stream", len(content)),
        )
        conn.commit()
    return {
        "id": att_id, "entityId": entity_id, "filename": filename,
        "mimeType": mime_type, "sizeBytes": len(content),
    }


def get_attachment(att_id: str, db_path: Path = DB_PATH, uploads_dir: Path = UPLOADS_DIR) -> tuple[dict[str, Any], bytes] | None:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT id, entity_id, filename, stored_name, mime_type, size_bytes FROM attachments WHERE id = ?",
            (att_id,),
        ).fetchone()
    if not row:
        return None
    fpath = uploads_dir / row[3]
    if not fpath.exists():
        return None
    return (
        {"id": row[0], "entityId": row[1], "filename": row[2], "mimeType": row[4], "sizeBytes": row[5]},
        fpath.read_bytes(),
    )


def delete_attachment(att_id: str, db_path: Path = DB_PATH, uploads_dir: Path = UPLOADS_DIR) -> bool:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute("SELECT stored_name FROM attachments WHERE id = ?", (att_id,)).fetchone()
        if not row:
            return False
        conn.execute("DELETE FROM attachments WHERE id = ?", (att_id,))
        conn.commit()
    fpath = uploads_dir / row[0]
    if fpath.exists():
        try:
            fpath.unlink()
        except OSError:
            pass
    return True


# ==================== ИМПОРТ ЗАМЕРОВ ИЗ EXCEL / CSV (ПРИЛОЖЕНИЕ №2) ====================

PROTOCOL_IMPORT_COLUMNS: dict[str, list[tuple[str, str]]] = {
    "breaker_1p": [("panel", "Щит"), ("line", "Присоединение"), ("abType", "Тип АВ"), ("inVal", "In, А"), ("thSet", "Iт уст, А"), ("thTrip", "Iт ср, А"), ("thTime", "tт, с"), ("emSet", "Iэм уст, А"), ("emTrip", "Iэм ср, А"), ("emTime", "tэм, с")],
    "breaker_3p": [("panel", "Щит"), ("line", "Присоединение"), ("abType", "Тип АВ"), ("inVal", "In, А"), ("thSet", "Iт уст, А"), ("thTimes", "tт (A/B/C), с"), ("emSet", "Iэм уст, А"), ("emTrips", "Iэм ср (A/B/C), А"), ("emTime", "tэм, с")],
    "motor": [("line", "Присоединение"), ("edType", "Тип ЭД"), ("rA", "A-N, МОм"), ("rB", "B-N, МОм"), ("rC", "C-N, МОм"), ("kabs", "Kабс"), ("norm", "Норма, МОм")],
    "continuity": [("line", "Заземляемый элемент"), ("conductor", "Проводник"), ("rVal", "Rконт, Ом"), ("err", "Погр., %"), ("norm", "Норма, Ом")],
    "grounding": [("line", "Принадлежность ЗУ"), ("rMeas", "Rизм, Ом"), ("kSez", "Ксез"), ("err", "Погр., %"), ("norm", "Норма, Ом")],
    "opn": [("line", "Место установки ОПН"), ("phase", "Фаза"), ("rIz", "Rиз, МОм"), ("uisp", "Uисп, кВ"), ("iCond", "Iпров, мкА"), ("normR", "Норма Rиз, МОм")],
    "transformer": [("line", "Параметр трансформатора"), ("meas", "Измерено"), ("unit", "Ед."), ("norm", "Норма"), ("cond", "Условие (gte/lte/pm2)")],
    "disconnector": [("line", "Наименование / зав. №"), ("phase", "Фаза"), ("rIz", "Rиз, МОм"), ("rKs", "Rкс, мкОм"), ("rCd", "Rцд, мкОм"), ("normR", "Норма, мкОм")],
    "insulation": [("line", "Наименование линии / цепи"), ("uisp", "Uисп, В"), ("r15", "R15, МОм"), ("r60", "R60, МОм"), ("norm", "Норма, МОм")],
    "loop": [("line", "Линия / аппарат"), ("inVal", "In, А"), ("curve", "Хар. (B/C/D)"), ("zLoop", "Zп, Ом")],
    "hv_test": [("line", "Оборудование / жила КЛ"), ("uTest", "Uисп, кВ"), ("duration", "Время, мин"), ("iLeak", "Iут, мА"), ("normLeak", "Норма, мА"), ("breakdown", "Пробой (Нет/Да)")],
    "rcd": [("line", "Линия / тип УЗО"), ("idn", "IΔn, мА"), ("iTrip", "Iср, мА"), ("tTrip", "tоткл, мс"), ("tMax", "tмакс, мс")],
    "rzia": [("line", "Присоединение / ступень"), ("setpoint", "Уставка"), ("measured", "Измерено"), ("tol", "Допуск, %")],
    "dc_resistance": [("line", "Объект / обмотка / контакт"), ("phase", "Фаза / участок"), ("rVal", "Rизм, мкОм"), ("norm", "Норма, мкОм"), ("diff", "Разброс, %")],
    "ct": [("line", "Ячейка / тип ТТ"), ("phase", "Фаза"), ("rPrim", "Rиз перв. (2500 В), МОм"), ("rSec", "Rиз втор. (1000 В), МОм"), ("param", "Rобм / Kтр / ВАХ"), ("hv", "ВВИ (кВ/мин)")],
    "vt": [("line", "Ячейка / тип ТН"), ("phase", "Фаза"), ("rPrim", "Rиз перв. (2500 В), МОм"), ("rSec", "Rиз втор. (1000 В), МОм"), ("param", "Rобм / Kтр"), ("hv", "ВВИ (кВ/мин)")],
    "cb_oil": [("line", "Ячейка / тип МВ"), ("phase", "Фаза"), ("rOrg", "Rиз орг. (2500 В), МОм"), ("rSec", "Rиз втор. (1000 В), МОм"), ("rCont", "Rконт, мкОм"), ("hv", "ВВИ (кВ/мин)"), ("drive", "Привод")],
    "cb_sf6": [("line", "Ячейка / тип ЭВ"), ("phase", "Фаза"), ("rOrg", "Rиз орг. (2500 В), МОм"), ("rSec", "Rиз втор. (1000 В), МОм"), ("rCont", "Rконт, мкОм"), ("hv", "ВВИ (кВ/мин)"), ("drive", "Привод / SF6")],
    "cb_air": [("line", "Ячейка / тип ВВ"), ("phase", "Фаза"), ("rOrg", "Rиз орг. (2500 В), МОм"), ("rSec", "Rиз втор. (1000 В), МОм"), ("rCont", "Rконт, мкОм"), ("hv", "ВВИ (кВ/мин)"), ("drive", "Привод")],
    "load_switch": [("line", "Ячейка / тип ВН"), ("phase", "Фаза"), ("rOrg", "Rиз орг. (2500 В), МОм"), ("rSec", "Rиз втор. (1000 В), МОм"), ("rCont", "Rконт, мкОм"), ("hv", "ВВИ (кВ/мин)"), ("drive", "Привод")],
    "cb_vacuum": [("line", "Ячейка / тип ВВ (вакуумный)"), ("phase", "Фаза"), ("rOrg", "Rиз орг. (2500 В), МОм"), ("rSec", "Rиз втор. (1000 В), МОм"), ("rCont", "Rконт, мкОм"), ("hv", "ВВИ камер (кВ/мин)"), ("drive", "Привод")],
    "kru": [("line", "Ячейка КРУ / КРУН"), ("isoType", "Вид изоляции"), ("rIz", "Rиз (2500 В), МОм"), ("normR", "Норма Rиз, МОм"), ("rCont", "Rконт, мкОм"), ("hv", "ВВИ (кВ/мин)")],
    "busduct": [("line", "Секция токопровода / шинопровода"), ("isoType", "Вид изоляции"), ("rIz", "Rиз (2500 В), МОм"), ("normR", "Норма Rиз, МОм"), ("rCont", "Rсоед, мкОм"), ("hv", "ВВИ (кВ/мин)")],
    "insulators_bus": [("line", "Ввод / изолятор / сборные шины"), ("isoType", "Опорн. / проходн."), ("rIz", "Rиз (2500 В), МОм"), ("normR", "Норма Rиз, МОм"), ("rCont", "Rсоед, мкОм"), ("hv", "ВВИ (кВ/мин)")],
    "hv_fuse": [("line", "Ячейка / предохранитель 6–10 кВ"), ("isoType", "Вид изоляции"), ("rIz", "Rиз (2500 В), МОм"), ("normR", "Норма Rиз, МОм"), ("rCont", "Целостн. / R, мкОм"), ("hv", "ВВИ (кВ/мин)")],
    "ohl": [("line", "ВЛ 6–10 кВ / опора / пролёт"), ("isoType", "Изоляторы / ВЛ"), ("rIz", "Rиз (2500 В), МОм"), ("normR", "Норма Rиз, МОм"), ("rCont", "Rсоед / контур"), ("hv", "ВВИ (кВ/мин)")],
}


def generate_protocol_template_xlsx(proto_type: str) -> bytes:
    """Генерирует шаблон Excel (.xlsx) для быстрого импорта замеров в Приложение № 2."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment

    cols = PROTOCOL_IMPORT_COLUMNS.get(proto_type, PROTOCOL_IMPORT_COLUMNS["insulation"])
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Замеры"
    hdr_font = Font(bold=True, color="1E293B")
    hdr_fill = PatternFill("solid", fgColor="E2E8F0")
    for c_idx, (_, title) in enumerate(cols, start=1):
        cell = ws.cell(1, c_idx, title)
        cell.font = hdr_font
        cell.fill = hdr_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[openpyxl.utils.get_column_letter(c_idx)].width = max(18, len(title) + 4)

    ws_help = wb.create_sheet("Инструкция")
    ws_help.cell(1, 1, "Тип протокола").font = Font(bold=True)
    ws_help.cell(1, 2, proto_type)
    ws_help.cell(2, 1, "Правила заполнения").font = Font(bold=True)
    ws_help.cell(2, 2, "Заполняйте данные со 2-й строки листа «Замеры». Можно загружать .xlsx или .csv (включая выгрузки Sonel) — колонки распознаются по заголовкам или по порядку.")
    ws_help.column_dimensions["A"].width = 22
    ws_help.column_dimensions["B"].width = 90

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


_NUMERIC_KEYS = {
    "inVal", "thSet", "thTrip", "thTime", "emSet", "emTrip", "emTime",
    "rA", "rB", "rC", "kabs", "norm", "rVal", "err", "rMeas", "kSez",
    "rIz", "uisp", "normR", "meas", "rKs", "rCd", "r15", "r60",
    "zVal", "uVal", "dur", "iLeak", "iNorm", "idn", "iTrip", "tTrip",
    "tMax", "setpoint", "measured", "tol", "diff", "rPrim", "rSec",
    "rOrg", "rCont",
}


def _normalize_num_str(val: str) -> str:
    s = str(val or "").strip()
    if not s:
        return ""
    s_clean = s.replace("\u00a0", "").replace(" ", "").replace(",", ".")
    try:
        float(s_clean)
        return s_clean
    except ValueError:
        return s


def parse_measurements_file_detailed(proto_type: str, filename: str, file_bytes: bytes) -> dict[str, Any]:
    """Умный парсер замеров из .xlsx или .csv: распознавание по заголовкам, нормализация чисел и отчёт об ошибках."""
    import csv

    cols = PROTOCOL_IMPORT_COLUMNS.get(proto_type, PROTOCOL_IMPORT_COLUMNS["insulation"])
    raw_rows: list[list[str]] = []

    if filename.lower().endswith(".csv"):
        text = ""
        for enc in ("utf-8-sig", "cp1251", "utf-8"):
            try:
                text = file_bytes.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        delim = ";" if text.count(";") >= text.count(",") else ","
        reader = csv.reader(io.StringIO(text), delimiter=delim)
        for row in reader:
            if any(str(c).strip() for c in row):
                raw_rows.append([str(c).strip() for c in row])
    else:
        import openpyxl

        wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
        ws = wb.active
        for r in range(1, ws.max_row + 1):
            vals = [str(ws.cell(r, c).value).strip() if ws.cell(r, c).value is not None else "" for c in range(1, ws.max_column + 1)]
            if any(vals):
                raw_rows.append(vals)

    if not raw_rows:
        raise ValueError("Файл пуст или не содержит строк замеров.")

    first_low = " ".join(raw_rows[0]).lower()
    has_header = any(
        k in first_low
        for k in (
            "присоед", "щит", "линия", "элемент", "тип", "r15", "r60", "zп",
            "rконт", "rиз", "измерено", "уставка", "объект", "фаза", "норма",
            "ячейка", "наименование", "опора", "секции", "секция", "ввод", "пробой",
        )
    )
    data_rows = raw_rows[1:] if has_header else raw_rows

    # Попытка сопоставления по заголовкам колонок
    col_map: dict[str, int] = {}
    if has_header:
        hdr_norm = [h.lower().strip() for h in raw_rows[0]]
        for key, title in cols:
            t_low = title.lower().strip()
            t_words = [w for w in re.split(r"[^a-zа-яё0-9]+", t_low) if len(w) >= 2]
            best_idx = -1
            best_score = 0
            for idx, h in enumerate(hdr_norm):
                if idx in col_map.values():
                    continue
                if h == t_low or key.lower() == h:
                    best_idx = idx
                    best_score = 100
                    break
                score = sum(1 for w in t_words if w in h)
                if score > best_score:
                    best_score = score
                    best_idx = idx
            if best_idx >= 0 and best_score > 0:
                col_map[key] = best_idx

    use_header_map = has_header and len(col_map) >= max(2, len(cols) // 2)
    matched_by = "headers" if use_header_map else "position"

    skip_first_col = False
    if not use_header_map and has_header and raw_rows[0] and raw_rows[0][0].lower().startswith("№"):
        skip_first_col = True

    result: list[dict[str, str]] = []
    skipped = 0
    for row in data_rows:
        cells = row if use_header_map else (row[1:] if skip_first_col else row)
        if not any(cells):
            skipped += 1
            continue
        first_cell = str(cells[0] if cells else "").strip().lower()
        if first_cell in ("итого", "всего", "среднее"):
            skipped += 1
            continue

        item: dict[str, str] = {}
        for idx, (key, _) in enumerate(cols):
            if use_header_map:
                src_idx = col_map.get(key)
                raw_val = cells[src_idx] if (src_idx is not None and src_idx < len(cells)) else ""
            else:
                raw_val = cells[idx] if idx < len(cells) else ""
            item[key] = _normalize_num_str(raw_val) if key in _NUMERIC_KEYS else raw_val

        # Дефолты для норм, если пусто
        if proto_type == "grounding" and not item.get("kSez"):
            item["kSez"] = "1"
        if proto_type == "grounding" and not item.get("norm"):
            item["norm"] = "10"
        if proto_type == "continuity" and not item.get("norm"):
            item["norm"] = "0.05"
        if proto_type == "insulation" and not item.get("norm"):
            item["norm"] = "0.5"
        if proto_type == "hv_test" and not item.get("breakdown"):
            item["breakdown"] = "Нет"
        result.append(item)

    if not result:
        raise ValueError("Не удалось извлечь ни одной строки замеров.")

    warnings: list[str] = []
    if has_header and not use_header_map:
        warnings.append("Заголовки распознаны частично — применён импорт по порядку колонок.")
    elif use_header_map and len(col_map) < len(cols):
        missing_titles = [title for key, title in cols if key not in col_map]
        warnings.append(f"Не найдены столбцы: {', '.join(missing_titles[:3])}.")

    return {
        "rows": result,
        "count": len(result),
        "skipped": skipped,
        "matched_by": matched_by,
        "warnings": warnings,
    }


def parse_measurements_file(proto_type: str, filename: str, file_bytes: bytes) -> list[dict[str, str]]:
    return parse_measurements_file_detailed(proto_type, filename, file_bytes)["rows"]
