@echo off
cd /d "%~dp0"
echo ==========================================
echo   ARM ETL - OOO Surgut Perevalka (Offline)
echo ==========================================
set PY_CMD=python
where python >nul 2>&1 || set PY_CMD=py -3
%PY_CMD% --version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python 3.10+ not found. Install Python with Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  %PY_CMD% -m venv .venv
)
".venv\Scripts\python.exe" -c "import fastapi, uvicorn, docx, openpyxl, multipart" >nul 2>&1
if errorlevel 1 (
  echo Installing dependencies (first run, internet required once)...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
  if errorlevel 1 (
    echo [ERROR] Failed to install dependencies. Check internet connection.
    pause
    exit /b 1
  )
) else (
  echo Dependencies OK (offline mode ready).
)
echo Starting server on http://127.0.0.1:8080 and LAN port 8080...
echo Do not close this window while working on PC or phone.
".venv\Scripts\python.exe" app.py
pause
