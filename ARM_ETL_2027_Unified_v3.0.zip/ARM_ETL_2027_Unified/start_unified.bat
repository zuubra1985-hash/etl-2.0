@echo off
setlocal EnableDelayedExpansion
set PYTHONUTF8=1
cd /d "%~dp0"

echo ========================================================
echo   ARM ETL 2027 + ETL 2.0 (Unified Platform v3.0 - Win10)
echo ========================================================

set "PY_CMD="
where py >nul 2>&1 && set "PY_CMD=py -3"
if not defined PY_CMD (where python >nul 2>&1 && set "PY_CMD=python")
if not defined PY_CMD (
    echo [ERROR] Python 3.10+ not found in PATH.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/2] Creating virtual environment .venv ...
    %PY_CMD% -m venv .venv
    if errorlevel 1 (echo [ERROR] venv failed & pause & exit /b 1)
    echo [1/2] Installing unified dependencies ...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (echo [ERROR] pip install failed & pause & exit /b 1)
)

echo [2/2] Starting Unified Server v3.0 on port 8080 ...
echo   ARM ETL 2027 (Main UI)  : http://127.0.0.1:8080/
echo   ETL 2.0 Passports & QR  : http://127.0.0.1:8080/passports
echo   Mobile PWA (QR Scanner) : http://127.0.0.1:8080/mobile
echo   Swagger API Docs        : http://127.0.0.1:8080/docs
echo Press Ctrl+C to stop.
".venv\Scripts\python.exe" app.py
pause
