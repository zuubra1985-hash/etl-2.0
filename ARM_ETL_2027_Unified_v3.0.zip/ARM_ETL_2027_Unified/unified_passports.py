"""Единый модуль электронных паспортов, журналов ППР/ТО и QR-бирок в общей БД etl_base.db (АРМ ЭТЛ v3.0)."""

from __future__ import annotations

import datetime
import io
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import openpyxl
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt

import database as arm_db
from application.server.modules.passports.service import (
    _render_motor_oge_template_docx,
    _set_cell_text,
    _set_tnr,
    _mark_table_header_and_nosplit,
    find_soffice,
    render_passport_pdf_fallback,
)
from application.server.modules.passports.templates import get_template_for_type
from application.server.modules.qr.generator import (
    render_qr_labels_pdf,
    render_qr_png,
    render_qr_svg,
)

PROJECT_ROOT = Path(__file__).resolve().parent
ORIGINALS_DIR = PROJECT_ROOT / "uploads" / "passport_originals"
MOTORS_XLSX = PROJECT_ROOT / "data" / "equipment" / "motors_register_2024.xlsx"
OGE_TEMPLATE = PROJECT_ROOT / "documents" / "templates" / "motor_passport_oge_template.docx"

_PROTO_TYPE_RU = {
    "insulation": "Измерение сопротивления изоляции",
    "loop": "Измерение петли фаза-нуль",
    "ground": "Измерение сопротивления заземления",
    "bond": "Проверка металлосвязи",
    "rcd": "Проверка УЗО / дифавтоматов",
    "breaker": "Проверка автоматических выключателей",
    "hv": "Испытание повышенным напряжением",
    "motor": "Испытание электродвигателя",
    "cable": "Испытание кабельной линии",
    "transformer": "Испытание силового трансформатора",
    "rza": "Проверка устройств РЗиА",
    "visual": "Визуальный осмотр электроустановки",
}

_TYPE_NAMES_RU = {
    "MOTOR": "Электродвигатель переменного тока",
    "TRANSFORMER": "Силовой трансформатор",
    "KRU": "КРУ / КТП / КСО",
    "BREAKER_LV": "Автоматический выключатель до 1000 В",
    "BREAKER_HV": "Высоковольтный выключатель",
    "CABLE_LINE": "Кабельная линия",
    "GROUNDING": "Заземляющее устройство и молниезащита",
    "CT_VT": "Трансформатор тока / напряжения",
    "SWITCHBOARD": "Щит / ВРУ / ШУ / ЩО",
    "PPE": "Электрозащитные средства (СИЗ)",
}


def _detect_lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.3)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    return "127.0.0.1"


def build_qr_url(qr_token: str) -> str:
    host = os.environ.get("ARM_ETL_PUBLIC_URL") or f"http://{_detect_lan_ip()}:8080"
    return f"{host.rstrip('/')}/eq/{qr_token}"


def guess_type_code(cat: str, name: str) -> str:
    txt = f"{cat} {name}".lower()
    if "электродвиг" in txt or "эд " in txt or "насос" in txt or "вентилятор" in txt:
        return "MOTOR"
    if "трансформатор тока" in txt or "трансформатор напряж" in txt or "тт " in txt or "тн " in txt:
        return "CT_VT"
    if "трансформатор" in txt or "тмг" in txt or "тм-" in txt:
        return "TRANSFORMER"
    if "кабел" in txt or "кл " in txt or "кл-" in txt:
        return "CABLE_LINE"
    if "заземл" in txt or "молниезащ" in txt or "контур" in txt:
        return "GROUNDING"
    if "кру" in txt or "ктп" in txt or "ксо" in txt or "ячейк" in txt:
        return "KRU"
    if "выключател" in txt and ("6 кв" in txt or "10 кв" in txt or "вакуум" in txt or "вв/tel" in txt):
        return "BREAKER_HV"
    if "автомат" in txt or "выключател" in txt or "узо" in txt or "дифавтомат" in txt:
        return "BREAKER_LV"
    if "сиз" in txt or "перчатк" in txt or "боты" in txt or "указател" in txt or "штанга" in txt:
        return "PPE"
    return "SWITCHBOARD"


def init_unified_passport_tables(db_path: Optional[Path] = None) -> None:
    target = db_path or arm_db.DB_PATH
    with sqlite3.connect(target) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS equipment_passports (
                equipment_id TEXT PRIMARY KEY,
                qr_token TEXT UNIQUE NOT NULL,
                short_code TEXT UNIQUE NOT NULL,
                type_code TEXT NOT NULL DEFAULT 'SWITCHBOARD',
                dispatch_name TEXT DEFAULT '',
                inventory_no TEXT DEFAULT '',
                serial_no TEXT DEFAULT '',
                model TEXT DEFAULT '',
                manufacturer TEXT DEFAULT '',
                commissioned_at TEXT DEFAULT '',
                specs_json TEXT NOT NULL DEFAULT '{}',
                sec_1_scheme TEXT DEFAULT '',
                sec_3_rza TEXT DEFAULT '',
                original_file_path TEXT DEFAULT '',
                original_filename TEXT DEFAULT '',
                print_count INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS passport_journal (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                equipment_id TEXT NOT NULL,
                section TEXT NOT NULL,
                event_date TEXT NOT NULL DEFAULT '',
                col1 TEXT DEFAULT '',
                col2 TEXT DEFAULT '',
                col3 TEXT DEFAULT '',
                col4 TEXT DEFAULT '',
                col5 TEXT DEFAULT '',
                created_by TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pjournal_eq ON passport_journal(equipment_id, section)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS passport_versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                equipment_id TEXT NOT NULL,
                version_no INTEGER NOT NULL,
                snapshot_json TEXT NOT NULL,
                change_reason TEXT DEFAULT '',
                created_by TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pver_eq ON passport_versions(equipment_id, version_no)")
        conn.commit()


def _parse_float(val: Any) -> Optional[float]:
    if val is None:
        return None
    m = re.search(r"\d+(?:\.\d+)?", str(val).strip().replace(",", "."))
    return float(m.group(0)) if m else None


def _split_facility_dispatch(raw_place: str) -> Tuple[str, str]:
    clean = re.sub(r"\s+", " ", str(raw_place or "").replace("\n", " ")).strip()
    if not clean:
        return ("Общий участок", "Электродвигатель")
    parts = re.split(r"[,;/]", clean, maxsplit=1)
    fac = parts[0].strip().rstrip(".") or "Общий участок"
    return (fac, clean)


def seed_motors_into_arm_db(db_path: Optional[Path] = None, xlsx_path: Optional[Path] = None) -> int:
    """Idempotently import 230 motors from motors_register_2024.xlsx directly into etl_base.db."""
    target = db_path or arm_db.DB_PATH
    xfile = xlsx_path or MOTORS_XLSX
    init_unified_passport_tables(target)
    if not xfile.exists():
        return 0

    wb = openpyxl.load_workbook(str(xfile), data_only=True)
    ws = wb.active
    added = 0
    with sqlite3.connect(target) as conn:
        existing_ids = {r[0] for r in conn.execute("SELECT id FROM equipment").fetchall()}
        existing_objs = {r[0] for r in conn.execute("SELECT name FROM equipment_objects").fetchall()}
        max_obj_sort = conn.execute("SELECT COALESCE(MAX(sort_order), -1) FROM equipment_objects").fetchone()[0]
        max_eq_sort = conn.execute("SELECT COALESCE(MAX(sort_order), -1) FROM equipment").fetchone()[0]

        for r in range(2, ws.max_row + 1):
            seq_no = ws.cell(r, 1).value
            raw_place = ws.cell(r, 2).value
            raw_model = ws.cell(r, 3).value
            raw_kw = ws.cell(r, 4).value
            raw_rpm = ws.cell(r, 5).value
            raw_bearings = ws.cell(r, 6).value
            raw_year = ws.cell(r, 7).value
            raw_mfg = ws.cell(r, 8).value
            if raw_place is None and raw_model is None:
                continue

            seq_int = int(seq_no) if isinstance(seq_no, (int, float)) else r - 1
            inv_no = f"ED-REG-{seq_int:03d}"
            eq_id = f"ed-reg-{inv_no}"
            fac_name, disp_name = _split_facility_dispatch(str(raw_place or ""))
            model_str = re.sub(r"\s+", " ", str(raw_model or "").replace("\n", " ")).strip() or "Б/М"
            kw_val = _parse_float(raw_kw)
            rpm_val = _parse_float(raw_rpm)
            bearings_str = re.sub(r"\s+", " ", str(raw_bearings or "").replace("\n", " ")).strip() or None
            year_str = str(int(raw_year)) if isinstance(raw_year, (int, float)) else (str(raw_year).strip() if raw_year else "")
            mfg_str = re.sub(r"\s+", " ", str(raw_mfg or "").replace("\n", " ")).strip()

            b_drive, b_nondrive = bearings_str, None
            if bearings_str and "/" in bearings_str:
                p1, p2 = [x.strip() for x in bearings_str.split("/", 1)]
                b_drive, b_nondrive = p1, p2

            display_name = f"ЭД {model_str} ({disp_name})"
            pwr_txt = f"{kw_val} кВт" if kw_val is not None else "—"
            rpm_txt = f", {int(rpm_val)} об/мин" if rpm_val is not None else ""
            last_d = f"{year_str}-06-01" if year_str.isdigit() else ""

            if eq_id not in existing_ids:
                if fac_name not in existing_objs:
                    max_obj_sort += 1
                    conn.execute("INSERT OR IGNORE INTO equipment_objects (name, sort_order) VALUES (?, ?)", (fac_name, max_obj_sort))
                    existing_objs.add(fac_name)
                max_eq_sort += 1
                conn.execute(
                    """
                    INSERT OR IGNORE INTO equipment (id, sort_order, num, object_name, name, power, period, last_date, months_json, cat)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (eq_id, max_eq_sort, inv_no, fac_name, display_name, f"{pwr_txt}{rpm_txt}", "1 раз в 3 года", last_d, "[5, 9]", "Электродвигатели"),
                )
                existing_ids.add(eq_id)
                added += 1

            specs = {
                "type": model_str,
                "power_kw": kw_val,
                "rpm": int(rpm_val) if rpm_val is not None else None,
                "voltage_v": "380",
                "phases": "3",
                "frequency_hz": "50",
                "bearings": bearings_str or "",
                "bearing_drive": b_drive or "",
                "bearing_non_drive": b_nondrive or "",
            }
            qr_tok = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"surgut-perevalka-etl:{eq_id}"))
            short_code = f"EQ-{qr_tok[:8].upper()}"
            conn.execute(
                """
                INSERT OR IGNORE INTO equipment_passports
                (equipment_id, qr_token, short_code, type_code, dispatch_name, inventory_no, model, manufacturer, commissioned_at, specs_json)
                VALUES (?, ?, ?, 'MOTOR', ?, ?, ?, ?, ?, ?)
                """,
                (eq_id, qr_tok, short_code, disp_name, inv_no, model_str, mfg_str, year_str, json.dumps(specs, ensure_ascii=False)),
            )
        conn.commit()
    return added


def ensure_passport_row(conn: sqlite3.Connection, equipment_id: str) -> Dict[str, Any]:
    conn.row_factory = sqlite3.Row
    eq = conn.execute("SELECT * FROM equipment WHERE id = ?", (equipment_id,)).fetchone()
    if not eq:
        raise KeyError("Оборудование не найдено в базе")
    p = conn.execute("SELECT * FROM equipment_passports WHERE equipment_id = ?", (equipment_id,)).fetchone()
    if not p:
        qr_tok = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"surgut-perevalka-etl:{equipment_id}"))
        short_code = f"EQ-{qr_tok[:8].upper()}"
        tcode = guess_type_code(eq["cat"], eq["name"])
        inv_no = str(eq["num"] or "").strip() or (equipment_id if equipment_id.startswith("ED-") else f"ARM-{equipment_id}")
        specs = {"type": eq["name"], "arm_power": eq["power"] or ""}
        conn.execute(
            """
            INSERT INTO equipment_passports
            (equipment_id, qr_token, short_code, type_code, dispatch_name, inventory_no, model, specs_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (equipment_id, qr_tok, short_code, tcode, eq["name"], inv_no, eq["power"] or "", json.dumps(specs, ensure_ascii=False)),
        )
        conn.commit()
        p = conn.execute("SELECT * FROM equipment_passports WHERE equipment_id = ?", (equipment_id,)).fetchone()
    return {"eq": dict(eq), "passport": dict(p)}


def _collect_auto_tests(conn: sqlite3.Connection, eq: Dict[str, Any], passport: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Collect all test records for this equipment directly from unified etl_base.db (equipment_tests + saved protocols + manual archive)."""
    records: List[Dict[str, Any]] = []
    seen_keys = set()

    # 1. Direct equipment_tests history from ARM ETL
    try:
        rows = conn.execute(
            "SELECT test_date, protocol_no, protocol_type, result, actor, note FROM equipment_tests WHERE equipment_id = ? ORDER BY test_date DESC, id DESC",
            (eq["id"],),
        ).fetchall()
        for r in rows:
            key = (str(r["test_date"]), str(r["protocol_no"] or ""), str(r["protocol_type"] or ""))
            seen_keys.add(key)
            records.append({
                "source": "arm_history",
                "date": str(r["test_date"] or ""),
                "test_type": str(r["protocol_type"] or "Плановое испытание ППР"),
                "protocol_no": str(r["protocol_no"] or "График ППР"),
                "summary": str(r["note"] or f"Выполнено ({r['actor'] or 'ЭТЛ'})"),
                "conclusion": str(r["result"] or "Соответствует"),
            })
    except sqlite3.OperationalError:
        pass

    # 2. Saved protocols in app_state.payload
    try:
        st_row = conn.execute("SELECT payload FROM app_state WHERE id = 1").fetchone()
        if st_row and st_row["payload"]:
            st = json.loads(st_row["payload"])
            eq_name_low = str(eq["name"] or "").lower().strip()
            eq_obj_low = str(eq["object_name"] or "").lower().strip()
            disp_low = str(passport.get("dispatch_name") or "").lower().strip()
            for proto in st.get("protocols") or []:
                if not isinstance(proto, dict):
                    continue
                p_obj_low = str(proto.get("object") or "").lower().strip()
                p_num = str(proto.get("number") or proto.get("num") or "б/н")
                p_date = str(proto.get("date") or "")[:10]
                p_type = _PROTO_TYPE_RU.get(str(proto.get("type") or ""), str(proto.get("type") or "Испытание ЭТЛ"))
                for row in proto.get("rows") or []:
                    row_txt = json.dumps(row, ensure_ascii=False).lower() if isinstance(row, (dict, list)) else str(row).lower()
                    matched = False
                    if isinstance(row, dict) and str(row.get("equipmentId") or "") == eq["id"]:
                        matched = True
                    elif eq_name_low and len(eq_name_low) >= 4 and eq_name_low in row_txt:
                        matched = True
                    elif disp_low and len(disp_low) >= 4 and disp_low in row_txt and (not p_obj_low or p_obj_low in eq_obj_low or eq_obj_low in p_obj_low):
                        matched = True
                    if not matched:
                        continue
                    if isinstance(row, dict):
                        skip = {"id", "idx", "num", "equipmentId", "conclusion", "result"}
                        summary = "; ".join(str(v) for k, v in row.items() if k not in skip and v not in (None, "", "—", "-"))[:160]
                        concl = str(row.get("conclusion") or row.get("result") or "Соответствует")
                    elif isinstance(row, list):
                        vals = [str(x).strip() for x in row if x not in (None, "")]
                        summary = "; ".join(vals[:6])[:160]
                        concl = "Не соответствует" if any("не соотв" in v.lower() or "брак" in v.lower() for v in vals) else "Соответствует"
                    else:
                        summary, concl = str(row)[:160], "Соответствует"
                    key = (p_date, f"№ {p_num}", p_type)
                    if key not in seen_keys:
                        seen_keys.add(key)
                        records.append({
                            "source": "arm_protocol",
                            "date": p_date,
                            "test_type": p_type,
                            "protocol_no": f"№ {p_num}",
                            "summary": summary or "Проведено испытание",
                            "conclusion": concl,
                        })
    except Exception:
        pass

    # 3. Manual archived test records in passport_journal
    j_rows = conn.execute(
        "SELECT id, event_date, col1, col2, col3, col4 FROM passport_journal WHERE equipment_id = ? AND section = 'manual_test' ORDER BY event_date DESC, id DESC",
        (eq["id"],),
    ).fetchall()
    for r in j_rows:
        records.append({
            "id": r["id"],
            "source": "manual",
            "date": r["event_date"],
            "test_type": r["col1"],
            "protocol_no": r["col2"],
            "summary": r["col3"],
            "conclusion": r["col4"],
        })

    records.sort(key=lambda x: str(x.get("date") or ""), reverse=True)
    return records


def get_full_passport_payload(equipment_id: str, db_path: Optional[Path] = None) -> Dict[str, Any]:
    target = db_path or arm_db.DB_PATH
    init_unified_passport_tables(target)
    with sqlite3.connect(target) as conn:
        ctx = ensure_passport_row(conn, equipment_id)
        eq, p = ctx["eq"], ctx["passport"]
        specs = json.loads(p.get("specs_json") or "{}")
        if not specs.get("type") and p.get("model"):
            specs["type"] = p["model"]

        journal: Dict[str, List[Dict[str, Any]]] = {"repair": [], "hours": [], "move": []}
        for r in conn.execute(
            "SELECT id, section, event_date, col1, col2, col3, col4, col5, created_by FROM passport_journal WHERE equipment_id = ? AND section IN ('repair','hours','move') ORDER BY event_date DESC, id DESC",
            (equipment_id,),
        ).fetchall():
            journal[r["section"]].append({
                "id": r["id"],
                "date": r["event_date"],
                "col1": r["col1"],
                "col2": r["col2"],
                "col3": r["col3"],
                "col4": r["col4"],
                "col5": r["col5"],
                "created_by": r["created_by"],
            })

        versions = [
            {
                "version_no": r["version_no"],
                "change_reason": r["change_reason"],
                "created_by": r["created_by"],
                "created_at": r["created_at"],
            }
            for r in conn.execute(
                "SELECT version_no, change_reason, created_by, created_at FROM passport_versions WHERE equipment_id = ? ORDER BY version_no DESC",
                (equipment_id,),
            ).fetchall()
        ]
        tests = _collect_auto_tests(conn, eq, p)
        tpl = get_template_for_type(p["type_code"])

        return {
            "equipment": {
                "id": eq["id"],
                "num": eq["num"],
                "object_name": eq["object_name"],
                "name": eq["name"],
                "power": eq["power"],
                "period": eq["period"],
                "last_date": eq["last_date"],
                "months": json.loads(eq["months_json"] or "[]"),
                "cat": eq["cat"],
            },
            "passport": {
                "type_code": p["type_code"],
                "type_name": _TYPE_NAMES_RU.get(p["type_code"], p["type_code"]),
                "qr_token": p["qr_token"],
                "short_code": p["short_code"],
                "qr_url": build_qr_url(p["qr_token"]),
                "dispatch_name": p["dispatch_name"] or eq["name"],
                "inventory_no": p["inventory_no"] or eq["num"] or "",
                "serial_no": p["serial_no"] or "",
                "model": p["model"] or "",
                "manufacturer": p["manufacturer"] or "",
                "commissioned_at": p["commissioned_at"] or "",
                "specs": specs,
                "sec_1_scheme": p["sec_1_scheme"] or "",
                "sec_3_rza": p["sec_3_rza"] or "",
                "original_filename": p["original_filename"] or "",
                "has_original": bool(p["original_file_path"] and Path(p["original_file_path"]).exists()),
                "print_count": p["print_count"],
                "updated_at": p["updated_at"],
            },
            "template": tpl,
            "tests": tests,
            "journal": journal,
            "versions": versions,
        }


def save_passport_fields(
    equipment_id: str,
    body: Dict[str, Any],
    actor: str = "admin",
    db_path: Optional[Path] = None,
) -> Dict[str, Any]:
    target = db_path or arm_db.DB_PATH
    init_unified_passport_tables(target)
    with sqlite3.connect(target) as conn:
        ctx = ensure_passport_row(conn, equipment_id)
        p = ctx["passport"]
        cur_specs = json.loads(p.get("specs_json") or "{}")
        if isinstance(body.get("specs"), dict):
            cur_specs.update(body["specs"])

        type_code = str(body.get("type_code") or p["type_code"])
        dispatch_name = str(body.get("dispatch_name") if body.get("dispatch_name") is not None else p["dispatch_name"]).strip()
        inventory_no = str(body.get("inventory_no") if body.get("inventory_no") is not None else p["inventory_no"]).strip()
        serial_no = str(body.get("serial_no") if body.get("serial_no") is not None else p["serial_no"]).strip()
        model = str(body.get("model") if body.get("model") is not None else (cur_specs.get("type") or p["model"])).strip()
        manufacturer = str(body.get("manufacturer") if body.get("manufacturer") is not None else p["manufacturer"]).strip()
        commissioned_at = str(body.get("commissioned_at") if body.get("commissioned_at") is not None else p["commissioned_at"]).strip()
        sec_1 = str(body.get("sec_1_scheme") if body.get("sec_1_scheme") is not None else p["sec_1_scheme"]).strip()
        sec_3 = str(body.get("sec_3_rza") if body.get("sec_3_rza") is not None else p["sec_3_rza"]).strip()
        reason = str(body.get("change_reason") or "Обновление паспорта").strip()

        conn.execute(
            """
            UPDATE equipment_passports
            SET type_code=?, dispatch_name=?, inventory_no=?, serial_no=?, model=?,
                manufacturer=?, commissioned_at=?, specs_json=?, sec_1_scheme=?, sec_3_rza=?,
                updated_at=CURRENT_TIMESTAMP
            WHERE equipment_id=?
            """,
            (type_code, dispatch_name, inventory_no, serial_no, model, manufacturer, commissioned_at, json.dumps(cur_specs, ensure_ascii=False), sec_1, sec_3, equipment_id),
        )
        max_v = conn.execute("SELECT COALESCE(MAX(version_no), 0) FROM passport_versions WHERE equipment_id = ?", (equipment_id,)).fetchone()[0]
        next_v = int(max_v) + 1
        snap = {
            "type_code": type_code, "dispatch_name": dispatch_name, "inventory_no": inventory_no,
            "serial_no": serial_no, "model": model, "manufacturer": manufacturer,
            "commissioned_at": commissioned_at, "specs": cur_specs,
            "sec_1_scheme": sec_1, "sec_3_rza": sec_3,
        }
        conn.execute(
            "INSERT INTO passport_versions (equipment_id, version_no, snapshot_json, change_reason, created_by) VALUES (?, ?, ?, ?, ?)",
            (equipment_id, next_v, json.dumps(snap, ensure_ascii=False), reason, actor),
        )
        conn.commit()
    return {"status": "ok", "version_no": next_v}


def add_journal_entry(
    equipment_id: str,
    section: str,
    event_date: str,
    col1: str = "",
    col2: str = "",
    col3: str = "",
    col4: str = "",
    col5: str = "",
    actor: str = "admin",
    db_path: Optional[Path] = None,
) -> int:
    if section not in ("repair", "hours", "move", "manual_test"):
        raise ValueError("Неизвестный раздел журнала")
    target = db_path or arm_db.DB_PATH
    init_unified_passport_tables(target)
    with sqlite3.connect(target) as conn:
        ensure_passport_row(conn, equipment_id)
        cur = conn.execute(
            """
            INSERT INTO passport_journal (equipment_id, section, event_date, col1, col2, col3, col4, col5, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (equipment_id, section, event_date.strip(), col1.strip(), col2.strip(), col3.strip(), col4.strip(), col5.strip(), actor),
        )
        conn.commit()
        return int(cur.lastrowid)


def delete_journal_entry(equipment_id: str, entry_id: int, db_path: Optional[Path] = None) -> bool:
    target = db_path or arm_db.DB_PATH
    with sqlite3.connect(target) as conn:
        cur = conn.execute("DELETE FROM passport_journal WHERE id = ? AND equipment_id = ?", (entry_id, equipment_id))
        conn.commit()
        return cur.rowcount > 0


def save_original_passport_file(
    equipment_id: str,
    filename: str,
    content: bytes,
    db_path: Optional[Path] = None,
) -> Dict[str, Any]:
    target = db_path or arm_db.DB_PATH
    init_unified_passport_tables(target)
    ORIGINALS_DIR.mkdir(parents=True, exist_ok=True)
    safe_id = re.sub(r"[^a-zA-Z0-9_-]", "_", equipment_id)
    ext = Path(filename or "passport.pdf").suffix or ".pdf"
    dest = ORIGINALS_DIR / f"{safe_id}_original{ext}"
    with sqlite3.connect(target) as conn:
        ctx = ensure_passport_row(conn, equipment_id)
        if ctx["passport"].get("original_file_path") and Path(ctx["passport"]["original_file_path"]).exists():
            raise FileExistsError("Неизменяемый оригинал паспорта уже загружен")
        dest.write_bytes(content)
        conn.execute(
            "UPDATE equipment_passports SET original_file_path = ?, original_filename = ?, updated_at = CURRENT_TIMESTAMP WHERE equipment_id = ?",
            (str(dest), filename, equipment_id),
        )
        conn.commit()
    return {"status": "ok", "filename": filename, "size": len(content)}


def _build_render_structures(payload: Dict[str, Any], version_no: Optional[int] = None) -> Tuple[Dict[str, Any], int, Dict[str, Any], Dict[str, Any]]:
    eq_raw = payload["equipment"]
    p_raw = payload["passport"]
    specs = dict(p_raw.get("specs") or {})
    if not specs.get("type") and p_raw.get("model"):
        specs["type"] = p_raw["model"]

    eq = {
        "id": eq_raw["id"],
        "name": eq_raw["name"],
        "dispatch_name": p_raw.get("dispatch_name") or eq_raw["name"],
        "location_name": eq_raw["object_name"],
        "inventory_no": p_raw.get("inventory_no") or eq_raw["num"] or "—",
        "serial_no": p_raw.get("serial_no") or "—",
        "model": p_raw.get("model") or eq_raw["power"] or "—",
        "manufacturer": p_raw.get("manufacturer") or "—",
        "commissioned_at": p_raw.get("commissioned_at") or "",
        "short_code": p_raw.get("short_code") or "",
        "type_code": p_raw.get("type_code") or "SWITCHBOARD",
        "type_name": p_raw.get("type_name") or "Электрооборудование",
    }
    v_num = version_no if version_no is not None else (payload["versions"][0]["version_no"] if payload["versions"] else 1)
    j = payload["journal"]
    v_data = {
        "specs": specs,
        "sec_1_scheme": p_raw.get("sec_1_scheme") or "",
        "sec_3_rza": p_raw.get("sec_3_rza") or "",
        "test_records": payload["tests"],
        "repair_records": [
            {"date": r["date"], "order_no": r["col1"], "work": r["col2"], "executor": r["col3"], "note": r["col4"]}
            for r in reversed(j["repair"])
        ],
        "hours_records": [
            {"date": r["date"], "hours": r["col1"], "facility": r["col2"], "unit": r["col3"], "responsible": r["col4"], "note": r["col5"]}
            for r in reversed(j["hours"])
        ],
        "move_records": [
            {"date": r["date"], "facility": r["col1"], "unit": r["col2"], "responsible": r["col3"], "note": r["col4"]}
            for r in reversed(j["move"])
        ],
    }
    return eq, v_num, v_data, specs


def export_unified_passport(equipment_id: str, fmt: str = "docx", db_path: Optional[Path] = None) -> Tuple[bytes, str, str]:
    payload = get_full_passport_payload(equipment_id, db_path=db_path)
    eq, v_num, v_data, specs = _build_render_structures(payload)
    safe_inv = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", str(eq["inventory_no"] or eq["short_code"] or equipment_id))

    if eq["type_code"] == "MOTOR" and OGE_TEMPLATE.exists():
        docx_bytes = _render_motor_oge_template_docx(eq, v_num, v_data, specs)
    else:
        docx_bytes = _render_generic_gost_passport(eq, v_num, v_data, specs)

    if fmt.lower() == "docx":
        return docx_bytes, f"passport_{safe_inv}_v{v_num}.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

    if fmt.lower() == "pdf":
        soffice = find_soffice()
        if soffice:
            with tempfile.TemporaryDirectory() as td:
                in_doc = Path(td) / "passport.docx"
                in_doc.write_bytes(docx_bytes)
                res = subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", td, str(in_doc)], capture_output=True, timeout=60)
                out_pdf = Path(td) / "passport.pdf"
                if res.returncode == 0 and out_pdf.exists():
                    return out_pdf.read_bytes(), f"passport_{safe_inv}_v{v_num}.pdf", "application/pdf"
        pdf_bytes = render_passport_pdf_fallback(eq, v_num, v_data, specs)
        return pdf_bytes, f"passport_{safe_inv}_v{v_num}.pdf", "application/pdf"

    raise ValueError("Поддерживаются только форматы docx и pdf")


def _render_generic_gost_passport(eq: Dict[str, Any], v_num: int, v_data: Dict[str, Any], specs: Dict[str, Any]) -> bytes:
    tpl = get_template_for_type(eq["type_code"])
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.left_margin, sec.right_margin, sec.top_margin, sec.bottom_margin = Mm(20), Mm(15), Mm(15), Mm(15)
    doc.styles["Normal"].font.name = "Times New Roman"
    doc.styles["Normal"].font.size = Pt(11)

    _set_tnr(doc.add_paragraph().add_run("ООО «Сургут перевалка» — Отдел главного энергетика (ОГЭ) / ЭТЛ (Свид. № 58ЭТЛ035)"), size=11, bold=True)
    _set_tnr(doc.add_paragraph().add_run(f"ЭЛЕКТРОННЫЙ ПАСПОРТ ОБОРУДОВАНИЯ (Редакция № {v_num})"), size=13, bold=True)
    _set_tnr(doc.add_paragraph().add_run(tpl["title"]), size=11)

    tbl = doc.add_table(rows=0, cols=2)
    tbl.style = "Table Grid"
    tbl.autofit = False
    for k, val in [
        ("Наименование", eq["name"]),
        ("Тип оборудования", eq["type_name"]),
        ("Место установки (объект)", eq["location_name"] or "—"),
        ("Инвентарный №", eq["inventory_no"] or "—"),
        ("Заводской №", eq["serial_no"] or "—"),
        ("Модель / марка", eq["model"] or "—"),
        ("Завод-изготовитель", eq["manufacturer"] or "—"),
        ("Год ввода", eq["commissioned_at"] or "—"),
        ("QR-код", eq["short_code"] or "—"),
    ]:
        r = tbl.add_row().cells
        r[0].width, r[1].width = Mm(60), Mm(115)
        _set_cell_text(r[0], k, size=10, bold=True)
        _set_cell_text(r[1], str(val), size=10)
    _mark_table_header_and_nosplit(tbl)

    if v_data.get("sec_1_scheme"):
        p1 = doc.add_paragraph()
        p1.paragraph_format.space_before = Pt(8)
        _set_tnr(p1.add_run("Раздел 1. Схема подключения и привязка"), size=11, bold=True)
        _set_tnr(doc.add_paragraph().add_run(str(v_data["sec_1_scheme"])), size=10)

    sec2 = next((s for s in tpl.get("sections", []) if s.get("code") == "sec_2"), None)
    if sec2 and sec2.get("fields"):
        p2 = doc.add_paragraph()
        p2.paragraph_format.space_before = Pt(8)
        p2.paragraph_format.keep_with_next = True
        _set_tnr(p2.add_run(f"Раздел {sec2['title']}"), size=11, bold=True)
        stbl = doc.add_table(rows=1, cols=3)
        stbl.style = "Table Grid"
        stbl.autofit = False
        w3 = [Mm(14), Mm(106), Mm(55)]
        for i, htxt in enumerate(["№", "Параметр", "Значение"]):
            stbl.rows[0].cells[i].width = w3[i]
            _set_cell_text(stbl.rows[0].cells[i], htxt, size=10, bold=True)
        for fld in sec2["fields"]:
            r = stbl.add_row().cells
            val = specs.get(fld["key"])
            for i, txt in enumerate([fld["no"], fld["label"], str(val) if val not in (None, "") else "—"]):
                r[i].width = w3[i]
                _set_cell_text(r[i], txt, size=10)
        _mark_table_header_and_nosplit(stbl)

    if v_data.get("sec_3_rza"):
        p3 = doc.add_paragraph()
        p3.paragraph_format.space_before = Pt(8)
        _set_tnr(p3.add_run("Раздел 3. Коммутационные аппараты и РЗиА"), size=11, bold=True)
        _set_tnr(doc.add_paragraph().add_run(str(v_data["sec_3_rza"])), size=10)

    p4 = doc.add_paragraph()
    p4.paragraph_format.space_before = Pt(8)
    p4.paragraph_format.keep_with_next = True
    _set_tnr(p4.add_run("Разделы 4–10. Результаты электрических испытаний и измерений"), size=11, bold=True)
    ttbl = doc.add_table(rows=1, cols=5)
    ttbl.style = "Table Grid"
    ttbl.autofit = False
    w5 = [Mm(22), Mm(40), Mm(26), Mm(52), Mm(35)]
    for i, htxt in enumerate(["Дата", "Вид испытания / МВИ", "Протокол №", "Результаты", "Заключение"]):
        ttbl.rows[0].cells[i].width = w5[i]
        _set_cell_text(ttbl.rows[0].cells[i], htxt, size=9, bold=True)
    for tr in (v_data.get("test_records") or [{}]):
        r = ttbl.add_row().cells
        vals = [tr.get("date"), tr.get("test_type"), tr.get("protocol_no"), tr.get("summary"), tr.get("conclusion")] if tr else ["—"] * 5
        for i, txt in enumerate(vals):
            r[i].width = w5[i]
            _set_cell_text(r[i], str(txt or "—"), size=9)
    _mark_table_header_and_nosplit(ttbl)

    if v_data.get("repair_records"):
        pr = doc.add_paragraph()
        pr.paragraph_format.space_before = Pt(8)
        pr.paragraph_format.keep_with_next = True
        _set_tnr(pr.add_run("Раздел 11. ППР, ТО и текущий ремонт"), size=11, bold=True)
        rtbl = doc.add_table(rows=1, cols=4)
        rtbl.style = "Table Grid"
        rtbl.autofit = False
        w4 = [Mm(22), Mm(32), Mm(86), Mm(35)]
        for i, htxt in enumerate(["Дата", "Наряд / расп.", "Выполненные работы", "Исполнитель"]):
            rtbl.rows[0].cells[i].width = w4[i]
            _set_cell_text(rtbl.rows[0].cells[i], htxt, size=9, bold=True)
        for rec in v_data["repair_records"]:
            r = rtbl.add_row().cells
            for i, txt in enumerate([rec.get("date"), rec.get("order_no"), rec.get("work"), rec.get("executor")]):
                r[i].width = w4[i]
                _set_cell_text(r[i], str(txt or "—"), size=9)
        _mark_table_header_and_nosplit(rtbl)

    ps = doc.add_paragraph()
    ps.paragraph_format.space_before = Pt(14)
    _set_tnr(ps.add_run("Начальник ЭТЛ: ______________ / Д. Ю. Лиханов"), size=10)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _format_specs_line(model: str, power: str, specs: Dict[str, Any]) -> str:
    parts = []
    if model and model != "Б/М":
        parts.append(model)
    kw = specs.get("power_kw")
    rpm = specs.get("rpm")
    if kw not in (None, "") and "квт" not in (model or "").lower():
        parts.append(f"{kw} кВт")
    if rpm not in (None, "") and "об/мин" not in (model or "").lower():
        parts.append(f"{int(float(rpm))} об/мин")
    if not parts and power:
        parts.append(power)
    return ", ".join(parts)


def get_qr_badge_bytes(equipment_id: str, fmt: str = "png", db_path: Optional[Path] = None) -> Tuple[bytes, str]:
    target = db_path or arm_db.DB_PATH
    init_unified_passport_tables(target)
    with sqlite3.connect(target) as conn:
        ctx = ensure_passport_row(conn, equipment_id)
        eq, p = ctx["eq"], ctx["passport"]
        specs = json.loads(p.get("specs_json") or "{}")
        url = build_qr_url(p["qr_token"])
        if fmt.lower() == "svg":
            return render_qr_svg(url), "image/svg+xml"
        label_info = {
            "short_code": p["short_code"],
            "name": eq["name"],
            "inventory_no": p["inventory_no"] or eq["num"] or "—",
            "model": p["model"] or eq["power"] or "",
            "location_name": eq["object_name"],
            "specs_line": _format_specs_line(p["model"] or "", eq["power"] or "", specs),
        }
        return render_qr_png(url, label_info=label_info), "image/png"


def print_qr_batch(equipment_ids: List[str], preset: str = "a4_3x7", db_path: Optional[Path] = None) -> Tuple[bytes, str]:
    if not equipment_ids:
        raise ValueError("Выберите хотя бы один объект для печати QR")
    if preset not in ("a4_3x7", "thermal_58x40", "thermal_43x25"):
        raise ValueError("Неизвестный формат этикетки")
    target = db_path or arm_db.DB_PATH
    init_unified_passport_tables(target)
    items = []
    with sqlite3.connect(target) as conn:
        for eid in equipment_ids:
            try:
                ctx = ensure_passport_row(conn, eid)
            except KeyError:
                continue
            eq, p = ctx["eq"], ctx["passport"]
            specs = json.loads(p.get("specs_json") or "{}")
            items.append({
                "qr_url": build_qr_url(p["qr_token"]),
                "short_code": p["short_code"],
                "inventory_no": p["inventory_no"] or eq["num"] or "—",
                "location_name": eq["object_name"],
                "name": eq["name"],
                "model": p["model"] or eq["power"] or "",
                "specs_line": _format_specs_line(p["model"] or "", eq["power"] or "", specs),
            })
            conn.execute("UPDATE equipment_passports SET print_count = print_count + 1 WHERE equipment_id = ?", (eid,))
        conn.commit()
    if not items:
        raise ValueError("Выбранные объекты не найдены")
    return render_qr_labels_pdf(items, preset=preset), f"qr_{preset}_{len(items)}pcs.pdf"


def resolve_equipment_by_qr(qr_token: str, db_path: Optional[Path] = None) -> Optional[str]:
    target = db_path or arm_db.DB_PATH
    init_unified_passport_tables(target)
    tok = qr_token.strip()
    with sqlite3.connect(target) as conn:
        row = conn.execute(
            "SELECT equipment_id FROM equipment_passports WHERE qr_token = ? OR upper(short_code) = upper(?) LIMIT 1",
            (tok, tok),
        ).fetchone()
        return row[0] if row else None
